#pragma once
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "LinkedList.h"
#include "Collisions.h"
#include <iostream>
#include "Button.h"
#include "GameScreenControls.h"

class GameScreenLoose : public GameScreenControls
{
public:
	GameScreenLoose(SDL_Renderer* renderer, Camera* cam);
	~GameScreenLoose();
	void Render(float Xoffset, float Yoffset) override;
	void Update(float deltaTime) override;
	void HandleEvents(SDL_Event e, float deltaTime) override;

private:
	Button* m_congratsButton = nullptr;
	Button* m_continueButton = nullptr;
	bool m_mouseIsOnCongratsButton = false;
	bool m_mouseIsOnContinueButton = false;
	Camera* m_cam = nullptr;
	float m_buttonSpacing = 20;
	void InitButtons();
	void HandleButtonClicks(SDL_Event e);
};

