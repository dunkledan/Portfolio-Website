#pragma once
#include "GameObject.h"
#include "Audio.h"

class Coin : public GameObject
{
	public:
		Coin(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D startPosition);
		~Coin();
		void InitAudio();
		void PlayPickup() { m_SFXPickup->Play(0); };
		void Update(float deltaTime);
		void HandleEvents(SDL_Event e);
	private:
		Audio* m_SFXPickup = nullptr;
		float m_centre;
};

