#include "GameScreenMenu.h"

GameScreenMenu::GameScreenMenu(SDL_Renderer* renderer, Camera* cam) : GameScreen(renderer)
{
	m_renderer = renderer;
	m_cam = cam;
	m_buttonsList = LinkedList<Button>();
	TryLoadTexture(m_backgroundTexture, "Images/level1Bg.png");
	InitButtons();
}

GameScreenMenu::~GameScreenMenu()
{
	m_buttonsList.ClearList();
}

void GameScreenMenu::Render(float Xoffset, float Yoffset)
{
	m_backgroundTexture->Render(Vector2D(Xoffset, Yoffset), SDL_FLIP_NONE);
	m_startButton->Render(Xoffset,Yoffset);
	m_controlsButton->Render(Xoffset,Yoffset);
}

void GameScreenMenu::HandleEvents(SDL_Event e, float deltaTime)
{
	for (int i = 0; i < m_buttonsList.GetSize(); i++)
	{
		m_buttonsList.GetItemByIndex(i)->HandleEvents(e, deltaTime);
	}
	ButtonSelect(e);
}

void GameScreenMenu::Update(float deltaTime)
{	
	for (int i = 0; i < m_buttonsList.GetSize(); i++)
	{
		m_buttonsList.GetItemByIndex(i)->Update(deltaTime);
	}
}

/// <summary>
/// initialises buttons on the  screen
/// </summary>
void GameScreenMenu::InitButtons()
{
	m_buttonsList.ClearList();
	m_startButton = new Button(m_renderer, m_cam, Vector2D((SCREEN_WIDTH / 4), (SCREEN_HEIGHT / 4)), "Start", 24, SDL_Color{ 85,153,0,1}, SDL_Color{ 0,0,0,0 });
	m_controlsButton = new Button(m_renderer,m_cam, Vector2D(m_startButton->GetPos().x, m_startButton->GetPos().y + m_buttonSpacing),"Controls", 24, SDL_Color{ 0,48,143,1 }, SDL_Color{ 0,0,0,0 });
	m_buttonsList.Push(m_startButton);
	m_buttonsList.Push(m_controlsButton);
}
using namespace std;
/// <summary>
/// handles button selection
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenMenu::ButtonSelect(SDL_Event e)
{
	//handle evercade button selection
	switch (e.type)
	{
	case SDL_JOYBUTTONDOWN:
		switch (e.jbutton.button)
		{
		case 13:
			if (m_buttonsList.GetSize() != 1)
			{
				m_currentButtonIndex--;
				//if scrolled to the start of the button list, select the button at the end of the list
				if (m_currentButtonIndex < 0)
				{
					m_currentButtonIndex = m_buttonsList.GetSize() - 1;
					ClearHoveredAndClicked();
				}
				ClearHoveredAndClicked();
				m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetHovered(true);
			}
			break;
		case 16:
			if (m_buttonsList.GetSize() != 1)
			{
				m_currentButtonIndex++;
				//if scrolled to the end of the button list, select the button at the start of the list
				if (m_currentButtonIndex > m_buttonsList.GetSize() - 1)
				{
					m_currentButtonIndex = 0;
					ClearHoveredAndClicked();
				}
				ClearHoveredAndClicked();
				m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetHovered(true);
			}
			break;
		case 4:
			m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetHovered(true);
			m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetClicked(true);
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	HandleButtonClicks( e);
}	

/// <summary>
/// resets all button states
/// </summary>
void GameScreenMenu::ClearHoveredAndClicked()
{
	for (int i = 0; i < m_buttonsList.GetSize(); i++)
	{
		m_buttonsList.GetItemByIndex(i)->SetHovered(false);
		m_buttonsList.GetItemByIndex(i)->SetClicked(false);
	}
}

/// <summary>
/// if a button is clicked/selected push appropriate event
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenMenu::HandleButtonClicks(SDL_Event e)
{
	if (m_startButton->IsClicked(e))
	{
		//go to level 1
		SDL_Event userEvent;
		userEvent.type = SDL_USEREVENT;
		userEvent.user.code = 2;
		SDL_PushEvent(&userEvent);
	}
	if (m_controlsButton->IsClicked(e))
	{
		//go to controls
		SDL_Event userEvent;
		userEvent.type = SDL_USEREVENT;
		userEvent.user.code = 3;
		SDL_PushEvent(&userEvent);
	}
}