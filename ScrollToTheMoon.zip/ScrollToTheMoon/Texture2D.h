#pragma once
#ifndef _TEXTURE2D_H
#define _TEXTURE2D_H

#include <SDL.h>
#include <string>
#include "Commons.h"

class Texture2D
{
	private:
		SDL_Renderer* m_renderer = nullptr;
		SDL_Texture* m_texture = nullptr;
		float m_width;
		float m_height;
	
	public:
		Texture2D(SDL_Renderer* renderer);
		~Texture2D();
		bool LoadFromFile(std::string path);
		void Free();
		void Render(Vector2D new_position, SDL_RendererFlip flip, double angle = 0.0f);

		//getters (inline)
		float GetWidth() { return m_width; }
		float GetHeight(){ return m_height; }
};

#endif //_TEXTURE2D_H