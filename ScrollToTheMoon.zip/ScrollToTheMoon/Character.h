#pragma once
#include "GameObject.h"
#include "GameObjectPhysics.h"
#include "Tilemap.h"
#include "Collisions.h"
#include <map>
#include "Audio.h"
#include <vector>

enum PowerUpEquipped
{
	DoubleJump,
	Helmet,
	Climb,
	None,
	Random
};

class Character : public GameObject
{
	public:
		Character(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D startPosition, Tilemap* tmap);
		~Character();
		virtual void Render(float Xoffset, float Yoffset) override;
		void RenderHelmet(float Xoffset, float Yoffset, SDL_RendererFlip flip);
		virtual void Update(float deltaTime) override;
		virtual void HandleEvents(SDL_Event e, float deltaTime) override;
		void SetPowerUp(PowerUpEquipped power) { m_powerUp = power; };
		void SetFallingState(bool state) { m_falling = state; };
		void SetJumpUsed(bool state) { m_jumpUsed = state; };
		PowerUpEquipped GetPowerUp() { return m_powerUp; };
		void AddPowerUpTextureMapping(PowerUpEquipped type, Texture2D* powerUpTexture) { (*m_characterPowerUpTextures)[type] = powerUpTexture; };
		void HandlePowerUpChange(PowerUpEquipped power);
		GameObjectPhysics* m_physicsSystem = nullptr;
		int GetHits() { return m_hits; };
		void SetHits(int newHits) { m_hits = newHits; };
		void TakeDamage();
		float GetTimeSinceHit() { return m_timeSinceHit; };
		float GetHitCoolDownTime();
		void InitAudio();
		bool m_isDead = false;
		Audio* m_SFXDeath = nullptr;
		void SetIdleAnim(std::vector<Texture2D*> anim) { m_idleAnim = anim; };
		void SetIdleHelmetAnim(std::vector<Texture2D*> anim) { m_idleHelmetAnim = anim; };
		void SetRegenHelmetAnim(std::vector<Texture2D*> anim) { m_regenHelmetAnim = anim; };
		void SetInvincibleHelmetAnim(std::vector<Texture2D*> anim) { m_invincibleHelmetAnim = anim; };
		void SetDamageHelmetAnim(std::vector<Texture2D*> anim) { m_damageHelmetAnim = anim; };
		void SetDoubleJumpIdleAnim(std::vector<Texture2D*> anim) { m_idleDoubleJumpAnim = anim; };
		void SetJumpAnim(std::vector<Texture2D*> anim) { m_jumpAnim = anim; };
		void SetClimbJumpAnim(std::vector<Texture2D*> anim) { m_ClimbJumpAnim = anim; };
		void SetClimbIdleAnim(std::vector<Texture2D*> anim) { m_climbIdleAnim = anim; };
		void SetDoubleJumpJumpAnim(std::vector<Texture2D*> anim) { m_doubleJumpJumpAnim = anim; };
		void SetHelmetJumpAnim(std::vector<Texture2D*> anim) { m_helmetJumpAnim = anim; };

	protected:
		int m_hits = 1;
		std::vector<Texture2D*> m_idleAnim;
		std::vector<Texture2D*> m_idleHelmetAnim;
		std::vector<Texture2D*> m_regenHelmetAnim;
		std::vector<Texture2D*> m_invincibleHelmetAnim;
		std::vector<Texture2D*> m_damageHelmetAnim;
		std::vector<Texture2D*> m_idleDoubleJumpAnim;
		std::vector<Texture2D*> m_jumpAnim;
		std::vector<Texture2D*> m_ClimbJumpAnim;
		std::vector<Texture2D*> m_climbIdleAnim;
		std::vector<Texture2D*> m_doubleJumpJumpAnim;
		std::vector<Texture2D*> m_helmetJumpAnim;
		void HandleGameObjectCollision();
		void HandleTileMapCollisions();
		void HandleTileMapDownCollision(Rect2D box, Vector2D gridPos);
		void HandleTileMapUpCollision(Rect2D box, Vector2D gridPos);
		void HandleTileMapRightCollision(Rect2D box, Vector2D gridPos);
		void HandleTileMapLeftCollision(Rect2D box, Vector2D gridPos);
		void HandleRegen(float deltaTime);
		std::map<PowerUpEquipped, Texture2D*>* m_characterPowerUpTextures = nullptr;
		bool m_falling;
		bool m_jumpUsed;
		PowerUpEquipped m_powerUp = None;
		bool m_movingLeft;
		bool m_movingRight;
		void SetTexture(Texture2D* texture) { GameObject::SetTexture(texture); }
		void SetTexture(PowerUpEquipped power) { m_texture = (*m_characterPowerUpTextures)[power]; };
		virtual void MoveLeft(float deltaTime);
		virtual void MoveRight(float deltaTime);
		virtual void Jump(float deltaTime);
		virtual void HandleKeyDownEvent(SDL_Event e, float deltaTime);
		virtual void HandleKeyUpEvent(SDL_Event e);
		virtual void HandleCharacterFacingDirection(float deltaTime);
		bool m_doubleJumpUsed = false;
		float m_timeSinceHit = 0;
		float m_hitCoolDownTime = 3;
		void HandleHitCoolDownTimer();
		int m_maxHits = 1;
		Tilemap* m_tileMap = nullptr;
		Audio* m_SFXJump = nullptr;
		Audio* m_SFXHit = nullptr;
		void HandleLeftKeyDownInput(SDL_Event e, float deltaTime);
		void HandleRightKeyDownInput(SDL_Event e, float deltaTime);
		void HandleUpKeyDownInput(SDL_Event e, float deltaTime);
		void HandleLeftKeyReleaseInput(SDL_Event e);
		void HandleRightKeyReleaseInput(SDL_Event e);
		bool m_evenTimeSinceHit = false;
		FACING m_facingDirection;
		void HandleNonClimbCollisions(bool collidingDown, bool collidingUp, bool collidingRight, bool collidingLeft);
		bool HandleClimbCollisions(bool collidingDown, bool collidingUp, bool collidingRight, bool collidingLeft);
};
