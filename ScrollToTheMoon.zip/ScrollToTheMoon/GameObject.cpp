#include "GameObject.h"
#include "Texture2D.h"

using namespace std;

GameObject::GameObject(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D start_position)
{
	m_renderer = renderer;
	m_position = start_position;
	m_texture = baseTexture;
	m_collisionRadius = m_texture->GetWidth();
}

GameObject::~GameObject()
{
	m_renderer = nullptr;
}

void GameObject::Update(float deltaTime)
{

}

void GameObject::HandleEvents(SDL_Event e, float deltaTime)
{

}

void GameObject::Render(float Xoffset, float Yoffset)
{
    m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), SDL_FLIP_NONE); 
}

/// <summary>
/// plays a frame of animation based on how much time has passed since last frame every frame
/// </summary>
/// <param name="deltaTime"></param>
void GameObject::PlayAnimationFrame(float deltaTime)
{
    if (m_currentAnim.size() > 0)
    {
        m_animTimer += deltaTime;
        if (m_animTimer >= 5)
        {
            m_animTimer -= 5;
            m_animIndex++; 
            if (m_animIndex >= m_currentAnim.size())
            {
                m_animIndex = 0;
            }
            m_texture = m_currentAnim[m_animIndex];
        }
    }
}
