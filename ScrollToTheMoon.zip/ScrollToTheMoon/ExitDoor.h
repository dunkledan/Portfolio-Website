#pragma once
#include "GameObject.h"
#include "Audio.h"

class ExitDoor : public GameObject
{
	public:
		ExitDoor(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D startPosition);
		~ExitDoor();
		void PlayWin() { m_SFX_Win->Play(0); };
		void InitAudio();
		void HandleEvents(SDL_Event e);

	private:
		Audio* m_SFX_Win = nullptr;
};

