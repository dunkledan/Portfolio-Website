#pragma once
#include "GameScreenControls.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "LinkedList.h"
#include "Collisions.h"
#include <iostream>
#include "Button.h"

class GameScreenCredits : public GameScreenControls
{
public:
	GameScreenCredits(SDL_Renderer* renderer, Camera* cam);
	~GameScreenCredits();
	void Render(float Xoffset, float Yoffset) override;
	void Update(float deltaTime) override;
	void HandleEvents(SDL_Event e, float deltaTime) override;

private:
	Button* m_congratsButton = nullptr;
	Button* m_replayButton = nullptr;
	Camera* m_cam = nullptr;
	bool m_mouseIsOncongratsButton = false;
	bool m_mouseIsOnreplayButton = false;
	float m_buttonSpacing = 20;
	void InitButtons();
	void HandleButtonClicks(SDL_Event e);

};

