#pragma once
#include "GameObject.h"
#include "Character.h"
#include <cstdlib>
#include <time.h>

class MysteryBox : public GameObject
{
	public:
		MysteryBox(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D start_position, PowerUpEquipped powerUp);
		~MysteryBox();
		void SetPowerup(Character* player);
		void InitAudio();
		void HandleEvents(SDL_Event e, float deltaTime) override;

	private:
		PowerUpEquipped m_powerUp;
		Audio* m_SFX_ItemPickup = nullptr;
};