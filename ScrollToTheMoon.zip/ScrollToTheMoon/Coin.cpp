#include "Coin.h"

Coin::Coin(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D startPosition) : GameObject(renderer, baseTexture, startPosition)
{
	m_tag = "Coin";
	m_centre = m_position.y - 2;
}

void Coin::Update(float deltaTime)
{
	static float currentTime = 0;
	PlayAnimationFrame(deltaTime);
	///bounce up and down coin anim maths
	currentTime += deltaTime;
	m_position.y = m_centre+sinf(currentTime * 0.1f) * 8;
}

void Coin::HandleEvents(SDL_Event e)
{
}

/// <summary>
/// Initialises coin pickup audio
/// </summary>
void Coin::InitAudio()
{
	m_SFXPickup = new Audio("AudioFiles/SFX_CoinPickup.wav");
	m_SFXPickup->SetVolume(100);
}

Coin::~Coin()
{
}