#include "GameScreenCredits.h"

GameScreenCredits::GameScreenCredits(SDL_Renderer* renderer, Camera* cam) : GameScreenControls(renderer,cam)
{
	m_buttonsList.ClearList();
	InitButtons();
	m_currentButtonIndex = 0;
	m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetHovered(true);
}

GameScreenCredits::~GameScreenCredits()
{
	delete m_congratsButton;
	m_congratsButton = nullptr;
	delete m_replayButton;
	m_replayButton = nullptr;
}

void GameScreenCredits::Render(float Xoffset, float Yoffset)
{
	m_backgroundTexture->Render(Vector2D(Xoffset, Yoffset), SDL_FLIP_NONE);
	m_congratsButton->Render(Xoffset, Yoffset);
	m_replayButton->Render(Xoffset, Yoffset);
}

void GameScreenCredits::Update(float deltaTime)
{
	m_congratsButton->Update(deltaTime);
	m_replayButton->Update(deltaTime);
}

void GameScreenCredits::HandleEvents(SDL_Event e, float deltaTime)
{
	GameScreenControls::HandleEvents(e,deltaTime);
}

/// <summary>
/// initialises buttons on the  screen
/// </summary>
void GameScreenCredits::InitButtons()
{
	m_congratsButton = new Button(m_renderer, m_cam, Vector2D((SCREEN_WIDTH / 4), (SCREEN_HEIGHT / 4)), "YOU BEAT THE GAME", 24, SDL_Color{ 0,48,143,1 }, SDL_Color{ 0,0,0,0 });
	m_replayButton = new Button(m_renderer, m_cam, Vector2D(m_congratsButton->GetPos().x, m_congratsButton->GetPos().y + m_buttonSpacing), "Replay?", 24, SDL_Color{ 85,153,0,1 }, SDL_Color{ 0,0,0,0 });
	m_buttonsList.Push(m_replayButton);
}

/// <summary>
/// if a button is clicked/selected push appropriate event
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenCredits::HandleButtonClicks(SDL_Event e)
{
	if (m_replayButton->IsClicked(e))
	{
		//go to main menu
		SDL_Event userEvent;
		userEvent.type = SDL_USEREVENT;
		userEvent.user.code = 4;
		SDL_PushEvent(&userEvent);
	}
}