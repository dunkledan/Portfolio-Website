#pragma once
#include "GameScreenControls.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "LinkedList.h"
#include "Collisions.h"
#include <iostream>
#include "Button.h"

class GameScreenWin : public GameScreenControls
{
public:
	void Render(float Xoffset, float Yoffset);
	void Update(float deltaTime);
	void HandleEvents(SDL_Event e, float deltaTime);
	GameScreenWin(SDL_Renderer* renderer, Camera* cam);
	~GameScreenWin();

private:
	Button* m_congratsButton = nullptr;
	Button* m_continueButton = nullptr;
	bool m_mouseIsOnCongratsButton = false;
	bool m_mouseIsOnContinueButton = false;
	float m_buttonSpacing = 20;
	Camera* m_cam = nullptr;
	void InitButtons();
	void HandleButtonClicks(SDL_Event e);
};

