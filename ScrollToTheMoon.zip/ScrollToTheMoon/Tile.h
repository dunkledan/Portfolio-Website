#pragma once
#include "Texture2D.h"
#include "Commons.h"

//tile specific enums
enum class TileType
{
	None,
	Platform,
	Ground,
	Lava
};

enum CollisionType
{
	Impassable,
	Passable
};

class Tile
{
	public:
		Tile(Texture2D* texture, TileType  type, Vector2D position, CollisionType collisionType);
		~Tile();
		Texture2D* m_texture = nullptr;
		Vector2D m_position;
		void Render(float Xoffset, float Yoffset);
		static const int TILE_WIDTH;
		static const int TILE_HEIGHT;
		TileType m_tileType;
		CollisionType m_collisionType;

};

