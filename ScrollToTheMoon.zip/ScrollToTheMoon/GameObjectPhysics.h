#pragma once
#include "GameObject.h"

class GameObjectPhysics
{
	private:
		float m_xVelocity = 0;
		float m_yVelocity = 0;
		GameObject* m_object = nullptr;
		float m_gravityForce = 0;

	public:
		GameObjectPhysics(GameObject* object);
		~GameObjectPhysics();
		void UpdateVelocities(float deltaTime);
		void SetVelocity(Vector2D vel);
		Vector2D GetVelocity() {return Vector2D(m_xVelocity, m_yVelocity);};
		void AddVelocity(Vector2D vel);
		void ApplyGravity(float deltaTime) { m_yVelocity += m_gravityForce * deltaTime; };
};

