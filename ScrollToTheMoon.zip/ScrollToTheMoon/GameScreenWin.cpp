#include "GameScreenWin.h"

GameScreenWin::GameScreenWin(SDL_Renderer* renderer, Camera* cam) : GameScreenControls(renderer,cam)
{
	m_buttonsList.ClearList();
	InitButtons();
	m_currentButtonIndex = 0;
	m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetHovered(true);
}

GameScreenWin::~GameScreenWin()
{
	delete m_congratsButton;
	m_congratsButton = nullptr;
	m_buttonsList.ClearList();
	delete m_continueButton;
	m_continueButton = nullptr;
}

void GameScreenWin::Render(float Xoffset, float Yoffset)
{
	m_backgroundTexture->Render(Vector2D(Xoffset, Yoffset), SDL_FLIP_NONE);
	m_congratsButton->Render(Xoffset, Yoffset);
	m_continueButton->Render(Xoffset, Yoffset);
}

void GameScreenWin::Update(float deltaTime)
{
	m_congratsButton->Update(deltaTime);
	m_continueButton->Update(deltaTime);
}

void GameScreenWin::HandleEvents(SDL_Event e, float deltaTime)
{
	GameScreenControls::HandleEvents(e,deltaTime);
}

/// <summary>
/// initialises buttons on the  screen
/// </summary>
void GameScreenWin::InitButtons()
{
	m_congratsButton = new Button(m_renderer, m_cam, Vector2D((SCREEN_WIDTH / 4), (SCREEN_HEIGHT / 4)), "YOU BEAT LEVEL 1", 24, SDL_Color{ 0,48,143,1 }, SDL_Color{ 0,0,0,0 });
	m_continueButton = new Button(m_renderer, m_cam, Vector2D(m_congratsButton->GetPos().x, m_congratsButton->GetPos().y + m_buttonSpacing), "Continue", 24, SDL_Color{ 85,153,0,1 }, SDL_Color{ 0,0,0,0 });
	m_buttonsList.Push(m_continueButton);
}

/// <summary>
/// if a button is clicked/selected push appropriate event
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenWin::HandleButtonClicks(SDL_Event e)
{
	if (m_continueButton->IsClicked(e))
	{
		//go to next level
		SDL_Event userEvent;
		userEvent.type = SDL_USEREVENT;
		userEvent.user.code = 6;
		SDL_PushEvent(&userEvent);
	}
}