#pragma once
#include "GameScreen.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "MysteryBox.h"
#include "LinkedList.h"
#include "Enemy.h"
#include "Coin.h"
#include "ExitDoor.h"
#include <iostream>
#include "GameScreenLevel1.h"

class GameScreenLevel2 : GameScreenLevel1
{
private:
	SDL_Renderer* m_renderer = nullptr;
	void InitGameObjects() override;
	void HandleCharacterGameObjectCollisions() override;

public:
	GameScreenLevel2(SDL_Renderer* renderer, Camera* cam);
	~GameScreenLevel2();
	void Render(float Xoffset, float Yoffset);
	void Update(float deltaTime);
	void HandleEvents(SDL_Event e, float deltaTime);
};