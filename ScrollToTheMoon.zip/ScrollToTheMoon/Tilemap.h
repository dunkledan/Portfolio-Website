#pragma once
#include <vector>
#include <map>
#include "SDL.h"
#include "Tile.h"
#include <fstream>

class Tilemap
{
	private:
		Vector2D m_position;
		std::map<TileType, Texture2D*>* m_TileTexturesMapping = nullptr;
		int** m_tileMapIndices = nullptr;
		std::vector<std::vector<Tile*>>* m_tileObjects = nullptr;
		bool ShowErrorAndCloseFile(std::ifstream& stream, const std::string& msg);

	public:
		void SetPosition(const Vector2D& position) {this->m_position = position;};
		void Render(float Xoffset, float Yoffset);
		void AddTileTexture(TileType type, Texture2D* tileTexture) {(*m_TileTexturesMapping)[type] = tileTexture;};
		void InitTileObjects();
		Tile* GetTile(int x, int y);
		void SetTile(int x, int y, TileType value) {m_tileMapIndices[x][y] = (int)value;};
		bool LoadFromFile(const std::string& path);
		Vector2D WorldToGridPosition(const Vector2D& input);
		//public members
		int m_rows = 0;
		int m_cols = 0;
		Tilemap(int rows, int cols, const Vector2D& position);
		~Tilemap();
		bool CheckTileInBounds(int x, int y);
};

