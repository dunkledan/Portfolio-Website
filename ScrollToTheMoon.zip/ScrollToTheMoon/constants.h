#pragma once

//screen dimensions
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 480

//game world dimensions
#define LEVEL_WIDTH 6000
#define LEVEL_HEIGHT 416

//other global defininitions
#define MOVEMENT_SPEED 9
#define JUMP_SPEED 50
#define SCROLL_SPEED 4