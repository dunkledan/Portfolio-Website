#pragma once
#include <SDL.h>
#include "constants.h"
#include "Commons.h"

class Camera
{
	private:
		float m_Xoffset;
		float m_Yoffset;
		float m_width;
		float m_height;
		Rect2D* m_cameraViewPort = nullptr;

	public:
		Camera(float w, float h, float m_Xoffset, float m_Yoffset);
		~Camera();
		void SetOffSet(float Xoffset, float XYoffset);
		Vector2D GetOffSet() { return Vector2D(m_Xoffset, m_Yoffset); };
		Rect2D* GetViewPort() { return m_cameraViewPort; };
};

