#include "GameScreenControls.h"

GameScreenControls::GameScreenControls(SDL_Renderer* renderer, Camera* cam) : GameScreenMenu(renderer,cam)
{
	m_buttonsList.ClearList();
	InitButtons();
	m_currentButtonIndex = 0;
	m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetHovered(true);
}

GameScreenControls::~GameScreenControls()
{
}

void GameScreenControls::Render(float Xoffset, float Yoffset)
{
	m_backgroundTexture->Render(Vector2D(Xoffset, Yoffset), SDL_FLIP_NONE);
	m_controlsTitleButton->Render(Xoffset,Yoffset);
	m_controlsButton->Render(Xoffset, Yoffset);
	m_backButton->Render(Xoffset, Yoffset);
}

void GameScreenControls::Update(float deltaTime)
{
	m_controlsTitleButton->Update(deltaTime);
	m_controlsButton->Update(deltaTime);
	m_backButton->Update(deltaTime);
}

void GameScreenControls::HandleEvents(SDL_Event e, float deltaTime)
{
	ButtonSelect(e);
}

void GameScreenControls::ButtonSelect(SDL_Event e)
{
	switch (e.type)
	{
	case SDL_JOYBUTTONDOWN:
		switch (e.jbutton.button)
		{
		case 4:
			m_buttonsList.GetItemByIndex(m_currentButtonIndex)->SetClicked(true);
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	HandleButtonClicks(e);
}

/// <summary>
/// initialises buttons on the  screen
/// </summary>
void GameScreenControls::InitButtons()
{
	m_controlsTitleButton = new Button(m_renderer, m_cam, Vector2D((SCREEN_WIDTH / 4), (SCREEN_HEIGHT / 4)), "Controls", 24, SDL_Color{ 0,48,143, 255 }, SDL_Color{ 0,0,0,0 });
	m_controlsButton = new Button(m_renderer, m_cam, Vector2D(m_controlsTitleButton->GetPos().x, m_controlsTitleButton->GetPos().y + m_buttonSpacing), "Arrow Keys to move", 16, SDL_Color{ 50,106,218, 255}, SDL_Color{0,0,0,0});
	m_backButton = new Button(m_renderer, m_cam, Vector2D(m_controlsButton->GetPos().x, m_controlsButton->GetPos().y + m_buttonSpacing), "Back", 24, SDL_Color{ 85,153,0, 255 }, SDL_Color{ 0,0,0,0 });
	m_buttonsList.Push(m_backButton);
}

/// <summary>
/// if a button is clicked/selected push appropriate event
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenControls::HandleButtonClicks(SDL_Event e)
{
	if (m_backButton->IsClicked(e))
	{
		//go to menu
		SDL_Event userEvent;
		userEvent.type = SDL_USEREVENT;
		userEvent.user.code = 4;
		SDL_PushEvent(&userEvent);
	}
}