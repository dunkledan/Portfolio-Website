#include "GameScreenManager.h"
#include "GameScreen.h"
#include <iostream>
#include "GameScreenLevel1.h"
#include "GameScreenLevel2.h"
#include "Camera.h"
#include "GameScreenControls.h"
#include "GameScreenWin.h"
#include "GameScreenLoose.h"
#include "GameScreenCredits.h"

GameScreenManager::GameScreenManager(SDL_Renderer* renderer, SCREENS startScreen, Camera* cam)
{
	m_renderer = renderer;
	m_cam = cam;
	m_currentScreen = nullptr;
	ChangeScreen(startScreen);
}

GameScreenManager::~GameScreenManager()
{
	m_renderer = nullptr;
	delete m_currentScreen;
	m_currentScreen = nullptr;
}

/// <summary>
/// changes the screens based on known screens
/// </summary>
/// <param name="new_screen"></param>
void GameScreenManager::ChangeScreen(SCREENS new_screen)
{
	//destroys current screen state if it is not already null
	if (m_currentScreen != nullptr)
	{
		delete m_currentScreen;
		m_currentScreen = nullptr;
	}
	//load appropriate scene from appropriate script
	switch (new_screen)
	{
		case SCREEN_MENU:
			m_currentScreen = (GameScreen*)new GameScreenMenu(m_renderer, m_cam);
			break;

		case SCREEN_CONTROLS:
			m_currentScreen = (GameScreen*)new GameScreenControls(m_renderer, m_cam);
			break;

		case SCREEN_LEVEL1:
			m_currentScreen = (GameScreen*)new GameScreenLevel1(m_renderer, m_cam);
			break;

		case SCREEN_LEVEL2:
			m_currentScreen = (GameScreen*)new GameScreenLevel2(m_renderer, m_cam);
			break;

		case SCREEN_WIN:
			m_currentScreen = (GameScreen*)new GameScreenWin(m_renderer, m_cam);
			break;

		case SCREEN_LOOSE:
			m_currentScreen = (GameScreen*)new GameScreenLoose(m_renderer, m_cam);
			break;

		case SCREEN_CREDITS:
			m_currentScreen = (GameScreen*)new GameScreenCredits(m_renderer, m_cam);
			break;

		default:
			break;
	}
}

