#pragma once
#include "GameScreenMenu.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "LinkedList.h"
#include "Collisions.h"
#include <iostream>
#include "Button.h"

class GameScreenControls : public GameScreenMenu
{
public:
	GameScreenControls(SDL_Renderer* renderer, Camera* cam);
	~GameScreenControls();
	void Render(float Xoffset, float Yoffset) override;
	void Update(float deltaTime) override;
	void HandleEvents(SDL_Event e, float deltaTime) override;

private:
	Camera* m_cam = nullptr;
	Button* m_controlsTitleButton = nullptr;
	Button* m_controlsButton = nullptr;
	Button* m_backButton = nullptr;
	bool m_mouseIsOntitleButton = false;
	bool m_mouseIsOnControlsButton = false;
	bool m_mouseIsOnbackButton = false;
	float m_buttonSpacing = 20;
	void InitButtons();
	void HandleButtonClicks(SDL_Event e);
	void ButtonSelect(SDL_Event e);
};

