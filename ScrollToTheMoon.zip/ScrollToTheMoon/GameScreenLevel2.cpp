#include "GameScreenLevel2.h"
using namespace std;

GameScreenLevel2::GameScreenLevel2(SDL_Renderer* renderer, Camera* cam) : GameScreenLevel1(renderer, cam)
{
	delete m_character;
	m_character = nullptr;
	delete m_music;
	m_music = nullptr;
	m_cam = cam;
	m_path = "Data/level1.txt";
	m_gameObjectList.ClearList();
	GameScreenLevel1::SetUpLevel();
}

GameScreenLevel2::~GameScreenLevel2()
{
	delete m_backgroundTexture;
	m_backgroundTexture = nullptr;
	delete m_tileMap;
	m_tileMap = nullptr;
	delete m_music;
	m_music = nullptr;
	m_gameObjectList.ClearList();
}

void GameScreenLevel2::Render(float Xoffset, float Yoffset)
{
	if (m_character->m_isDead)
	{
		return;
	}
	GameScreenLevel1::Render(Xoffset, Yoffset);
}

void GameScreenLevel2::Update(float deltaTime)
{
	if (m_character->m_isDead)
	{
		return;
	}
	GameScreenLevel1::Update(deltaTime);

}

void GameScreenLevel2::HandleEvents(SDL_Event e, float deltaTime)
{
	GameScreenLevel1::HandleEvents(e, deltaTime);
}


/// <summary>
/// initialises all gameobjects
/// </summary>
void GameScreenLevel2::InitGameObjects()
{
	m_gameObjectList.ClearList();
	//setup GameObjects
	m_character = new Character(m_renderer, m_characterTexture, Vector2D(100, 300), m_tileMap);
	m_gameObjectList.Push(m_character);
	//setup and store all gameObjects and children instances in a single linked list
	m_gameObjectList.Push(new MysteryBox(m_renderer, m_mysteryBoxTexture, Vector2D(11 * Tile::TILE_WIDTH, 7 * Tile::TILE_HEIGHT), Random));
	m_gameObjectList.Push(new MysteryBox(m_renderer, m_mysteryBoxTexture, Vector2D(60 * Tile::TILE_WIDTH, 8 * Tile::TILE_HEIGHT), Random));
	m_gameObjectList.Push(new Enemy(m_renderer, m_enemyTexture, Vector2D(40 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT), m_tileMap, 64, -64));
	m_gameObjectList.Push(new Enemy(m_renderer, m_enemyTexture, Vector2D(63 * Tile::TILE_WIDTH, 8 * Tile::TILE_HEIGHT), m_tileMap, 128, -128));
	m_gameObjectList.Push(new Enemy(m_renderer, m_enemyTexture, Vector2D(95 * Tile::TILE_WIDTH, 6 * Tile::TILE_HEIGHT), m_tileMap, 64, -64));
	m_gameObjectList.Push(new Enemy(m_renderer, m_enemyTexture, Vector2D(100 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT), m_tileMap, 64, -64));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(6 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(18 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(18 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(23 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(40 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT + 10)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(43 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT + 10)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(40 * Tile::TILE_WIDTH, 7 * Tile::TILE_HEIGHT + 10)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(40 * Tile::TILE_WIDTH, 7 * Tile::TILE_HEIGHT + 10)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(82 * Tile::TILE_WIDTH, 10 * Tile::TILE_HEIGHT + 10)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(120 * Tile::TILE_WIDTH, 8 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new ExitDoor(m_renderer, m_exitDoorTexture, Vector2D(125 * Tile::TILE_WIDTH, 8 * Tile::TILE_HEIGHT)));
	GameScreenLevel1::MapCharacterPowerUpTextures();
}

void GameScreenLevel2::HandleCharacterGameObjectCollisions()
{
	//Check if character exists to avoid nullptr access error
	if (m_character != nullptr)
	{
		//walk gameObjectList
		auto node = m_gameObjectList.GetHead();
		while (node != nullptr)
		{
			auto nextNode = node->next;
			//check for tags
			//mystery box collision handling
			if (node->data->m_tag == "MysteryBox")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					MysteryBox* current = dynamic_cast<MysteryBox*>(node->data);
					//set player powerup
					current->SetPowerup(m_character);
					//detroy box now its used + remove from gameobject list
					m_gameObjectList.RemoveItemByPointer(node->data);
					delete current;
					current = nullptr;
				}
			}
			//enemy collision handling
			else if (node->data->m_tag == "Enemy")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					m_character->TakeDamage();
				}
			}
			//coin collisions
			else if (node->data->m_tag == "Coin")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					Coin* current = dynamic_cast<Coin*>(node->data);
					current->PlayPickup();
					m_score++;
					m_gameObjectList.RemoveItemByPointer(node->data);
					delete current;
					current = nullptr;
				}
			}
			//exit door collision
			else if (node->data->m_tag == "ExitDoor")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					ExitDoor* current = dynamic_cast<ExitDoor*>(node->data);
					current->PlayWin();
					SDL_Event userEvent;
					userEvent.type = SDL_USEREVENT;
					userEvent.user.code = 8;
					SDL_PushEvent(&userEvent);
				}
			}
			node = nextNode;
		}
	}
}