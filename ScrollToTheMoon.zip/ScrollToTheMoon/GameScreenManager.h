#pragma once
#include <SDL.h>
#include "Commons.h"
#include "Camera.h"
#include "GameScreenMenu.h"

//class forawrd declartions
class GameScreen;
class GameScreenMenu;
class GameScreenControls;
class GameScreenLevel1;
class GameScreenLevel2;
class GameScreenWin;
class GameScreenLoose;
class GameScreenCredits;

class GameScreenManager
{
	private:
		Camera* m_cam = nullptr;
		SDL_Renderer* m_renderer = nullptr;
		GameScreen* m_currentScreen = nullptr;

	public:
		GameScreenManager(SDL_Renderer* renderer, SCREENS startScreen, Camera* cam);
		~GameScreenManager();
		void Render(float Xoffset, float Yoffset) {m_currentScreen->Render(Xoffset, Yoffset);};
		void Update(float deltaTime) { m_currentScreen->Update(deltaTime); };
		void HandleEvents(SDL_Event e, float deltaTime) { m_currentScreen->HandleEvents(e, deltaTime); };
		void ChangeScreen(SCREENS new_screen);
};

