#include "Tilemap.h"
#include <iostream>

/// <summary>
/// renders all tiles in size of tilemap at appropriate world positions relitive to start of tilemap
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void Tilemap::Render(float Xoffset, float Yoffset)
{
	for (int i = 0; i < m_rows; i++)
	{
		for (int j = 0; j < m_cols; j++)
		{
			//if tile should be rendered
			if (GetTile(j, i)->m_tileType != TileType::None) 
			{
				//render tile at position
				GetTile(j, i)->Render(Xoffset, Yoffset);
			}
		}
	}
}

Tilemap::Tilemap(int rows, int cols, const Vector2D& position)
{
	m_rows = rows;
	m_cols = cols;
	m_position = position;
	m_TileTexturesMapping = new std::map<TileType, Texture2D*>();
	//setup pointer to position of tiles in this tilemap
	m_tileObjects = new std::vector<std::vector<Tile*>>(m_cols, std::vector<Tile*>(m_rows));
	//init column of tilemap as empty
	m_tileMapIndices = new int* [cols]();
	//init rows as empty 
	for (int i = 0; i < cols; i++)
	{
		m_tileMapIndices[i] = new int[rows]();
	}
}

Tilemap::~Tilemap()
{
	m_TileTexturesMapping->clear();
	delete m_TileTexturesMapping;
	m_TileTexturesMapping = nullptr;
	//deletes each index of the tile map and frees its memory on destruction
	for (int i = 0; i < m_cols; i++)
	{
		delete m_tileMapIndices[i];
		m_tileMapIndices[i] = nullptr;
	}
	m_tileMapIndices = nullptr;
	//free each tilemap tile object in the tilemap
	for (auto i = m_tileObjects->begin(); i != m_tileObjects->end(); i++)
	{
		for (auto j = i->begin(); j != i->end(); j++)
		{
			delete* j;
		}
	}
}

/// <summary>
/// initialises all tiles relevant to thier specific tile type and texture on the tilemap 
/// </summary>
void Tilemap::InitTileObjects()
{
	for (int i = 0; i < m_rows; i++)
	{
		for (int j = 0; j < m_cols; j++)
		{
			//position of tile at index on screen
			int x = m_position.x + Tile::TILE_WIDTH * j;
			int y = m_position.y + Tile::TILE_HEIGHT * i;
			Texture2D* tempTex = nullptr;
			//gets tile type for tile at position and checks if it is none as to wether or not to give that tile a texture
			int idx = m_tileMapIndices[j][i];
			TileType currentTileType = (TileType)idx;
			if (currentTileType != TileType::None)
			{
				tempTex = (*m_TileTexturesMapping)[currentTileType];
			}
			//define type of collision for specific tile 
			CollisionType collType = (idx == 0) ? (CollisionType::Passable) : (CollisionType::Impassable);
			(*m_tileObjects)[j][i] = new Tile(tempTex, currentTileType,  Vector2D(x,y),collType);
		}
	}
}

/// <summary>
/// returns a tile at a grid position
/// </summary>
/// <param name="x"></param>
/// <param name="y"></param>
/// <returns></returns>
Tile* Tilemap::GetTile(int x, int y)
{
	if (CheckTileInBounds(x,y))
	{
		return (*m_tileObjects)[x][y];
	}
	return new Tile(nullptr, TileType::Lava, Vector2D(x, y), CollisionType::Passable);
}

/// <summary>
/// if there is an error reading the file, displays reason why it could not read the file
/// </summary>
/// <param name="stream"></param>
/// <param name="msg"></param>
/// <returns></returns>
bool Tilemap::ShowErrorAndCloseFile(std::ifstream& stream, const std::string& msg)
{
	std::cerr << "File stream reading error: could not read file at path: " << msg;
	stream.close();
	return false;
}

/// <summary>
/// load tile map from a file path with correct file structure
/// </summary>
/// <param name="path"></param>
/// <returns></returns>
bool Tilemap::LoadFromFile(const std::string& path)
{
	//open file
	std::ifstream file(path);
	if (!file.is_open())
	{
		return ShowErrorAndCloseFile(file, path);
	}
	std::string line;
	int lineCount = 0;
	char currentCharacter = ' ';
	int tileType = 0;
	while (getline(file, line))
	{
		//for each character in line
		for (int currentCol = 0; currentCol < m_cols; currentCol++)
		{
			currentCharacter = line[currentCol];
			//if past the cols specified in tilemap init
			if ((currentCol >= m_cols) || (lineCount >= m_rows) || (!isdigit(currentCharacter)))
			{
				return ShowErrorAndCloseFile(file, path);
			}
			tileType = currentCharacter - '0';
			//if not blank tile
			if (tileType != 0)
			{
				//checks if mapping exists in file, returns error if not mapped
				if (m_TileTexturesMapping->find((TileType)tileType) == m_TileTexturesMapping->end())
				{
					return ShowErrorAndCloseFile(file, path);
				}
				m_tileMapIndices[currentCol][lineCount] = tileType;
			}
		}
		lineCount++;
	}
	file.close();
	return true;
}

/// <summary>
/// converts a world position to a tilemap position
/// </summary>
/// <param name="input"></param>
/// <returns></returns>
Vector2D Tilemap::WorldToGridPosition(const Vector2D& input)
{
	int calcX = m_position.x + int(input.x / Tile::TILE_WIDTH);
	int calcY = m_position.y + int(input.y / Tile::TILE_HEIGHT);
	return Vector2D(calcX,calcY);
}

/// <summary>
/// checks if a position is within the tilemap
/// </summary>
/// <param name="x"></param>
/// <param name="y"></param>
/// <returns></returns>
bool Tilemap::CheckTileInBounds(int x, int y)
{
	//if tile is in bounds return true
	if (x >= 0 && y >= 0 && x < m_cols && y < m_rows)
	{
		return true;
	}
	return false;
}