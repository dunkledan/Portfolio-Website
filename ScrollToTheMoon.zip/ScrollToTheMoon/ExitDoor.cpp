#include "ExitDoor.h"

ExitDoor::ExitDoor(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D startPosition) : GameObject(renderer, baseTexture, startPosition)
{
	m_tag = "ExitDoor";
}

/// <summary>
/// initialises Jump audio
/// </summary>
void ExitDoor::InitAudio()
{
	m_SFX_Win = new Audio("AudioFiles/SFX_Win.wav");
	m_SFX_Win->SetVolume(100);
}

void ExitDoor::HandleEvents(SDL_Event e)
{
}

ExitDoor::~ExitDoor()
{
	delete m_SFX_Win;
	m_SFX_Win = nullptr;
}