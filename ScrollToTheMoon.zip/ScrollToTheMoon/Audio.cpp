#include "Audio.h"

Audio::Audio(std::string path)
{
	m_channel = -1;
	m_chunk = nullptr;
	LoadFromFile(path);
}

Audio::~Audio()
{
	Mix_FreeChunk(m_chunk);
	m_chunk = nullptr;
}

/// <summary>
/// plays audio if not already playing
/// </summary>
/// <param name="loopNum"></param>
void Audio::Play(int loopNum)
{
	if (!m_chunk)
	{
		std::cerr << "failed to play audio" << std::endl;
		return;
	}
	if (m_channel != -1 && Mix_Playing(m_channel))
	{
		return;
	}
	m_channel = Mix_PlayChannel(-1, m_chunk, loopNum);
}


/// <summary>
/// loads an audio chunk from a specifided file path
/// </summary>
/// <param name="path"></param>
void Audio::LoadFromFile(std::string path)
{
	//saves audio file as a chunk to be assembled into ram
	m_chunk = Mix_LoadWAV(path.c_str());
	if (!m_chunk)
	{
		std::cerr << "could not load audio with path: " << path;
		return;
	}
}
