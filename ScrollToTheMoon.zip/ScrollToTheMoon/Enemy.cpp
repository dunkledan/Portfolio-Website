#include "Enemy.h"

Enemy::Enemy(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D start_position, Tilemap* tmap, float point1, float point2) : GameObject(renderer, baseTexture, start_position)
{
	m_tag = "Enemy";
	m_physicsSystem = new GameObjectPhysics(this);
	m_falling = true;
	m_tileMap = tmap;
	m_patrolPoint1 = new GameObject(renderer, m_texture, Vector2D(start_position.x + point1, start_position.y));
	m_patrolPoint2 = new GameObject(renderer, m_texture, Vector2D(start_position.x + point2, start_position.y));
	m_target = m_patrolPoint1;
}

/// <summary>
/// handles basic enemy AI movement
/// </summary>
void Enemy::MoveToCurrentTarget()
{
	if (Collisions::Instance()->Circle(this, m_target))
	{
		if (m_target == m_patrolPoint1)
		{
			m_target = m_patrolPoint2;
		}
		else
		{
			m_target = m_patrolPoint1;
		}
	}
	else
	{
		float direction = GetPosition().x - m_target->GetPosition().x;
		if (direction < 0)
		{
			direction = 1.0f;
		}
		else
		{
			direction = -1.0f;
		}
		m_physicsSystem->SetVelocity(Vector2D(m_speed * direction, m_physicsSystem->GetVelocity().y));
	}
}

Enemy::~Enemy()
{
	delete m_physicsSystem;
	m_physicsSystem = nullptr;
	delete m_patrolPoint1;
	m_patrolPoint1 = nullptr;
	delete m_patrolPoint2;
	m_patrolPoint2 = nullptr;
}

/// <summary>
/// Handles enemy tile map collisions
/// </summary>
void Enemy::HandleTileMapCollisions()
{
	Rect2D box = GetCollisionBox();
	Vector2D gridPos = m_tileMap->WorldToGridPosition(Vector2D(box.x, box.y));
	//check player and tilemap collision
	bool collidingDown = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(0, 1)) || Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, Rect2D(box.x + box.width - 1, box.y + 1, 1, box.height), Vector2D(0, 1));
	bool collidingUp = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(0, 0)) || Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, Rect2D(box.x + box.width - 1, box.y, 1, box.height), Vector2D(0, 0));
	bool collidingRight = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(1, 0));
	bool collidingLeft = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(-1, 0));
	//ground check
	Rect2D groundCheckBox = GetCollisionBox();
	groundCheckBox.y += 1;
	bool groundCheck = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, groundCheckBox, Vector2D(0, 1));
	if (!groundCheck)
	{
		SetFallingState(true);
	}
	//handle specific case tilemap collision, DO NOT USE SWITCH CASE AS MULTIPLE CAN BE THE CASE IN THE SAME FRAME
	if (collidingDown)
	{
		HandleTileMapDownCollision(box, gridPos);
	}
	if (collidingUp)
	{
		HandleTileMapUpCollision(box, gridPos);
	}
	if (collidingRight)
	{
		HandleTileMapRightCollision(box, gridPos);
	}
	if (collidingLeft)
	{
		HandleTileMapLeftCollision(box, gridPos);
	}
}

/// <summary>
/// handles enemy down tile map collisions
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Enemy::HandleTileMapDownCollision(Rect2D box, Vector2D gridPos)
{
	//Correcting Tile values calculation
	//down
	Vector2D downCollisionGridPos = Vector2D(gridPos.x, gridPos.y + 1);
	Tile* downCollisionTile = m_tileMap->GetTile((int)downCollisionGridPos.x, (int)downCollisionGridPos.y);
	Vector2D downCollisionWorldPos = downCollisionTile->m_position;
	float downCorrectedY = downCollisionWorldPos.y - box.height;
	//position and velocity correction 
	SetPosition(Vector2D(box.x, downCorrectedY));
	m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x, 0));
	SetFallingState(false);
}

/// <summary>
/// handles enemy up tile map collisions
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Enemy::HandleTileMapUpCollision(Rect2D box, Vector2D gridPos)
{
	//Correcting Tile values calculation
	//up
	Vector2D upCollisionGridPos = Vector2D(gridPos.x, gridPos.y);
	Tile* upCollisionTile = m_tileMap->GetTile((int)upCollisionGridPos.x, (int)upCollisionGridPos.y);
	Vector2D upCollisionWorldPos = upCollisionTile->m_position;
	float upCorrectedY = upCollisionWorldPos.y + Tile::TILE_HEIGHT;
	//position and velocity correction 
	SetPosition(Vector2D(box.x, upCorrectedY));
	m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x, 0));
}

/// <summary>
/// handles enemy left tile map collisions
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Enemy::HandleTileMapLeftCollision(Rect2D box, Vector2D gridPos)
{
	//Correcting Tile values calculation
	//left
	Vector2D leftCollisionGridPos = Vector2D(gridPos.x + 1, gridPos.y);
	Tile* leftCollisionTile = m_tileMap->GetTile((int)leftCollisionGridPos.x, (int)leftCollisionGridPos.y);
	Vector2D leftCollisionWorldPos = leftCollisionTile->m_position;
	float leftCorrectedX = leftCollisionWorldPos.x + 1;
	//position and velocity correction 
	SetPosition(Vector2D(leftCorrectedX, box.y));
	m_physicsSystem->SetVelocity(Vector2D(0, m_physicsSystem->GetVelocity().y));
}

/// <summary>
/// handles enemy right tile map collisions
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Enemy::HandleTileMapRightCollision(Rect2D box, Vector2D gridPos)
{
	//Correcting Tile values calculation
	//right
	Vector2D rightCollisionGridPos = Vector2D(gridPos.x + 1, gridPos.y);
	Tile* rightCollisionTile = m_tileMap->GetTile((int)rightCollisionGridPos.x, (int)rightCollisionGridPos.y);
	Vector2D rightCollisionWorldPos = rightCollisionTile->m_position;
	float rightCorrectedX = rightCollisionWorldPos.x - Tile::TILE_WIDTH;
	//position and velocity correction 
	SetPosition(Vector2D(rightCorrectedX, box.y));
	m_physicsSystem->SetVelocity(Vector2D(0, m_physicsSystem->GetVelocity().y));
}

void Enemy::Update(float deltaTime)
{
	HandleTileMapCollisions();
	MoveToCurrentTarget();
	if (m_falling)
	{
		m_physicsSystem->ApplyGravity(deltaTime);
	}
	else
	{
		//sets to 0 when collides with a floor
		m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x, 0));
	}
	m_physicsSystem->UpdateVelocities(deltaTime);
	PlayAnimationFrame(deltaTime);
}

void Enemy::HandleEvents(SDL_Event e, float deltaTime)
{
}

void Enemy::Render(float Xoffset, float Yoffset)
{
	if (m_physicsSystem->GetVelocity().x < 0)
	{
		m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), SDL_FLIP_HORIZONTAL);
	}
	else
	{
		m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), SDL_FLIP_NONE);
	}
}