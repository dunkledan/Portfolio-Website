#pragma once
#include "GameScreen.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "MysteryBox.h"
#include "LinkedList.h"
#include "Enemy.h"
#include "Coin.h"
#include "ExitDoor.h"
#include <iostream>
#include "Button.h"

class GameScreenLevel1 : GameScreen
{
	protected:
		Audio* m_music = nullptr;
		Character* m_character = nullptr;
		Button* m_scoreButton = nullptr;
		Tilemap* m_tileMap = nullptr;
		Texture2D* m_backgroundTexture = nullptr;
		Texture2D* m_tile1Texture = nullptr;
		Texture2D* m_tile2Texture = nullptr;
		Texture2D* m_tile3Texture = nullptr;
		Texture2D* m_characterTexture = nullptr;
		Texture2D* m_characterTexture2 = nullptr;
		Texture2D* m_characterTextureJump = nullptr;
		Texture2D* m_doubleJumpPowerTexture = nullptr;
		Texture2D* m_helmetPowerTexture = nullptr;
		Texture2D* m_helmetPowerTextureJump = nullptr;
		Texture2D* m_helmetPowerTexture2 = nullptr;
		Texture2D* m_ClimbPowerTexture = nullptr;
		Texture2D* m_doubleJumpPowerJump = nullptr;
		Texture2D* m_ClimbPowerTexture2 = nullptr;
		Texture2D* m_ClimbPowerTextureJump2 = nullptr;
		Texture2D* m_ClimbPowerTextureJump3 = nullptr;
		Texture2D* m_mysteryBoxTexture = nullptr;
		Texture2D* m_enemyTexture = nullptr;
		Texture2D* m_enemyTexture2 = nullptr;
		Texture2D* m_helmetRegen = nullptr;
		Texture2D* m_helmetTakeDamage = nullptr;
		Texture2D* m_coinTexture = nullptr;
		Texture2D* m_coinTexture2 = nullptr;
		Texture2D* m_coinTexture3 = nullptr;
		Texture2D* m_exitDoorTexture = nullptr;
		Texture2D* m_DoubleJump2 = nullptr;
		Texture2D* m_DoubleJump3 = nullptr;
		Camera* m_cam = nullptr;
		bool SetUpLevel();
		bool LoadGameTextures(); 
		void InitGameScreenAudio();
		virtual void InitGameObjects();
		void InitText() { delete m_scoreButton; m_scoreButton = new Button(m_renderer, m_cam, Vector2D(50, 50), "Score: 0", 16, SDL_Color{ 0,0,255,255 }, SDL_Color{ 255,255,255,255 }); };
		bool InitTileMap(std::string path);
		void HandleGameObjectCollisions();
		void MapCharacterPowerUpTextures();
		void HandleTileMapDownCollision(Rect2D box, Vector2D gridPos);
		void HandleTileMapUpCollision(Rect2D box, Vector2D gridPos);
		void HandleTileMapLeftCollision(Rect2D box, Vector2D gridPos);
		void HandleTileMapRightCollision(Rect2D box, Vector2D gridPos);
		void KeepPlayerOnScreen();
		void UpdateGameObjects(float deltaTime);
		virtual void HandleCharacterGameObjectCollisions();
		LinkedList<GameObject> m_gameObjectList = LinkedList<GameObject>();
		int m_score = 0;
		void InitGameObjectAnims();
		std::string m_path = "Data/Tutorial.txt";

	public:
		GameScreenLevel1(SDL_Renderer* renderer, Camera* cam);
		~GameScreenLevel1();
		void Render(float Xoffset, float Yoffset) override;
		void Update(float deltaTime) override;
		void HandleEvents(SDL_Event e, float deltaTime) override;

};