#pragma once
#include "Commons.h"
#include "Tilemap.h"

//forward declare GameObject class
class GameObject;

class Collisions
{
	public:
		~Collisions();
		static Collisions* Instance();
		bool Circle(GameObject* a, GameObject* b);
		bool Box(GameObject* a, GameObject* b);
		bool Box(Rect2D a, Rect2D b);
		bool TileMapCheckAdjacentTile(Tilemap* tilemap, Rect2D rect, Vector2D adjacencyOffset);

	private:
		Collisions();
		static Collisions* m_instance;

};

