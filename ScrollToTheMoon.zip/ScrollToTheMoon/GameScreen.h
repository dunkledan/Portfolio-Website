#pragma once
#include <SDL.h>
#include "Camera.h"
#include "Commons.h"
#include "Texture2D.h"
#include <iostream>
#include "LinkedList.h"
#include <vector>

//enum declarations
enum TextureLoadStatus
{
	Fail,
	Ok
};

class GameScreen
{
	protected:
		TextureLoadStatus TryLoadTexture(Texture2D*& texturePtr, const std::string& inputPath);
		SDL_Renderer* m_renderer = nullptr;

	public:
		GameScreen(SDL_Renderer* renderer);
		virtual ~GameScreen();
		virtual void Render(float Xoffset, float Yoffset);
		virtual void Update(float deltaTime);
		virtual void HandleEvents(SDL_Event e, float deltaTime);
};

