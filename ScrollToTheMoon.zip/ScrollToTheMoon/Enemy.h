#pragma once
#include "GameObject.h"
#include "Tilemap.h"
#include "Collisions.h"
#include "GameObjectPhysics.h"

class Enemy : public GameObject
{
public:

	virtual void Update(float deltaTime) override;
	virtual void HandleEvents(SDL_Event e, float deltaTime) override;
	virtual void Render(float Xoffset, float Yoffset) override;
	Enemy(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D start_position, Tilemap* tmap, float point1, float point2);
	~Enemy();
	void HandleTileMapCollisions();
	void HandleGameObjectCollision(); 
	void HandleTileMapDownCollision(Rect2D box, Vector2D gridPos);
	void HandleTileMapUpCollision(Rect2D box, Vector2D gridPos);
	void HandleTileMapRightCollision(Rect2D box, Vector2D gridPos);
	void HandleTileMapLeftCollision(Rect2D box, Vector2D gridPos);
	void SetFallingState(bool state) { m_falling = state;  };
	void MoveToCurrentTarget();
	GameObjectPhysics* m_physicsSystem = nullptr;
	GameObject* m_patrolPoint1 = nullptr;
	GameObject* m_patrolPoint2 = nullptr;
	GameObject* m_target = nullptr;

private:
	Tilemap* m_tileMap = nullptr;
	bool m_falling;
	float m_speed = 10;
};

