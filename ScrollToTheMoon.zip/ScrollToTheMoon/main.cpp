#include <SDL.h>
#include "GameScreenManager.h"
#include "constants.h"
#include "Texture2D.h"
#include "Commons.h"
#include <SDL_image.h>
#include <iostream>
#include "GameObject.h"
#include <SDL_ttf.h>
#include "Audio.h"
#include "Camera.h"

using namespace std;

//forward Declarations
void InitSDL();
void CloseSDL();
void Render(float Xoffset, float Yoffset);
void InitImgLoading();
void Update();
void HandleUserSDLEvents(SDL_Event e);
//global variables
SDL_Window* window = nullptr;
SDL_Renderer* renderer = nullptr;
GameScreenManager* game_screen_manager;
Uint32 g_old_time;
bool isRunning = false;
Camera* cam = new Camera(SCREEN_WIDTH,SCREEN_HEIGHT,0,0);
float refreshRate = 0;

int main(int argc, char** argv)
{
    InitSDL();
    //sets time
    g_old_time = SDL_GetTicks();
    //update
    isRunning = true;
    Update();
    CloseSDL();
    //ends program
    return 0;
}

void Update()
{

    while (isRunning)
    {
        SDL_Event e;
        Uint32 new_time = SDL_GetTicks();
        float deltaTime = (new_time - g_old_time) / refreshRate;
        g_old_time = new_time;
        while (SDL_PollEvent(&e))
        {
            //handle events on screen first
            game_screen_manager->HandleEvents(e, deltaTime);
            switch (e.type)
            {
            case SDL_USEREVENT:
                HandleUserSDLEvents(e);
                break;

            case SDL_WINDOWEVENT:
                break;

            case SDL_QUIT:
                isRunning = false;
                break;
            }
        }
        //handles updates and rendering every frame after events polled
        game_screen_manager->Update(deltaTime);
        Render(cam->GetOffSet().x, cam->GetOffSet().y);
    }
}

void HandleUserSDLEvents(SDL_Event e)
{
    switch (e.user.code)
    {
        case 0:
        {
            //game over
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_LOOSE);
            break;
        }
        case 1:
        {
            //Level Complete
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_WIN);
            break;
        }
        case 2:
        {
            //Go to level 1
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_LEVEL1);
            break;
        }
        case 3:
        {
            //Go to level 1
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_CONTROLS);
            break;
        }
        case 4:
        {
            //Go to menu
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_MENU);
            break;
        }
        case 5:
        {
            //Go to win screen
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_WIN);
            break;
        }
        case 6:
        {
            //Go to level 2
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_LEVEL2);
            break;
        }
        case 7:
        {
            //Go to level 2
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_LOOSE);
            break;
        }
        case 8:
        {
            //Go to credits
            cam->SetOffSet(0, 0);
            game_screen_manager->ChangeScreen(SCREEN_CREDITS);
            break;
        }
        default:
        {
            break;
        }
    }
}

void InitSDL()
{
    Mix_AllocateChannels(32);
    SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "1");
    //initialise text rendering
    TTF_Init();
    //audio init
    SDL_Init(SDL_INIT_AUDIO);
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
    {
        cout << "Mixer could not initialise, Error: " << Mix_GetError();
    }
    //sdl fails to load controls
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER | SDL_INIT_EVENTS) < 0) 
    {
        cerr << "SDL init failed with error: " << SDL_GetError() << endl;
        exit(1);
    }
    SDL_JoystickOpen(1);
    SDL_DisplayMode displayMode;
    SDL_GetCurrentDisplayMode(0, &displayMode);
    refreshRate = displayMode.refresh_rate;
    //initialise window
    window = SDL_CreateWindow("", 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_BORDERLESS);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    //renderer fails to load
    if (renderer == NULL) 
    {
        cerr << "Cannot create renderer.\n";
        SDL_DestroyWindow(window);
        exit(1);
    }
    game_screen_manager = new GameScreenManager(renderer, SCREEN_MENU, cam);
    InitImgLoading();
}

void CloseSDL()
{
    delete game_screen_manager;
    game_screen_manager = nullptr;
    delete cam;
    cam = nullptr;
    //destroy renderer
    SDL_DestroyRenderer(renderer);
    renderer = nullptr;
    //destroy window
    SDL_DestroyWindow(window);
    window = nullptr;
    //quits sdl
    SDL_Quit();
}

void InitImgLoading()
{
    if (renderer != nullptr)
    {
        int imageFlags = IMG_INIT_PNG;
        if (!(IMG_Init(imageFlags)& imageFlags))
        {
            cerr << "SDL_Image could not initialise. Error: " << IMG_GetError() << endl;
            exit(1);
        }
    }
    else
    {
        cerr << "Renderer could not initialise. Error: " << SDL_GetError() << endl;
        exit(1);
    }
}

void Render(float Xoffset, float Yoffset)
{
    game_screen_manager->Render(Xoffset, Yoffset);
    //clear screen
    SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
    //update screen
    SDL_RenderPresent(renderer);
    SDL_RenderClear(renderer);
}
