#pragma once
#include "GameScreen.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "LinkedList.h"
#include "Collisions.h"
#include <iostream>


class Button
{
private:
	bool hasBeenClicked = false;
	Camera* m_cam = nullptr;
	SDL_Renderer* m_renderer = nullptr;
	Vector2D m_buttonPos;
	GameText* m_buttonText = nullptr;
	SDL_Rect m_buttonBox;
	Vector2D m_pos;
	std::string m_stringText;
	void InitText() {m_buttonText = new GameText(m_renderer, "fonts/arial.ttf", m_fontSize);};
	void DrawButtonBoxes();
	bool m_mouseIsOnButton = false;
	int m_fontSize;
	SDL_Color m_boxColor;
	SDL_Color m_textColor;
	Audio* m_SFXClick = nullptr;
	Audio* m_SFXHover = nullptr;
	void InitAudio();
	bool m_clicked = false;
	SDL_Color m_selectedColor;
	SDL_Color m_unSelectedColor;

public:
	Button(SDL_Renderer* renderer, Camera* cam, Vector2D pos, std::string text, int fontSize, SDL_Color boxColor, SDL_Color textColor);
	~Button();
	void Render(float Xoffset, float Yoffset);
	void Update(float deltaTime);
	void HandleEvents(SDL_Event e, float deltaTime);
	bool IsHoverdOver(SDL_Event e);
	bool IsClicked(SDL_Event e);
	Vector2D GetPos() { return m_pos; };
	void SetHovered(bool state) ;
	void SetText(std::string text) { m_stringText = text; };
	void SetClicked(bool state) { m_clicked = state; };

};

