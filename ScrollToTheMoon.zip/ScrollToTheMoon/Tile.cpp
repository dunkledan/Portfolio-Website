#include "Tile.h"

//init tile size

const int Tile::TILE_WIDTH = 32;
const int Tile::TILE_HEIGHT = 40;

Tile::Tile(Texture2D* texture, TileType  type, Vector2D position, CollisionType collisionType)
{
	m_texture = texture;
	m_tileType = type;
	m_position = position;
	m_collisionType = collisionType;
}

/// <summary>
/// renders tile to the screen
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void Tile::Render(float Xoffset, float Yoffset)
{
	if (m_texture != nullptr)
	{
		m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), SDL_FLIP_NONE);
	}
}

Tile::~Tile()
{

}