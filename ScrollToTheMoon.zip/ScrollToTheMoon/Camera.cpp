#include "Camera.h"

Camera::Camera(float w, float h, float Xoffset, float Yoffset)
{
	m_width = w;
	m_height = h;
	m_Xoffset = Xoffset;
	m_Yoffset = Yoffset;
	m_cameraViewPort = new Rect2D(Xoffset,Yoffset, w, h);
}

/// <summary>
/// sets the camera offsets 
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void Camera::SetOffSet(float Xoffset, float Yoffset)
{
	m_Xoffset = Xoffset;
	m_Yoffset = Yoffset;
}

Camera::~Camera()
{
	delete m_cameraViewPort;
	m_cameraViewPort = nullptr;
}