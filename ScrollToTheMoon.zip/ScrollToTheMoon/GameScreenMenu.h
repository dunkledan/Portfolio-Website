#pragma once
#include "GameScreen.h"
#include "Commons.h"
#include "Texture2D.h"
#include "Character.h"
#include "GameText.h"
#include "Audio.h"
#include "Tilemap.h"
#include "LinkedList.h"
#include "Collisions.h"
#include <iostream>
#include "Button.h"

class GameScreenMenu : public GameScreen
{
public:
	GameScreenMenu(SDL_Renderer* renderer, Camera* cam);
	~GameScreenMenu();
	virtual void Render(float Xoffset, float Yoffset) override;
	virtual void Update(float deltaTime) override;
	virtual void HandleEvents(SDL_Event e,float deltaTime) override;

protected:
	Camera* m_cam = nullptr;
	LinkedList<Button> m_buttonsList = nullptr;
	void InitButtons();
	float m_buttonSpacing = 24;
	virtual void ButtonSelect(SDL_Event e);
	bool m_mouseIsOnStartButton = false;
	bool m_mouseIsOnControlsButton = false;
	int m_currentButtonIndex = 0;
	virtual void HandleButtonClicks(SDL_Event e);
	void ClearHoveredAndClicked();
	Texture2D* m_backgroundTexture = nullptr;

private:
	Button* m_startButton = nullptr;
	Button* m_controlsButton = nullptr;

};

