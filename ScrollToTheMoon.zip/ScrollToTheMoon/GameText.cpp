#include "GameText.h"

bool GameText::ttfHasInit = false;

GameText::GameText(SDL_Renderer* renderer, std::string fontPath, unsigned int fontSize)
{
	//initialise TTF if not already
	if (!InitTTF())
	{
		std::cerr << "Couldn't initialise TTF, error is: " << TTF_GetError() << std::endl;
		errorEncountered = true;
		return;
	}
	this->m_renderer = renderer;
	this->LoadFont(fontPath, fontSize);
}

/// <summary>
/// inits TTF lib
/// </summary>
/// <returns></returns>
bool GameText::InitTTF()
{
	if (ttfHasInit)
	{
		return true;
	}
	//return error if not properly initialised
	return (TTF_Init() >= 0);
}

/// <summary>
/// loads font from path
/// </summary>
/// <param name="fontPath"></param>
/// <param name="fontSize"></param>
/// <returns></returns>
bool GameText::LoadFont(std::string& fontPath, unsigned int fontSize)
{
	this->m_font = TTF_OpenFont(fontPath.c_str(), fontSize);
	if (!this->m_font)
	{
		//error font loading
		std::cerr << "Could not load font from path " << fontPath << " Error is: " << TTF_GetError() << std::endl;
		return false;
	}
	return true;
}

/// <summary>
/// renders game text element as specific position with specific text
/// </summary>
/// <param name="text"></param>
/// <param name="x"></param>
/// <param name="y"></param>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void GameText::RendererAt(const std::string& text, int x, int y, float Xoffset, float Yoffset)
{
	//error check
	if (errorEncountered)
	{
		return;
	}
	//Destroy text when required
	if (m_texture != nullptr)
	{
		SDL_DestroyTexture(m_texture);
	}
	//scale text size with screen proportions
	int w, h;
	TTF_SizeText(m_font,text.c_str(), &w, &h);
	//load surface and texture
	SDL_Surface* surface = TTF_RenderText_Blended(m_font,text.c_str(), m_color);
	m_texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);

	//get render rect size and render with this rectangle size
	SDL_Rect renderRect{x + Xoffset,y + Yoffset,w,h};
	SDL_RenderCopy(m_renderer, m_texture, NULL, &renderRect);
	m_textBoxRect = renderRect;
}

GameText::~GameText()
{
}


