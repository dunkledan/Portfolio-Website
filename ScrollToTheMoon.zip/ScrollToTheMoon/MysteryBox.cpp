#include "MysteryBox.h"

MysteryBox::MysteryBox(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D start_position, PowerUpEquipped powerUp) : GameObject(renderer, baseTexture, start_position)
{
	m_powerUp = powerUp;
	m_tag = "MysteryBox";
	//used to ensure random number always random
	srand(time(0));
}

MysteryBox::~MysteryBox()
{
}

/// <summary>
/// sets current powerup based on mystery box instance data
/// </summary>
/// <param name="player"></param>
void MysteryBox::SetPowerup(Character* player)
{
	m_SFX_ItemPickup->Play(0);
	if (m_powerUp == PowerUpEquipped::Random)
	{
		//sets random powerup
		PowerUpEquipped power = PowerUpEquipped(rand() % PowerUpEquipped::None+1);
		while (power == player->GetPowerUp() || power == PowerUpEquipped::None)
		{
			power = PowerUpEquipped(rand() % PowerUpEquipped::None);
		}
		player->HandlePowerUpChange(power);
	}
	else
	{
		player->HandlePowerUpChange(m_powerUp);
	}
}

/// <summary>
/// inits mystery box audio
/// </summary>
void MysteryBox::InitAudio()
{
	m_SFX_ItemPickup = new Audio("AudioFiles/SFX_ItemPickup.wav");
	m_SFX_ItemPickup->SetVolume(100);
}

void MysteryBox::HandleEvents(SDL_Event e, float deltaTime)
{
}