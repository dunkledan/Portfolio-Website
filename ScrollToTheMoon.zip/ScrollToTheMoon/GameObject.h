#pragma once
#include <SDL.h>
#include <iostream>
#include "Commons.h"
#include "Camera.h"
#include "LinkedList.h"
#include <vector>
#include "GameScreen.h"

class Texture2D;

class GameObject
{
protected:
	SDL_Renderer* m_renderer = nullptr;
	Vector2D m_position;
	Texture2D* m_texture = nullptr;
	float m_collisionRadius;
	std::vector<Texture2D*> m_currentAnim;
	float m_animTimer = 0;
	int m_animIndex = 0;

public:
	GameObject(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D startPosition);
	virtual ~GameObject();
	virtual void Render(float Xoffset, float Yoffset) ;
	virtual void Update(float deltaTime);
	virtual void HandleEvents(SDL_Event e, float deltaTime);
	void SetPosition(Vector2D newPosition) { m_position = newPosition; };
	Vector2D GetPosition() { return m_position; };
	bool GetCollisionRadius() { return m_collisionRadius; };
	Rect2D GetCollisionBox() { return Rect2D(m_position.x, m_position.y, m_texture->GetWidth(), m_texture->GetHeight()); };
	virtual void SetTexture(Texture2D* texture) { m_texture = texture; };
	std::string m_tag = "";
	void SetAnimation(std::vector<Texture2D*> anim) { m_currentAnim = anim; };
	void PlayAnimationFrame(float deltaTime);
	bool m_colldiable = true;
};

