#include "Collisions.h"
#include "GameObject.h"

//collisions return if there was a collision between two specific gameobjects on the most recent updated frame

//initialise instance to null pointer to prevent crash/unexpected errors
Collisions* Collisions::m_instance = nullptr;

Collisions::Collisions()
{
	
}

Collisions::~Collisions()
{
	m_instance = nullptr;
}

/// <summary>
/// creates a new collisions instance temporarily to handle specific collision case using the rest of the class
/// </summary>
/// <returns></returns>
Collisions* Collisions::Instance()
{
	if (!m_instance)
	{
		m_instance = new Collisions;
	}
	return m_instance;
}

/// <summary>
/// Circle collision check
/// </summary>
/// <param name="a"></param>
/// <param name="b"></param>
/// <returns></returns>
bool Collisions::Circle(GameObject* a, GameObject* b)
{
	//checking if two circle colliders overlap each other
	Vector2D vec = Vector2D((a->GetPosition().x - b->GetPosition().x), (a->GetPosition().y - b->GetPosition().y));
	double distance = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	double combined_distance = ((a->GetCollisionRadius()) + (b->GetCollisionRadius()));
	//returns if the distance is within the combined distance of each vector
	return distance < combined_distance;
}

/// <summary>
/// box collision check based on texture size of game objects
/// </summary>
/// <param name="a"></param>
/// <param name="b"></param>
/// <returns></returns>
bool Collisions::Box(GameObject* a, GameObject* b)
{
	//check to see if the object has collisions enabled before checking the collisions
	if (!a->m_colldiable || !b->m_colldiable)
	{
		return false;
	}
	//checking box overlap
	//setting up relevant variables for final calculation
	Rect2D rect1 = a->GetCollisionBox();
	Rect2D rect2 = b->GetCollisionBox();
	int rect1Left = rect1.x;
	int rect2Left = rect2.x;
	int rect1Top = rect1.y;
	int rect2Top = rect2.y;
	int rect1Bottom = (rect1Top + rect1.height);
	int rect2Bottom = (rect2Top + rect2.height);
	int rect1Right = (rect1Left + rect1.width);
	int rect2Right = (rect2Left + rect2.width);
	//calculating if two boxes acctually overlap, return true when collision happesn
	return (rect1Left < rect2Right) && (rect1Right > rect2Left) && (rect1Top < rect2Bottom) && (rect1Bottom > rect2Top);
}

//box collision overload for rect2Ds

/// <summary>
/// box collision based on rect struct
/// </summary>
/// <param name="a"></param>
/// <param name="b"></param>
/// <returns></returns>
bool Collisions::Box(Rect2D a, Rect2D b)
{
	//checking box overlap
	//setting up relevant variables for final calculation
	Rect2D rect1 = a;
	Rect2D rect2 = b;
	int rect1Left = rect1.x;
	int rect2Left = rect2.x;
	int rect1Top = rect1.y;
	int rect2Top = rect2.y;
	int rect1Bottom = (rect1Top + rect1.height);
	int rect2Bottom = (rect2Top + rect2.height);
	int rect1Right = (rect1Left + rect1.width);
	int rect2Right = (rect2Left + rect2.width);
	//calculating if two boxes acctually overlap 
	return (rect1Left < rect2Right) && (rect1Right > rect2Left) && (rect1Top < rect2Bottom) && (rect1Bottom > rect2Top);
}

/// <summary>
/// collision check with adjacent tile at specific offset between tilemap tile and a given rect struct
/// </summary>
/// <param name="tilemap"></param>
/// <param name="rect"></param>
/// <param name="adjacencyOffset"></param>
/// <returns></returns>
bool Collisions::TileMapCheckAdjacentTile(Tilemap* tilemap, Rect2D rect, Vector2D adjacencyOffset)
{
	//this function checks the adjacent tile of a specific rect e.g player rect collision box, and returns if there are relevant adjacent tile types to its position
	//the adjacency offset is the direciton there can be adjacent tiles
	//find grid position of the player from the tilemap data, and find adjacent cells to the given collision box based on adjacencyOffset arg
	Vector2D gridPos = tilemap->WorldToGridPosition(Vector2D(rect.x,rect.y));
	Vector2D castGridPos = Vector2D(gridPos.x + adjacencyOffset.x, gridPos.y + adjacencyOffset.y);
	//if outside of tilemap bound collide with edge of screen
	if (castGridPos.x >= tilemap->m_cols || castGridPos.x < 0)
	{
		return true;
	}
	else if (castGridPos.y >= tilemap->m_rows || castGridPos.y < 0)
	{
		return true;
	}
	//find adjacent tile in tilemap
	Tile* castTile = tilemap->GetTile((int)castGridPos.x, (int)castGridPos.y);
	//not impassable tile type then dont ping collision
	if (castTile->m_collisionType != CollisionType::Impassable)
	{
		return false;
	}
	//get tile position in world space
	float x = castTile->m_position.x;
	float y = castTile->m_position.y;
	//Find collision box in world space of the tile
	Rect2D tileColliderBox = Rect2D(x,y,Tile::TILE_WIDTH,Tile::TILE_HEIGHT);
	return m_instance->Box(rect, tileColliderBox);
}
