#include "GameScreen.h"
#include <SDL_image.h>

GameScreen::GameScreen(SDL_Renderer* renderer)
{
	m_renderer = renderer;
}

GameScreen::~GameScreen()
{
	m_renderer = nullptr;
}

void GameScreen::Render(float Xoffset, float Yoffset)
{
}

void GameScreen::Update(float deltaTime)
{
}

void GameScreen::HandleEvents(SDL_Event e,float deltaTime)
{
}

/// <summary>
/// tries to load a texture from file, if fails return a failed status enum
/// </summary>
/// <param name="texturePtr"></param>
/// <param name="inputPath"></param>
/// <returns></returns>
TextureLoadStatus GameScreen::TryLoadTexture(Texture2D*& texturePtr, const std::string& inputPath)
{
	//constuct new current managed texture
	texturePtr = new Texture2D(m_renderer);
	//load texture from file if not fail
	if (!texturePtr->LoadFromFile(inputPath))
	{
		std::cerr << "Failed to load texture at path: " << inputPath << std::endl;
		return TextureLoadStatus::Fail;
	}
	//successful texture load
	return TextureLoadStatus::Ok;
}