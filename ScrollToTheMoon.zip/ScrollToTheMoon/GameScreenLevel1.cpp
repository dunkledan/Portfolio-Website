#include "GameScreenLevel1.h"
#include <iostream>

using namespace std;

GameScreenLevel1::GameScreenLevel1(SDL_Renderer* renderer, Camera* cam) : GameScreen(renderer)
{
	delete m_music;
	m_music = nullptr;
	m_renderer = renderer;
	m_cam = cam;
	SetUpLevel();
}

GameScreenLevel1::~GameScreenLevel1()
{
	delete m_backgroundTexture;
	m_backgroundTexture = nullptr;
	delete m_tileMap;
	m_tileMap = nullptr;
	delete m_scoreButton;
	m_scoreButton = nullptr;
	m_tileMap = nullptr;
	delete m_music;
	m_music = nullptr;
	m_gameObjectList.ClearList();
}

/// <summary>
/// renders all screen elements
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void GameScreenLevel1::Render(float Xoffset, float Yoffset)
{
	if (m_character->m_isDead)
	{
		return;
	}
	//render reapeating parralax background texture
	for (int i = 0; i < 12; i++)
	{
		m_backgroundTexture->Render(Vector2D(Xoffset * 2 + m_backgroundTexture->GetWidth() * i, Yoffset * 2), SDL_FLIP_NONE);
	}
	//Render All GameObjects
	auto object = m_gameObjectList.GetHead();
	while (object != nullptr)
	{
		object->data->Render(Xoffset, Yoffset);
		object = object->next;
	}
	//score display render
	m_scoreButton->SetText("Score: " + std::to_string(m_score));
	m_scoreButton->Render(Xoffset+50, Yoffset+50);
	//Render tilemap
	m_tileMap->Render(Xoffset, Yoffset);
}

/// <summary>
/// updates all screen elements
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenLevel1::Update(float deltaTime) 
{
	if (m_character->m_isDead)
	{
		return;
	}
	//update all gameobjects
	UpdateGameObjects(deltaTime);
	//handle collisions
	HandleGameObjectCollisions();
	//camera scrolling effect
	m_cam->SetOffSet(m_cam->GetOffSet().x - SCROLL_SPEED * deltaTime, m_cam->GetOffSet().y * deltaTime);
}

void GameScreenLevel1::HandleEvents(SDL_Event e, float deltaTime)
{
	auto node = m_gameObjectList.GetHead();
	while (node != nullptr)
	{
		node->data->HandleEvents(e, deltaTime);
		node = node->next;
	}
}

/// <summary>
/// updates all gameObjects
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void GameScreenLevel1::UpdateGameObjects(float deltaTime)
{
	auto node = m_gameObjectList.GetHead();
	while (node != nullptr)
	{
		node->data->Update(deltaTime);
		node = node->next;
	}
}

/// <summary>
/// handles all game object collisions
/// </summary>
void GameScreenLevel1::HandleGameObjectCollisions()
{
	//check for if the player is not on screen
	if (m_character != nullptr)
	{
		KeepPlayerOnScreen();
		HandleCharacterGameObjectCollisions();
	}
}

/// <summary>
/// handles all Character collisions with game objects
/// </summary>
void GameScreenLevel1::HandleCharacterGameObjectCollisions()
{
	//Check if character exists to avoid nullptr access error
	if (m_character != nullptr)
	{
		//walk gameObjectList
		auto node = m_gameObjectList.GetHead();
		while (node != nullptr)
		{
			auto nextNode = node->next;
			//check for tags
			//mystery box collision handling
			if (node->data->m_tag == "MysteryBox")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					MysteryBox* current = dynamic_cast<MysteryBox*>(node->data);
					//set player powerup
					current->SetPowerup(m_character);
					//detroy box now its used + remove from gameobject list
					m_gameObjectList.RemoveItemByPointer(node->data);
					delete current;
					current = nullptr;
				}
			}
			//enemy collision handling
			else if (node->data->m_tag == "Enemy")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					m_character->TakeDamage();
				}
			}
			//coin collisions
			else if (node->data->m_tag == "Coin")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					Coin* current = dynamic_cast<Coin*>(node->data);
					current->PlayPickup();
					m_score++;
					m_gameObjectList.RemoveItemByPointer(node->data);
					delete current;
					current = nullptr;
				}
			}
			//exit door collision
			else if (node->data->m_tag == "ExitDoor")
			{
				if (Collisions::Instance()->Box(m_character, node->data))
				{
					ExitDoor* current = dynamic_cast<ExitDoor*>(node->data);
					current->PlayWin();
					SDL_Event userEvent;
					userEvent.type = SDL_USEREVENT;
					userEvent.user.code = 5;
					SDL_PushEvent(&userEvent);
				}
			}
			node = nextNode;
		}
	}
}

/// <summary>
/// keeps the player on the screen if when scrolling
/// </summary>
void GameScreenLevel1::KeepPlayerOnScreen()
{
	//if character is going ooffscreen on the left set position to most left part of visible screen
	if (m_character->GetPosition().x < -m_cam->GetOffSet().x)
	{
		if (m_character->m_physicsSystem->GetVelocity().x <= 0)
		{
			//position and velocity correction 
			m_character->SetPosition(Vector2D(-1 * m_cam->GetOffSet().x, m_character->GetPosition().y));
			m_character->m_physicsSystem->SetVelocity(Vector2D(0, m_character->m_physicsSystem->GetVelocity().y));
		}
	}
	//if character is going of screen on the right set position to most right part of visible screen
	else if (m_character->GetPosition().x > m_cam->GetViewPort()->width - m_cam->GetOffSet().x - Tile::TILE_WIDTH)
	{
		if (m_character->m_physicsSystem->GetVelocity().x >= 0)
		{
			//position and velocity correction 
			m_character->SetPosition(Vector2D(m_cam->GetViewPort()->width - m_cam->GetOffSet().x - Tile::TILE_WIDTH, m_character->GetPosition().y));
			m_character->m_physicsSystem->SetVelocity(Vector2D(0, m_character->m_physicsSystem->GetVelocity().y));
		}
	}
}

/// <summary>
/// initialises the level
/// </summary>
/// <returns></returns>
bool GameScreenLevel1::SetUpLevel()
{
	//load textures and error if failed
	if (!LoadGameTextures())
	{
		return false;
	}
	if (!InitTileMap(m_path))
	{
		return false;
	}
	InitText();
	InitGameObjects();
	InitGameScreenAudio();
	m_music->Play(20);
	return true;
}

/// <summary>
/// loads all textures for the level
/// </summary>
/// <returns></returns>
bool GameScreenLevel1::LoadGameTextures()
{
	int successStatus = TextureLoadStatus::Ok;
	//load textures from files
	successStatus &= TryLoadTexture(m_backgroundTexture, "Images/level1Bg.png");
	//tile textures
	successStatus &= TryLoadTexture(m_tile1Texture, "Images/tiles/WoodPlatform.png");
	successStatus &= TryLoadTexture(m_tile2Texture, "Images/tiles/StoneBrick.png");
	successStatus &= TryLoadTexture(m_tile3Texture, "Images/tiles/LavaTile.png");
	//character textures
	successStatus &= TryLoadTexture(m_characterTexture, "Images/CharacterStatic.png");
	successStatus &= TryLoadTexture(m_characterTexture2, "Images/CharacterStatic2.png");
	successStatus &= TryLoadTexture(m_characterTextureJump, "Images/CharacterStaticJump.png");
	successStatus &= TryLoadTexture(m_doubleJumpPowerTexture, "Images/DoubleJumpPower.png");
	successStatus &= TryLoadTexture(m_DoubleJump2, "Images/DoubleJump2.png");
	successStatus &= TryLoadTexture(m_DoubleJump3, "Images/DoubleJump3.png");
	successStatus &= TryLoadTexture(m_helmetPowerTexture, "Images/HelmetPower.png");
	successStatus &= TryLoadTexture(m_helmetPowerTextureJump, "Images/HelmetPowerJump.png");
	successStatus &= TryLoadTexture(m_helmetPowerTexture2, "Images/HelmetPower2.png");
	successStatus &= TryLoadTexture(m_ClimbPowerTexture, "Images/ClimbPower.png");
	successStatus &= TryLoadTexture(m_ClimbPowerTexture2, "Images/ClimbPower2.png");
	successStatus &= TryLoadTexture(m_doubleJumpPowerJump, "Images/DoubleJumpPowerJump.png");
	successStatus &= TryLoadTexture(m_ClimbPowerTextureJump2, "Images/ClimbPowerJump2.png");
	successStatus &= TryLoadTexture(m_helmetRegen, "Images/HelmetRegen.png");
	successStatus &= TryLoadTexture(m_helmetTakeDamage, "Images/HelmetTakesDamage.png");
	//gameObject Textures
	successStatus &= TryLoadTexture(m_mysteryBoxTexture, "Images/MysteryBox.png");
	successStatus &= TryLoadTexture(m_enemyTexture, "Images/enemy.png");
	successStatus &= TryLoadTexture(m_enemyTexture2, "Images/enemy2.png");
	successStatus &= TryLoadTexture(m_coinTexture, "Images/coin.png");
	successStatus &= TryLoadTexture(m_coinTexture2, "Images/coin2.png");
	successStatus &= TryLoadTexture(m_coinTexture3, "Images/coin3.png");
	successStatus &= TryLoadTexture(m_exitDoorTexture, "Images/door.png");
	if (successStatus == TextureLoadStatus::Fail)
	{
		std::cerr << "Could not initialise level 1 screen, texture loading error" << std::endl;
		return false;
	}
	return true;
}

/// <summary>
/// initialises all audio for each game object and the level in general
/// </summary>
void GameScreenLevel1::InitGameScreenAudio()
{
	//init audio
	//walk gameObjectList
	m_music = new Audio("AudioFiles/BPDMusic.wav");
	auto node = m_gameObjectList.GetHead();
	while (node != nullptr)
	{
		auto nextNode = node->next;
		//check for tags
		//player
		if (node->data->m_tag == "Character")
		{
			Character* current = dynamic_cast<Character*>(node->data);
			current->InitAudio();
		}
		//mystery box 
		if (node->data->m_tag == "MysteryBox")
		{
			MysteryBox* current = dynamic_cast<MysteryBox*>(node->data);
			current->InitAudio();
		}
		//coin 
		else if (node->data->m_tag == "Coin")
		{
			Coin* current = dynamic_cast<Coin*>(node->data);
			current->InitAudio();
		}
		//exit door 
		else if (node->data->m_tag == "ExitDoor")
		{
			ExitDoor* current = dynamic_cast<ExitDoor*>(node->data);
			current->InitAudio();
		}
		node = nextNode;
	}

	m_character->InitAudio();
}

/// <summary>
/// initialises all game objects
/// </summary>
void GameScreenLevel1::InitGameObjects()
{
	m_gameObjectList.ClearList();
	//setup GameObjects
	//init gameObjects & push them into a linked list
	m_character = new Character(m_renderer, m_characterTexture, Vector2D(100, 300), m_tileMap);
	m_gameObjectList.Push(m_character);
	m_gameObjectList.Push(new MysteryBox(m_renderer, m_mysteryBoxTexture, Vector2D(200, 300), DoubleJump));
	m_gameObjectList.Push(new MysteryBox(m_renderer, m_mysteryBoxTexture, Vector2D(1032, 128), Helmet));
	m_gameObjectList.Push(new MysteryBox(m_renderer, m_mysteryBoxTexture, Vector2D(82 * Tile::TILE_WIDTH, 9 * Tile::TILE_HEIGHT), Climb));
	m_gameObjectList.Push(new Enemy(m_renderer, m_enemyTexture, Vector2D(32 * Tile::TILE_WIDTH, 6 *  Tile::TILE_HEIGHT), m_tileMap, 64, -64));
	m_gameObjectList.Push(new Enemy(m_renderer, m_enemyTexture, Vector2D(58 * Tile::TILE_WIDTH, 6 * Tile::TILE_HEIGHT), m_tileMap, 64, -64));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(18 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(21 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(24 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(55 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(58 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(61 * Tile::TILE_WIDTH, 4 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(89 * Tile::TILE_WIDTH, 9 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_coinTexture, Vector2D(86 * Tile::TILE_WIDTH, 9 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_enemyTexture, Vector2D(50 * Tile::TILE_WIDTH, 6 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new Coin(m_renderer, m_enemyTexture, Vector2D(53 * Tile::TILE_WIDTH, 6 * Tile::TILE_HEIGHT)));
	m_gameObjectList.Push(new ExitDoor(m_renderer, m_exitDoorTexture, Vector2D(93 * Tile::TILE_WIDTH, 3 * Tile::TILE_HEIGHT)));
	MapCharacterPowerUpTextures();
}

/// <summary>
/// initialises the character powerup textures
/// </summary>
void GameScreenLevel1::MapCharacterPowerUpTextures()
{
	m_character->AddPowerUpTextureMapping(None, m_characterTexture);
	m_character->AddPowerUpTextureMapping(DoubleJump, m_doubleJumpPowerTexture);
	m_character->AddPowerUpTextureMapping(Helmet, m_helmetPowerTexture);
	m_character->AddPowerUpTextureMapping(Climb, m_ClimbPowerTexture);
	InitGameObjectAnims();
}

/// <summary>
/// initialises animations
/// </summary>
void GameScreenLevel1::InitGameObjectAnims()
{
	//init gameObject animations
	std::vector<Texture2D*> enemyAnim = { m_enemyTexture ,m_enemyTexture2 };
	std::vector<Texture2D*> coinAnim = { m_coinTexture ,m_coinTexture2,m_coinTexture3,m_coinTexture2 };
	//init character  animations
	std::vector<Texture2D*> playerAnimIdle = { m_characterTexture,m_characterTexture2 };
	std::vector<Texture2D*> playerAnimHelmetIdle = { m_helmetPowerTexture, m_helmetPowerTexture2 };
	std::vector<Texture2D*> playerAnimHelmetRegen = { m_helmetPowerTexture2, m_helmetRegen };
	std::vector<Texture2D*> playerAnimHelmetInvincible = { m_helmetPowerTexture, m_helmetPowerTexture2 };
	std::vector<Texture2D*> playerAnimHelmetDamage = { m_helmetTakeDamage };
	std::vector<Texture2D*> playerAnimHelmetJump = { m_helmetPowerTexture,m_helmetPowerTextureJump };
	std::vector<Texture2D*> playerAnimDoubleJumpIdle = { m_doubleJumpPowerTexture,m_DoubleJump2,m_DoubleJump3 };
	std::vector<Texture2D*> playerAnimJump = { m_characterTexture,m_characterTextureJump };
	std::vector<Texture2D*> playerAnimClimbJump = { m_ClimbPowerTexture,m_ClimbPowerTextureJump2 };
	std::vector<Texture2D*> playerAnimClimbIdle = { m_ClimbPowerTexture,m_ClimbPowerTexture2 };
	std::vector<Texture2D*> playerAnimDoubleJumpJump = { m_doubleJumpPowerTexture,m_doubleJumpPowerJump };
	//set all object instances to resepctive animations
	auto node = m_gameObjectList.GetHead();
	while (node != nullptr)
	{
		auto nextNode = node->next;
		if (node->data->m_tag == "Enemy")
		{
			node->data->SetAnimation(enemyAnim);
		}
		if (node->data->m_tag == "Coin")
		{
			node->data->SetAnimation(coinAnim);
		}
		if (node->data->m_tag == "Character")
		{
			Character* Instace = dynamic_cast<Character*>(node->data);
			Instace->SetAnimation(playerAnimIdle);
			Instace->SetIdleAnim(playerAnimIdle);
			Instace->SetIdleHelmetAnim(playerAnimHelmetIdle);
			Instace->SetRegenHelmetAnim(playerAnimHelmetRegen);
			Instace->SetInvincibleHelmetAnim(playerAnimHelmetInvincible);
			Instace->SetDamageHelmetAnim(playerAnimHelmetDamage);
			Instace->SetHelmetJumpAnim(playerAnimHelmetJump);
			Instace->SetDoubleJumpIdleAnim(playerAnimDoubleJumpIdle);
			Instace->SetJumpAnim(playerAnimJump);
			Instace->SetClimbJumpAnim(playerAnimClimbJump);
			Instace->SetClimbIdleAnim(playerAnimClimbIdle);
			Instace->SetDoubleJumpJumpAnim(playerAnimDoubleJumpJump);
		}
		node = nextNode;
	}
}

/// <summary>
/// initialises all tilemaps 
/// </summary>
/// <param name="path"></param>
/// <returns></returns>
bool GameScreenLevel1::InitTileMap(std::string path)
{
	//setup tilemap
	m_tileMap = new Tilemap(12, 191, Vector2D(0, 0));
	//tile type mappings
	m_tileMap->AddTileTexture(TileType::Ground, m_tile1Texture);
	m_tileMap->AddTileTexture(TileType::Platform, m_tile2Texture);
	m_tileMap->AddTileTexture(TileType::Lava, m_tile3Texture);
	//load tile map tiles from file if possible
	bool tileMapLoadStatus = m_tileMap->LoadFromFile(path);
	if (!tileMapLoadStatus)
	{
		std::cerr << "Failed to load tilemap " << std::endl;
		return false;
	}
	//initialise previously defined tiles
	m_tileMap->InitTileObjects();
	return true;
}