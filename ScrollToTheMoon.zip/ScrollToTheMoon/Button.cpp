#include "Button.h"

Button::Button(SDL_Renderer* renderer, Camera* cam, Vector2D pos, std::string text, int fontSize, SDL_Color boxColor, SDL_Color textColor)
{
	m_renderer = renderer;
	m_cam = cam;
	m_pos = pos;
	m_stringText = text;
	m_fontSize = fontSize;
	m_boxColor = boxColor;
	m_selectedColor = SDL_Color{105,105,105,255};
	m_unSelectedColor = boxColor;
	m_textColor = textColor;
	InitText();
	InitAudio();
}

/// <summary>
/// draw box of a specific color around the text
/// </summary>
void Button::DrawButtonBoxes()
{
	//draw start button
	m_buttonBox = m_buttonText->GetTextBox();
	SDL_SetRenderDrawColor(m_renderer, m_boxColor.r, m_boxColor.g, m_boxColor.b, m_boxColor.a);
	SDL_RenderFillRect(m_renderer, &m_buttonBox);
}

Button::~Button()
{
	delete m_buttonText;
	m_buttonText = nullptr;
	delete m_SFXClick;
	m_SFXClick = nullptr;
	delete m_SFXHover;
	m_SFXHover = nullptr;
}

/// <summary>
/// Renders button text and boxes
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void Button::Render(float Xoffset, float Yoffset)
{
	DrawButtonBoxes();
	m_buttonText->SetColor(m_textColor);
	m_buttonText->RendererAt(m_stringText, m_pos.x, m_pos.y, m_pos.x, m_pos.y);
}

void Button::Update(float deltaTime)
{
	
}

/// <summary>
/// handles SDL_Events for the class
/// </summary>
/// <param name="e"></param>
void Button::HandleEvents(SDL_Event e, float deltaTime)
{
	IsHoverdOver(e);
	IsClicked(e);
}

/// <summary>
/// check if a button is hovered over and returns true if it is
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
/// <returns></returns>
bool Button::IsHoverdOver(SDL_Event e)
{
	switch (e.type)
	{
	case SDL_MOUSEMOTION:
		//check if mouse is on the button
		if (Collisions::Instance()->Box(Rect2D(e.motion.x, e.motion.y, 1, 1), Rect2D(m_buttonBox.x, m_buttonBox.y, m_buttonBox.w, m_buttonBox.h)))
		{
			if (!m_mouseIsOnButton)
			{
				m_SFXHover->Play(0);
			}
			m_mouseIsOnButton = true;
			if (m_mouseIsOnButton)
			{
				m_boxColor = m_selectedColor;
			}
		}
		else
		{
			m_mouseIsOnButton = false;
			m_boxColor = m_unSelectedColor;
		}
		break;
	default:
		break;
	}
	return m_mouseIsOnButton;
}

/// <summary>
/// check if a button is clicked and returns true if it is
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
/// <returns></returns>
bool Button::IsClicked(SDL_Event e)
{
	if (hasBeenClicked == true)
		return false;

	if (m_clicked)
	{
		hasBeenClicked = true;
		return true;
	}
	switch (e.type)
	{
	case SDL_MOUSEBUTTONDOWN:
		if (m_mouseIsOnButton)
		{
			m_clicked = true;
			m_SFXClick->Play(0);
			return true;
		}
		break;
	case SDL_JOYBUTTONDOWN:
		switch (e.jbutton.button)
		{
		case 4:
			if (m_mouseIsOnButton)
			{
				m_clicked = true;
				m_SFXClick->Play(0);
				return true;
			}
			break;
		default:
			break;
		}
	default:
		break;
	}
	return false;
}

/// <summary>
/// initialises button click and hover audio 
/// </summary>
void Button::InitAudio()
{
	//click
	m_SFXClick = new Audio("AudioFiles/SFX_Click.wav");
	m_SFXClick->SetVolume(100);
	//hover
	m_SFXHover = new Audio("AudioFiles/SFX_Hover.wav");
	m_SFXHover->SetVolume(100);
}

/// <summary>
/// sets the button state to be hovered over
/// </summary>
/// <param name="state"></param>
void Button::SetHovered(bool state) 
{
	m_mouseIsOnButton = state;
	if (m_mouseIsOnButton)
	{
		m_boxColor = m_selectedColor;
		m_SFXHover->Play(0);
	}
	else
	{
		m_boxColor = m_unSelectedColor;
	}
};