#pragma once
#include <iostream>

template <typename T>

class LinkedList
{
private:
	struct Node
	{
		Node* next = nullptr;
		Node* prev = nullptr;
		T* data = nullptr;

		//constructors + overload constructors
		Node()
		{
			next = nullptr;
			prev = nullptr;
			data = nullptr;
		}

		Node(Node* n, Node* p, T* d)
		{
			next = n;
			prev = p;
			data = d;
		}

	};
	Node* head = nullptr;
	int size = 0;

public:

	LinkedList()
	{
		head = nullptr;
	}

	LinkedList(T* d)
	{
		head = new Node(nullptr, nullptr, d);
		size++;
	}

	~LinkedList()
	{
		Node* n = head;
		while (n != nullptr)
		{
			Node* next = n->next;
			delete n;
			n = next;
		}
	}

	void Push(T* object)
	{
		if (head == nullptr)
		{
			head = new Node(nullptr, nullptr, object);
			size++;
			return;
		}
		Node* n = head;
		Node* previous = n;
		while (n->next != nullptr)
		{
			previous = n;
			n = n->next;
		}
		n->next = new Node(nullptr, n, object);
		size++;
	}

	void RemoveItemByPointer(T* item)
	{
		Node* n = head;
		//traverse list
		while (n != nullptr)
		{
			//find item bby pointer 
			if (n->data == item)
			{
				Node* nextTemp = n->next;
				Node* prevTemp = n->prev;
				if (prevTemp != nullptr)
				{
					prevTemp->next = nextTemp;
				}
				if (nextTemp != nullptr)
				{
					nextTemp->prev = prevTemp;
				}
				if (n == head)
				{
					head = nextTemp;
				}
				size--;
				delete n;
				return;
			}
			n = n->next;
		}
	}

	int GetSize()
	{
		return size;
	}

	T* GetItemByPointer(T* item)
	{
		Node* n = head;
		//traverse list
		while (n != nullptr)
		{
			//find item bby pointer 
			if (n->data == item)
			{
				return n->data;
			}
			n = n->next;
		}
	}

	T* GetItemByIndex(int index)
	{
		int currentIndex = 0;
		Node* n = head;
		//traverse list
		while (n != nullptr)
		{
			//find item by index
			if (currentIndex == index)
			{
				return n->data;
			}
			currentIndex++;
			n = n->next;
		}
		return nullptr;
	}

	Node* GetHead()
	{
		return head;
	}

	void ClearList()
	{
		Node* n = head;
		while (n != nullptr)
		{
			Node* next = n->next;
			delete n;
			n = next;
		}
		head = nullptr;
		size = 0;
	}
};