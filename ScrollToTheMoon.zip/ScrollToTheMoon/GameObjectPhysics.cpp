#include "GameObjectPhysics.h"
using namespace std;

GameObjectPhysics::GameObjectPhysics(GameObject* object)
{
	m_object = object;
	m_gravityForce = 9.8f;
}

void GameObjectPhysics::AddVelocity(Vector2D vel)
{
	m_xVelocity += vel.x * -1;
	m_yVelocity += vel.y * -1;
}

GameObjectPhysics::~GameObjectPhysics()
{
}

void GameObjectPhysics::SetVelocity(Vector2D vel)
{
	m_xVelocity = vel.x;
	m_yVelocity = vel.y;
}

void GameObjectPhysics::UpdateVelocities(float deltaTime)
{
	if (m_object != nullptr)
	{
		m_object->SetPosition(Vector2D(m_xVelocity * deltaTime + m_object->GetPosition().x, m_yVelocity * deltaTime + m_object->GetPosition().y));
	}
};