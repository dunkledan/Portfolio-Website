#include "Texture2D.h"
#include <SDL_image.h>
#include <iostream>

using namespace std;

Texture2D::Texture2D(SDL_Renderer* renderer)
{
    m_renderer = renderer;
}

Texture2D::~Texture2D()
{
    //Free memory
    Free();
    m_renderer = nullptr;
}

/// <summary>
/// loads an image from file as a texture
/// </summary>
/// <param name="path"></param>
/// <returns></returns>
bool Texture2D::LoadFromFile(std::string path)
{
    Free();
    //load image
    SDL_Surface* p_surface = IMG_Load(path.c_str());
    if (p_surface != nullptr)
    {
        SDL_SetColorKey(p_surface, SDL_TRUE, SDL_MapRGB(p_surface->format, 0, 0XFF, 0XFF));
        m_texture = SDL_CreateTextureFromSurface(m_renderer, p_surface);
        //create texture from the surface pixels
        if (m_texture == nullptr)
        {
            cerr << "Unable to create texture from surface. Error: " << SDL_GetError() << endl;
        }
        else
        {
            m_width = p_surface->w;
            m_height = p_surface->h;
        }
        //remove loaded surface now it isnt needed
        SDL_FreeSurface(p_surface);
        p_surface = nullptr;
    }
    else
    {
        cerr << "Unable to create texture from surface. Error: " << SDL_GetError() << endl;
    }
    return m_texture != nullptr;
}

/// <summary>
/// frees texture memory
/// </summary>
void Texture2D::Free()
{
	if (m_texture != nullptr)
	{
		SDL_DestroyTexture(m_texture);
		m_texture = nullptr;
	}
}

/// <summary>
/// renders texture to screen at position with a flip attribute
/// </summary>
/// <param name="new_position"></param>
/// <param name="flip"></param>
/// <param name="angle"></param>
void Texture2D::Render(Vector2D new_position, SDL_RendererFlip flip, double angle)
{
    //if there is no texture dont render anything
    if (this == nullptr)
    {
        return; 
    }
    if (this != nullptr)
    {
        //set render location on screen
        SDL_Rect renderLocation = { new_position.x, new_position.y,m_width,m_height };
        //render on screen
        SDL_RenderCopyEx(m_renderer, m_texture, nullptr, &renderLocation, 0, nullptr, flip);
    }
}