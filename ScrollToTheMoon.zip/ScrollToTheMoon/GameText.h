#pragma once
#include <SDL_ttf.h>
#include <string>
#include <iostream>

class GameText
{
	public:
		GameText(SDL_Renderer* renderer, std::string fontPath, unsigned int fontSize);
		~GameText();
		bool LoadFont(std::string &fontPath, unsigned int fontSize);
		void RendererAt(const std::string& text, int x, int y, float Xoffset, float Yoffset);
		void SetColor(SDL_Color color) {this->m_color = color;};
		SDL_Rect GetTextBox() {return m_textBoxRect;};
		
	protected:
		SDL_Texture* m_texture = nullptr;
		TTF_Font* m_font = nullptr;
		SDL_Color m_color{255,255,255,255};
		SDL_Renderer* m_renderer = nullptr;
		SDL_Rect m_textBoxRect;

	private:
		bool errorEncountered = false;
		static bool ttfHasInit;
		bool InitTTF();
};

