#include "Character.h"
#include "Texture2D.h"
#include "constants.h"
#include "GameObjectPhysics.h"
#include "Camera.h"
using namespace std;

Character::Character(SDL_Renderer* renderer, Texture2D* baseTexture, Vector2D start_position, Tilemap* tmap) : GameObject(renderer, baseTexture, start_position)
{
    delete m_physicsSystem;
    m_physicsSystem = nullptr;
    m_tag = "Character";
    m_tileMap = tmap;
    m_facingDirection = FACING_RIGHT;
    m_movingLeft = false;
    m_movingRight = false;
    m_falling = true;
    m_jumpUsed = false;
    //setup map for character powerup textures vs enum
    m_characterPowerUpTextures = new std::map<PowerUpEquipped, Texture2D*>();
}

/// <summary>
/// sets variables associated with each powerup appropriately when the powerup changes
/// </summary>
/// <param name="power"></param>
void Character::HandlePowerUpChange(PowerUpEquipped power)
{
    m_powerUp = power;
    switch (m_powerUp)
    {
    case DoubleJump:
    {
        SetAnimation(m_idleDoubleJumpAnim);
        m_hits = 1;
        m_maxHits = 1;
        break;
    }
    case Helmet:
    {
        m_hits = 2;
        m_maxHits = 2;
        break;
    }
    case Climb:
    {
        SetAnimation(m_climbIdleAnim);
        m_hits = 1;
        m_maxHits = 1;
        break;
    }
    case None:
    {
        SetAnimation(m_idleAnim);
        m_hits = 1;
        m_maxHits = 1;
        break;
    }
    default:
        break;
    }
}

Character::~Character()
{
    delete m_physicsSystem;
    m_physicsSystem = nullptr;
    delete m_characterPowerUpTextures;
    m_characterPowerUpTextures = nullptr;
    delete m_SFXJump;
    m_SFXJump = nullptr;
    delete m_SFXDeath;
    m_SFXDeath = nullptr;
    delete m_SFXHit;
    m_SFXHit = nullptr;
}

/// <summary>
/// renders the character on screen based on texture and handles helemt rendering edgecases
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
void Character::Render(float Xoffset, float Yoffset)
{
    //handles right rendering
    if (m_facingDirection == FACING_RIGHT)
    {
        if (m_powerUp == Helmet)
        {
            RenderHelmet(Xoffset, Yoffset, SDL_FLIP_NONE);
        }
        else
        {
            m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), SDL_FLIP_NONE);
        }
    }
    //handles left rendering
    else if (m_facingDirection == FACING_LEFT)
    {
        if (m_powerUp == Helmet)
        {
            RenderHelmet(Xoffset, Yoffset, SDL_FLIP_HORIZONTAL);
        }
        else
        {
            m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), SDL_FLIP_HORIZONTAL);
        }
    }
}

/// <summary>
/// handles animations for helmet states rendering
/// </summary>
/// <param name="Xoffset"></param>
/// <param name="Yoffset"></param>
/// <param name="flip"></param>
void Character::RenderHelmet(float Xoffset, float Yoffset, SDL_RendererFlip flip)
{ 
    //if player just hit, damage anim
    if (m_timeSinceHit < 0.3f)
    {
        SetAnimation(m_damageHelmetAnim);
        m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), flip);
    }
    //if the player is invunrable play invunrable animation
    else if (m_timeSinceHit < 1)
    {
        //frame switch between rendering and not for invincibility effect
        SetAnimation(m_invincibleHelmetAnim);
        m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), flip);
    }
    //if the player is not invunrable and is not at full health regen animation
    else if (m_timeSinceHit < 3 && m_timeSinceHit > 1) 
    {
        SetAnimation(m_regenHelmetAnim);
        m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), flip);
    }
    //if the player has regenerated to full health, render normally helmet
    else if (m_timeSinceHit >= 3)
    {
        SetAnimation(m_idleHelmetAnim);
        m_texture->Render(Vector2D(m_position.x + Xoffset, m_position.y + Yoffset), flip);
    }
}

/// <summary>
/// adds x velocity to the character physics system 
/// </summary>
/// <param name="deltaTime"></param>
void Character::MoveLeft(float deltaTime)
{
    if (m_physicsSystem->GetVelocity().x > -0.05f)
    {
        m_physicsSystem->AddVelocity(Vector2D(MOVEMENT_SPEED, 0));
    }
}

/// <summary>
/// takes x velocity to the character physics system 
/// </summary>
/// <param name="deltaTime"></param>
void Character::MoveRight(float deltaTime)
{
    if (m_physicsSystem->GetVelocity().x < 0.05f)
    {
        m_physicsSystem->AddVelocity(Vector2D( -MOVEMENT_SPEED, 0));
    }
}
/// <summary>
/// adds y velocity to the physics system when called and handles double jump jumm when appropriate 
/// </summary>
/// <param name="deltaTime"></param>
void Character::Jump(float deltaTime)
{
    m_SFXJump->SetVolume(100);
    m_SFXJump->Play(0);
    m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x, 0));
    m_physicsSystem->AddVelocity(Vector2D(0, JUMP_SPEED));
    m_falling = true;
    if (m_powerUp == DoubleJump && m_doubleJumpUsed)
    {
        SetAnimation(m_idleDoubleJumpAnim);
    }
}

/// <summary>
/// handles character updates and character specific event polling
/// </summary>
/// <param name="deltaTime"></param>
/// <param name="e"></param>
void Character::Update(float deltaTime)
{
    if (m_physicsSystem == nullptr)
    {
        //Setup physics component via reference to pointer to this gameobject
        m_physicsSystem = new GameObjectPhysics(this);
    }
    else
    {
        PlayAnimationFrame(deltaTime);
        //character inputs
        if (m_texture == nullptr)
        {
            m_colldiable = false;
        }
        else
        {
            m_colldiable = true;
        }
        HandleCharacterFacingDirection(deltaTime);
        //handle collisions
        if (m_texture != nullptr)
        {
            HandleTileMapCollisions();
        }
        //handle falling during jumps and when falling (smooth jumping with gravity physics system)
        if (m_falling)
        {
            m_physicsSystem->ApplyGravity(deltaTime);
        }
        else
        {
            //sets to 0 when the player collides with a floor
            m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x, 0));
            //reset doublejump
            m_doubleJumpUsed = false;
        }
        m_physicsSystem->UpdateVelocities(deltaTime);
        HandleRegen(deltaTime);
    }
}

/// <summary>
/// handles SDL events fvor the character class
/// </summary>
/// <param name="e"></param>
void Character::HandleEvents(SDL_Event e, float deltaTime)
{
    //input event polling
    switch (e.type)
    {
    case SDL_KEYDOWN:
        HandleKeyDownEvent(e,deltaTime);
        break;
    case SDL_KEYUP:
        HandleKeyUpEvent(e);
        break;
    case SDL_JOYBUTTONDOWN:
        //console inputs
        switch (e.jbutton.button)
        {
        case 11:
            HandleUpKeyDownInput(e, deltaTime);
            break;
        case 4:
            HandleUpKeyDownInput(e, deltaTime);
            break;
        case 13:
            HandleUpKeyDownInput(e, deltaTime);
            break;
        case 15:
            HandleRightKeyDownInput(e, deltaTime);
            break;
        case 14:
            HandleLeftKeyDownInput(e, deltaTime);
            break;
        }
        break;
    case SDL_JOYBUTTONUP:
        //console inputs
        switch (e.jbutton.button)
        {
        case 13:
            HandleLeftKeyReleaseInput(e);
            break;
        case 15:
            HandleRightKeyReleaseInput(e);
            break;
        }
        break;
    default:
        break;
    }
}

/// <summary>
/// Applies regen effect to the character constantly
/// </summary>
/// <param name="deltaTime"></param>
void Character::HandleRegen(float deltaTime)
{
    //regen effect after taking a hit (3 second timer until regen happens)
    m_timeSinceHit += deltaTime * 0.1f;
    m_evenTimeSinceHit = !m_evenTimeSinceHit;
    if (m_timeSinceHit >= 3 && m_hits < m_maxHits )
    {
        m_hits++;
    }
}

/// <summary>
/// handles keyboard keydown inputs
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleKeyDownEvent(SDL_Event e, float deltaTime)
{
    switch (e.key.keysym.sym)
    {
        //Windows inputs
    case SDLK_LEFT:
        HandleLeftKeyDownInput(e,deltaTime);
        break;
    case SDLK_RIGHT:
        HandleRightKeyDownInput(e,deltaTime);
        break;
    case SDLK_UP:
        HandleUpKeyDownInput(e,deltaTime);
        break;
    default:
        break;
    }
}
/// <summary>
/// handles keyboard key up inputs
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleKeyUpEvent(SDL_Event e)
{
    switch (e.key.keysym.sym)
    {
    case SDLK_LEFT:
        HandleLeftKeyReleaseInput(e);
        break;
    case SDLK_RIGHT:
        HandleRightKeyReleaseInput(e);
        break;
    default:
        break;
    }
}

/// <summary>
/// handles left keydown input
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleLeftKeyDownInput(SDL_Event e, float deltaTime)
{
    m_facingDirection = FACING_LEFT;
    if (!m_movingLeft)
    {
        m_physicsSystem->SetVelocity(Vector2D(MOVEMENT_SPEED , m_physicsSystem->GetVelocity().y));
    }
    m_movingRight = false;
    m_movingLeft = true;
}

/// <summary>
/// handles right keydown input
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleRightKeyDownInput(SDL_Event e, float deltaTime)
{
    m_facingDirection = FACING_RIGHT;
    if (!m_movingRight)
    {
        m_physicsSystem->SetVelocity(Vector2D(MOVEMENT_SPEED , m_physicsSystem->GetVelocity().y));
    }
    m_movingRight = true;
    m_movingLeft = false;
}

/// <summary>
/// handles up keydown input
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleUpKeyDownInput(SDL_Event e, float deltaTime)
{
    if (!m_falling)
    {
        switch (m_powerUp)
        {
            case None:
                SetAnimation(m_jumpAnim);
                break;
            case DoubleJump:
                SetAnimation(m_doubleJumpJumpAnim);
                break;
            case Helmet:
                SetAnimation(m_helmetJumpAnim);
                break;
            case Climb:
                SetAnimation(m_climbIdleAnim);
                break;
            default:
                break;
        }
        Jump(deltaTime);
    }
    else if (m_powerUp == DoubleJump && !m_doubleJumpUsed)
    {
        SetAnimation(m_doubleJumpJumpAnim);
        m_doubleJumpUsed = true;
        Jump(deltaTime);
    }
    else if (m_falling)
    {
        switch (m_powerUp)
        {
        case None:
            SetAnimation(m_idleAnim);
            break;
        case DoubleJump:
            SetAnimation(m_idleDoubleJumpAnim);
            break;
        case Helmet:
            SetAnimation(m_idleHelmetAnim);
            break;
        case Climb:
            SetAnimation(m_climbIdleAnim);
            break;
        default:
            break;
        }
    }
}

/// <summary>
/// handles left keyup input
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleLeftKeyReleaseInput(SDL_Event e)
{
    m_movingRight = false;
    m_movingLeft = false;
    m_physicsSystem->SetVelocity(Vector2D(0, m_physicsSystem->GetVelocity().y));
}

/// <summary>
/// handles right keyup input
/// </summary>
/// <param name="e"></param>
/// <param name="deltaTime"></param>
void Character::HandleRightKeyReleaseInput(SDL_Event e)
{
    m_movingRight = false;
    m_movingLeft = false;
    m_physicsSystem->SetVelocity(Vector2D(0, m_physicsSystem->GetVelocity().y));
}

/// <summary>
/// sets character facing direction based on moving direction
/// </summary>
/// <param name="deltaTime"></param>
void Character::HandleCharacterFacingDirection(float deltaTime)
{
    if (m_movingLeft)
    {
        MoveLeft(deltaTime);
    }
    else if (m_movingRight)
    {
        MoveRight(deltaTime);
    }
}

/// <summary>
/// applies damage to the player and handles death when hits go to 0 or below
/// </summary>
void Character::TakeDamage()
{
    if (m_timeSinceHit > 1)
    {
        m_hits -= 1;
        m_timeSinceHit = 0;
        //check if dead after that hit
        if (m_hits <= 0 && m_isDead == false)
        {
            m_isDead = true;
            m_SFXDeath->Play(0);
            SDL_Event userEvent;
            userEvent.type = SDL_USEREVENT;
            userEvent.user.code = 7;
            SDL_PushEvent(&userEvent);
        }
        else
        {
            //if player is hit but not dead plays hit sound
            m_SFXHit->Play(0);
        }
    }
}

/// <summary>
/// handles character tile map collisions
/// </summary>
void Character::HandleTileMapCollisions()
{
    Rect2D box = GetCollisionBox();
    Vector2D gridPos = m_tileMap->WorldToGridPosition(Vector2D(box.x, box.y));
    //check player and tilemap collision
    bool collidingDown = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(0, 1)) || Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, Rect2D(box.x + box.width - 1, box.y + 1, 1, box.height), Vector2D(0, 1));
    bool collidingUp = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(0, -1)) || Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, Rect2D(box.x + box.width - 1, box.y, 1, box.height), Vector2D(0, -1));
    bool collidingRight = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(1, 0));
    bool collidingLeft = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, box, Vector2D(0, 0));
    //ground check
    Rect2D groundCheckBox = GetCollisionBox();
    groundCheckBox.y += 1;
    bool groundCheck = Collisions::Instance()->TileMapCheckAdjacentTile(m_tileMap, groundCheckBox, Vector2D(0, 0));
    if (!groundCheck)
    {
        SetFallingState(true);
    }
    //wall jump checks
    bool Climbed = false;
    if (m_position.y > 50)
    {
        Climbed = HandleClimbCollisions(collidingDown, collidingUp, collidingRight, collidingLeft);
    }
    if (!Climbed)
    {
        HandleNonClimbCollisions( collidingDown,  collidingUp,  collidingRight,  collidingLeft);
    }
}

/// <summary>
/// handles character collisions in the wall jump state
/// </summary>
/// <param name="collidingRight"></param>
/// <param name="collidingLeft"></param>
/// <returns></returns>
bool Character::HandleClimbCollisions(bool collidingDown, bool collidingUp, bool collidingRight, bool collidingLeft)
{
    bool Climbed = false;
    Rect2D box = GetCollisionBox();
    Vector2D gridPos = m_tileMap->WorldToGridPosition(Vector2D(box.x, box.y));
    if (collidingRight && GetPowerUp() == Climb)
    {
        HandleTileMapRightCollision(box, gridPos);
        m_physicsSystem->SetVelocity(Vector2D(0, -0.5*JUMP_SPEED));
        Climbed = true;
    }
    else if (collidingLeft && GetPowerUp() == Climb)
    {
        HandleTileMapLeftCollision(box, gridPos);
        m_physicsSystem->SetVelocity(Vector2D(0, -0.5 * JUMP_SPEED));
        Climbed = true;
    }
    return Climbed;
}

/// <summary>
/// handles character collisions when not in wall jump state
/// </summary>
/// <param name="collidingDown"></param>
/// <param name="collidingUp"></param>
/// <param name="collidingRight"></param>
/// <param name="collidingLeft"></param>
void Character::HandleNonClimbCollisions(bool collidingDown, bool collidingUp, bool collidingRight, bool collidingLeft)
{
    Rect2D box = GetCollisionBox();
    Vector2D gridPos = m_tileMap->WorldToGridPosition(Vector2D(box.x, box.y));
    //handle specific case tilemap collision, DO NOT USE SWITCH CASE AS MULTIPLE CAN BE THE CASE IN THE SAME FRAME
    if (collidingDown && m_physicsSystem->GetVelocity().y >= 0)
    {
        HandleTileMapDownCollision(box, gridPos);
    }
    if (collidingUp)
    {
        HandleTileMapUpCollision(box, gridPos);
    }
    box = GetCollisionBox();
    gridPos = m_tileMap->WorldToGridPosition(Vector2D(box.x, box.y));
    if (collidingRight)
    {
        if (m_position.y > 50)
        {
            HandleTileMapRightCollision(box, gridPos);
        }
    }
    if (collidingLeft)
    {
        HandleTileMapLeftCollision(box, gridPos);
    }
}

/// <summary>
/// handles down collision on tilemap
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Character::HandleTileMapDownCollision(Rect2D box, Vector2D gridPos)
{
    //Lava check first to see if the calculation even needs to happen
    if (m_tileMap->GetTile(gridPos.x, gridPos.y + 1)->m_tileType == TileType::Lava)
    {
        TakeDamage();
    }
    //Correcting Tile values calculation
    //down
    Vector2D downCollisionGridPos = Vector2D(gridPos.x, gridPos.y + 1);
    Tile* downCollisionTile = m_tileMap->GetTile((int)downCollisionGridPos.x, (int)downCollisionGridPos.y);
    Vector2D downCollisionWorldPos = downCollisionTile->m_position;
    float downCorrectedY = downCollisionWorldPos.y - box.height;
    //position and velocity correction 
    SetPosition(Vector2D(box.x, downCorrectedY));
    m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x, 0));
    SetFallingState(false);
}

/// <summary>
/// handles up collision on tilemap
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Character::HandleTileMapUpCollision(Rect2D box, Vector2D gridPos)
{
    //Lava check first to see if the calculation even needs to happen
    if (m_tileMap->GetTile(gridPos.x, gridPos.y)->m_tileType == TileType::Lava)
    {
        TakeDamage();
    }
    //Correcting Tile values calculation
    //up
    Vector2D upCollisionGridPos = Vector2D(gridPos.x, gridPos.y);
    Tile* upCollisionTile = m_tileMap->GetTile((int)upCollisionGridPos.x, (int)upCollisionGridPos.y);
    Vector2D upCollisionWorldPos = upCollisionTile->m_position;
    float upCorrectedY = upCollisionWorldPos.y + Tile::TILE_HEIGHT;
    //position and velocity correction 
    SetPosition(Vector2D(box.x, upCorrectedY));
    m_physicsSystem->SetVelocity(Vector2D(m_physicsSystem->GetVelocity().x , 0));
    SetFallingState(true);
}

/// <summary>
/// handles left collision on tilemap
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Character::HandleTileMapLeftCollision(Rect2D box, Vector2D gridPos)
{
    //Lava check first to see if the calculation even needs to happen
    if (m_tileMap->GetTile(gridPos.x - 1, gridPos.y)->m_tileType == TileType::Lava)
    {
        TakeDamage();
    }
    //Correcting Tile values calculation
    //left
    Vector2D leftCollisionGridPos = Vector2D(gridPos.x - 1, gridPos.y);
    Tile* leftCollisionTile = m_tileMap->GetTile((int)leftCollisionGridPos.x, (int)leftCollisionGridPos.y);
    Vector2D leftCollisionWorldPos = leftCollisionTile->m_position;
    float leftCorrectedX = leftCollisionWorldPos.x + 2 * Tile::TILE_WIDTH;
    //position and velocity correction 
    SetPosition(Vector2D(leftCorrectedX, box.y));
    m_physicsSystem->SetVelocity(Vector2D(0, m_physicsSystem->GetVelocity().y));
}

/// <summary>
/// handles right collision on tilemap
/// </summary>
/// <param name="box"></param>
/// <param name="gridPos"></param>
void Character::HandleTileMapRightCollision(Rect2D box, Vector2D gridPos)
{
    //Lava check first to see if the calculation even needs to happen
    if (m_tileMap->GetTile(gridPos.x + 1, gridPos.y)->m_tileType == TileType::Lava)
    {
        TakeDamage();
    }
    //Correcting Tile values calculation
    //right
    Vector2D rightCollisionGridPos = Vector2D(gridPos.x + 1, gridPos.y);
    Tile* rightCollisionTile = m_tileMap->GetTile((int)rightCollisionGridPos.x, (int)rightCollisionGridPos.y);
    Vector2D rightCollisionWorldPos = rightCollisionTile->m_position;
    float rightCorrectedX = rightCollisionWorldPos.x - Tile::TILE_WIDTH;
    //position and velocity correction 
    SetPosition(Vector2D(rightCorrectedX, box.y));
    m_physicsSystem->SetVelocity(Vector2D(0, m_physicsSystem->GetVelocity().y));
}

/// <summary>
/// initialises audio
/// </summary>
void Character::InitAudio()
{
    //jump
    m_SFXJump = new Audio("AudioFiles/SFX_Jump.wav");
    m_SFXJump->SetVolume(100);
    //death
    m_SFXDeath = new Audio("AudioFiles/SFX_Death.wav");
    m_SFXDeath->SetVolume(100);
    //hit
    m_SFXHit = new Audio("AudioFiles/SFX_Hit.wav");
    m_SFXHit->SetVolume(100);

}