#pragma once
#include <SDL_mixer.h>
#include <string>
#include <iostream>

class Audio
{
private:
	Mix_Chunk* m_chunk = nullptr;
	int m_channel;

public:
	Audio(std::string path);
	~Audio();

	void LoadFromFile(std::string path);
	void Play(int loopNum);
	void Pause() { Mix_Pause(m_channel); } ;
	void SetVolume(int newVolume) { Mix_Volume(m_channel, newVolume); } ;
};


