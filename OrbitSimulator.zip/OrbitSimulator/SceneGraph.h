#pragma once
#include <iostream>
#include "structures.h"
#include "SceneObject.h"

class SceneGraph
{
private:
	SceneGraphNode* head = nullptr;

public:
	SceneGraph()
	{
	}

	SceneGraph(SceneGraphNode* d)
	{
		head = d;
	}

	~SceneGraph()
	{
		DeleteNodePtrs(head);
	}

	/// <summary>
	/// deletes all ndoe pointers when called with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	void DeleteNodePtrs(SceneGraphNode* currentNode)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			DeleteNodePtrs(currentNode->left);
		}
		if (currentNode->right != nullptr)
		{
			DeleteNodePtrs(currentNode->right);
		}
		delete currentNode;
	}

	/// <summary>
	/// set every item in the scene graph to be selected with pre order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	/// <param name="state"></param>
	void SetSelectedPreOrder(SceneGraphNode* currentNode, bool state)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		currentNode->data->SetSelected(state);
		if (currentNode->left != nullptr)
		{
			SetSelectedPreOrder(currentNode->left, state);
		}
		if (currentNode->right != nullptr)
		{
			SetSelectedPreOrder(currentNode->right, state);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	///  set every item in the scene graph to be selected with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	/// <param name="state"></param>
	void SetSelectedInOrder(SceneGraphNode* currentNode, bool state)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetSelectedInOrder(currentNode->left, state);
		}
		currentNode->data->SetSelected(state);
		if (currentNode->right != nullptr)
		{
			SetSelectedInOrder(currentNode->right, state);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	///  set every item in the scene graph to be selected with post order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	/// <param name="state"></param>
	void SetSelectedPostOrder(SceneGraphNode* currentNode, bool state)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetSelectedPostOrder(currentNode->left, state);
		}
		if (currentNode->right != nullptr)
		{
			SetSelectedPostOrder(currentNode->right, state);
		}
		currentNode->data->SetSelected(state);
		currentNode = currentNode->parent;
	}


	/// <summary>
	///  set every item in the scene grap material with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	void SetMaterialInOrder(SceneGraphNode* currentNode)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetMaterialInOrder(currentNode->left);
		}
		if (currentNode->data->GetSelectedState())
		{
			currentNode->data->SetMaterial(currentNode->data->m_selectedMaterial);
		}
		else
		{
			currentNode->data->SetMaterial(currentNode->data->m_unselectedMaterial);
		}
		if (currentNode->right != nullptr)
		{
			SetMaterialInOrder(currentNode->right);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	/// set every item in the scene graph texture with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	/// <param name="tex"></param>
	void SetTextureInOrder(SceneGraphNode* currentNode, Texture2D* tex)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetTextureInOrder(currentNode->left,tex);
		}
		currentNode->data->SetTexture(tex);
		if (currentNode->right != nullptr)
		{
			SetTextureInOrder(currentNode->right,tex);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	/// set every item's rotation in the scene graph with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	void SetRotationInOrder(SceneGraphNode* currentNode)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetRotationInOrder(currentNode->left);
		}
		currentNode->data->RotateAll(Vector3(1,1,1),1);
		if (currentNode->right != nullptr)
		{
			SetRotationInOrder(currentNode->right);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	/// set every item's roll rotation in the scene graph with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	void SetRotationRollInOrder(SceneGraphNode* currentNode)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetRotationRollInOrder(currentNode->left);
		}
		currentNode->data->RotateRoll(1,1);
		if (currentNode->right != nullptr)
		{
			SetRotationRollInOrder(currentNode->right);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	/// set every item's yaw rotation in the scene graph with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	void SetRotationYawInOrder(SceneGraphNode* currentNode)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetRotationYawInOrder(currentNode->left);
		}
		currentNode->data->RotateYaw(1, 1);
		if (currentNode->right != nullptr)
		{
			SetRotationYawInOrder(currentNode->right);
		}
		currentNode = currentNode->parent;
	}

	/// <summary>
	/// set every item's pithc rotation in the scene graph with in order traversal
	/// </summary>
	/// <param name="currentNode"></param>
	void SetRotationPitchInOrder(SceneGraphNode* currentNode)
	{
		if (currentNode == nullptr)
		{
			return;
		}
		if (currentNode->left != nullptr)
		{
			SetRotationPitchInOrder(currentNode->left);
		}
		currentNode->data->RotatePitch(1, 1);
		if (currentNode->right != nullptr)
		{
			SetRotationPitchInOrder(currentNode->right);
		}
		currentNode = currentNode->parent;
	}

};