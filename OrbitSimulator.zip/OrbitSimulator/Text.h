#pragma once
#include "Structures.h"
#include <String>

class Text
{
private:
	Vector3 m_position;
	Color m_color = Color(0,0,0);
public:
	Text(const char* text, Vector3 position, Color color);
	~Text();
	void DrawString(const char* text, Vector3* position, Color* color);
	void DrawString();
	void SetPosition(Vector3 position) { m_position = position; } ;
	void SetColor(Color color) { m_color = color; };
	std::string m_text = "";
};

