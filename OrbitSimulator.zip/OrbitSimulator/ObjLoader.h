#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include "Structures.h"
#include "LinkedList.h"
#include <vector>
#include <vector>
#define NOMINMAX 
#include <Windows.h>
#include <algorithm>

using namespace std;

class ObjLoader
{
public:
	ObjLoader();
	~ObjLoader();
	Mesh* LoadTextured(const char* path);

private:
	void CalculateMeshRadii(Mesh* mesh);
	void ReadObjFile(string path, vector<Vector3>& tempPositions, vector<Vector3>& tempNormals, vector<Vector2>& tempUVs, vector<Vertex>& tempVertices, vector<GLushort>& tempIndices);
};

