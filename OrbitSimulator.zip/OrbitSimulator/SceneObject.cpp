#include "SceneObject.h"

SceneObject:: SceneObject(Mesh* mesh, Texture2D* texture, float x, float y, float z)
{
	m_position.x = x;
	m_position.y = y;
	m_position.z = z;
	m_texture = texture;
	m_mesh = mesh;
	InitMaterials();
}

/// <summary>
/// initialises materials that will be used for each object and sets the default material value
/// </summary>
void SceneObject::InitMaterials()
{
	m_selectedMaterial = new Material(Vector4(0.2, 1, 0.2, 1), Vector4(0.2, 1, 0.2, 1), Vector4(0, 1, 0, 1), 128);
	m_unselectedMaterial = new Material(Vector4(0.2, 0.2, 0.2, 1), Vector4(0.2, 0.2, 0.2, 1), Vector4(0.5f, 0.5f, 0.5f, 0.1f), 1);
	SetMaterial(m_unselectedMaterial);
}

void SceneObject::Update()
{
}

/// <summary>
/// draws the sceneobject based on its mesh textures normals and textures in world space
/// </summary>
void SceneObject::Draw()
{
	glBindTexture(GL_TEXTURE_2D, m_texture->GetID());
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	//init Vertices + vertex data
	glVertexPointer(3, GL_FLOAT, sizeof(Vertex), m_mesh->Vertices);
	glTexCoordPointer(2, GL_FLOAT, sizeof(Vertex), m_mesh->Vertices);
	glNormalPointer(GL_FLOAT, sizeof(Vertex), m_mesh->Vertices);
	//material setup
	glMaterialfv(GL_FRONT, GL_AMBIENT, &(m_material->Ambient.x));
	glMaterialfv(GL_FRONT, GL_DIFFUSE, &(m_material->Diffuse.x));
	glMaterialfv(GL_FRONT, GL_SPECULAR, &(m_material->Specular.x));
	glMaterialf(GL_FRONT, GL_SHININESS, (m_material->Shininess));
	glMaterialfv(GL_FRONT, GL_EMISSION, emission);
	glPushMatrix();
	//rotate and translate + draw
	glTranslatef(m_position.x, m_position.y, m_position.z);
	glRotatef(m_roll, 1, 0, 0);
	glRotatef(m_yaw, 0, 1, 0);
	glRotatef(m_pitch, 0, 0, 1);
	glScalef(m_scaleX, m_scaleY, m_scaleZ);
	glDrawElements(GL_TRIANGLES, m_mesh->IndexCount, GL_UNSIGNED_SHORT, m_mesh->Indices);
	glPopMatrix();
	//disable uneeded stacks
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

/// <summary>
/// scales all aspects of the object 
/// </summary>
/// <param name="scale"></param>
void SceneObject::SetScale(float scale)
{
	m_scaleX = scale;
	m_scaleY = scale;
	m_scaleZ = scale;
	m_radiusX *= m_scaleX;
	m_radiusY *= m_scaleY;
	m_radiusZ *= m_scaleZ;
}

/// <summary>
/// scales X value of the object
/// </summary>
/// <param name="scale"></param>
void SceneObject::SetScaleX(float scale)
{
	m_scaleX = scale;
	m_radiusX *= m_scaleX;
}

/// <summary>
/// scales Y value of the object
/// </summary>
/// <param name="scale"></param>
void SceneObject::SetScaleY(float scale)
{
	m_scaleY = scale;
	m_radiusY *= m_scaleY;
}

/// <summary>
/// scales Z value of the object
/// </summary>
/// <param name="scale"></param>
void SceneObject::SetScaleZ(float scale)
{
	m_scaleZ = scale;
	m_radiusZ *= m_scaleZ;
}

/// <summary>
/// rotates the object on X plane
/// </summary>
/// <param name="roll"></param>
/// <param name="direction"></param>
void SceneObject::RotateRoll(float roll, int direction)
{
	m_roll += roll * direction;
}

/// <summary>
/// rotates the object on Y plane
/// </summary>
/// <param name="yaw"></param>
/// <param name="direction"></param>
void SceneObject::RotateYaw(float yaw, int direction)
{
	m_yaw += yaw * direction;
}

/// <summary>
/// rotates the object on Z plane
/// </summary>
/// <param name="pitch"></param>
/// <param name="direction"></param>
void SceneObject::RotatePitch(float pitch, int direction)
{
	m_pitch += pitch * direction;
}

/// <summary>
/// rotates the object on all planes
/// </summary>
/// <param name="rotation"></param>
/// <param name="direction"></param>
void SceneObject::RotateAll(Vector3 rotation, int direction)
{
	m_roll += rotation.x * direction;
	m_yaw += rotation.y * direction;
	m_pitch += rotation.z * direction;
}