#pragma once
#include "Structures.h"
#include "Texture2D.h"
#include "Camera.h"

class skyBox
{
public:
	skyBox(Mesh* mesh, Texture2D* texture, float x, float y, float z, Camera* cam);
	~skyBox();
	void Update();
	void Draw();

private:
	Mesh* m_mesh = nullptr;
	Texture2D* m_texture = nullptr;
	Vector3 m_position;
	Camera* m_cam = nullptr;
};

