#pragma once
#include <cmath>

class Vector3
{
private:

public:
	Vector3();
	Vector3(float _x, float _y, float _z);
	~Vector3();
	float x = 0;
	float y = 0;
	float z = 0;
	Vector3 operator*(float scalar);
	Vector3 operator+(const Vector3& OtherVector3);
	Vector3 operator-(const Vector3& OtherVector3);
	Vector3 operator-();
	Vector3 Normalized();
	float Distance(Vector3& v1, Vector3& v2);
	float Magnitude();
	float Dot(Vector3& v1, Vector3& v2);
	float CalculateDistanceSquared(Vector3 point1, Vector3 point2);
};