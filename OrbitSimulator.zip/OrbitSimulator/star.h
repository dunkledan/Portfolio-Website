#pragma once
#include "SceneObject.h"

class star : public SceneObject
{
public:
	star(Mesh* mesh, Texture2D* texture, float x, float y, float z);
	~star();
	void Update();
	void Draw();
	Vector4* GetLightPos() { return m_lightPosition; };
	Lighting* GetLightData() { return m_lightData; };
	void UpdateLights();

protected:
	Vector4 m_emmisionLightPos = Vector4(m_position.x, m_position.y, m_position.z, 1);
	GLfloat emission[4];
	Vector4* m_lightPosition = nullptr;
	Lighting* m_lightData = nullptr;
	void InitMaterials();

};

