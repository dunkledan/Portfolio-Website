#pragma once

class Scene1;

namespace GLUTCallbacks
{
	void Init(Scene1* gl);

	void Display();

	void Timer(int preferredRefersh);

	void Keyboard(unsigned char key, int x, int y);

	void MouseMovementInput(int x, int y);

	void MouseClickInput(int a, int b, int c, int d);

	void KeyboardSpecial(int key, int x, int y);

	void Close();
};