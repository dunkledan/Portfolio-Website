#include "Camera.h"

/// <summary>Camera Initialisation</summary>
Camera::Camera(Vector3 eye, Vector3 centre, Vector3 up)
{
	m_eye = eye;
	m_centre = centre;
	m_up = up;
}

Camera::~Camera()
{

}

/// <summary>Setups up view port for the camera </summary>
void Camera::CamPerspectiveSetup()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//set cam viewport to entire window size
	glViewport(0, 0, 800, 800);
	//Set correct camera perspective (FOV,aspect ratio,nearplane,farplane)
	gluPerspective(45, 1, 1, 1000);
	//model veiw matrix to work with rendered models in world space
	glMatrixMode(GL_MODELVIEW);
}

/// <summary>Updates where the camera looks at each frame based on previous operations to the camera</summary>
void Camera::Update()
{
	//camera looks at correct position
	gluLookAt(m_eye.x, m_eye.y, m_eye.z, m_centre.x, m_centre.y, m_centre.z, m_up.x, m_up.y, m_up.z);
}

/// <summary>Moves camera forward through the z plane based on camera speed</summary>
void Camera::MoveForward()
{
	//moves camera position forward based on direction camera is looking
	m_eye = m_eye + m_direction * m_speed;
	m_centre = m_centre + m_direction * m_speed;
}

/// <summary>Moves camera backward through the z plane based on camera speed</summary>
void Camera::MoveBackwards()
{
	//moves camera position backwards based on direction camera is looking
	m_eye = m_eye - m_direction * m_speed;
	m_centre = m_centre - m_direction * m_speed;
}

/// <summary>Moves camera left on the x plane based on camera speed</summary>
void Camera::MoveLeft()
{
	//moves camera position left based on direction camera is looking
	m_eye.x += m_direction.z * m_speed;
	m_eye.z += -m_direction.x * m_speed;
	m_centre.x += m_direction.z * m_speed;
	m_centre.z += -m_direction.x * m_speed;
}

/// <summary>Moves camera right on the x plane based on camera speed</summary>
void Camera::MoveRight()
{
	//moves camera position right based on direction camera is looking
	m_eye.x -= m_direction.z * m_speed;
	m_eye.z -= -m_direction.x * m_speed;
	m_centre.x -= m_direction.z * m_speed;
	m_centre.z -= -m_direction.x * m_speed;
}

void Camera::LookAt(Vector3 pos)
{
	m_centre = Vector3(pos.x, pos.y, pos.z);
}

/// <summary>Moves camera viewportr to look towards the mouse in 3D world space when moved using callbacks</summary>
void Camera::HandleMouseLook(int x, int y)
{
	static bool firstMouse = true;
	static float lastframeX = 0.0f;
	static float lastframeY = 0.0f;
	//when first moving move centres the position of camera looking properly to where the mouse is
	if (firstMouse)
	{
		lastframeX = x;
		lastframeY = y;
		firstMouse = false;
	}
	//change in x this frame calculated
	float deltaX = x - lastframeX;
	float deltaY = y - lastframeY;
	//update last frame x and y vals
	lastframeX = x;
	lastframeY = y;
	//update yaw and pitch
	m_yaw += deltaX * m_sensitivity;
	m_pitch += -deltaY * m_sensitivity;
	//adjusts the camera yaw and pitch by one radian
	float radYaw = m_yaw * rad;
	float radPitch = m_pitch * rad;
	//calculating appropriate camera direciton+ updating
	m_direction = Vector3(cosf(radYaw) * cosf(radPitch), sinf(radPitch), sinf(radYaw) * cosf(radPitch));
	m_centre = m_eye + m_direction;
}

