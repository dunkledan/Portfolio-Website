#pragma once
#include "Structures.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

class Texture2D
{
private:
	GLuint m_ID;
	int m_width;
	int m_height;
	
public:
	Texture2D();
	~Texture2D();

	bool LoadRAW(const char* path, int width, int height);
	int GetWidth() const { return m_width; };
	int GetHeigh() const { return m_height; };
	GLuint GetID() const { return m_ID; };
	void SetID(GLuint ID) { m_ID = ID; };
};

