#include "tgaLoader.h"

tgaLoader::tgaLoader()
{
}

tgaLoader::~tgaLoader()
{
}

/// <summary>
/// loads texture based on TGA file format and vinds it to next available ID
/// </summary>
/// <param name="textureFileName"></param>
/// <returns></returns>
int tgaLoader::LoadTextureTGA(const char* textureFileName)
{
    //allows texture to be in colour
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    GLuint ID = 0;
    //inits tga header size as 18 (TGA file)
    char* tempHeaderData = new char[18]; 
    char* tempTextureData;
    int fileSize;
    char type, pixelDepth, mode;
    ifstream inFile;
    inFile.open(textureFileName, ios::binary);
    //defensive programming
    if (!inFile.good())
    {
        cerr << "Can't open texture file " << textureFileName << endl;
        return -1;
    }
    //read all data in file
    inFile.seekg(0, ios::beg); 
    inFile.read(tempHeaderData, 18); 
    //get file size
    inFile.seekg(0, ios::end); 
    fileSize = (int)inFile.tellg() - 18;
    //create storage for texture data and go back to load file
    tempTextureData = new char[fileSize]; 
    inFile.seekg(18, ios::beg); 
    inFile.read(tempTextureData, fileSize); 
    inFile.close(); 
    //get TGA type
    type = tempHeaderData[2];
    //find width, height & pixel depth of texture from header
    int _width = ((unsigned char)tempHeaderData[13] << 8u) + (unsigned char)tempHeaderData[12]; 
    int _height = ((unsigned char)tempHeaderData[15] << 8u) + (unsigned char)tempHeaderData[14]; 
    pixelDepth = tempHeaderData[16]; 
    //handling flipping of texture
    bool flipped = false;
    if ((int)((tempHeaderData[11] << 8) + tempHeaderData[10]) == 0)
    {
        flipped = true;
    }
    //continue if RGB type
    if (type == 2)
    {
        //generate and bind texture to next available ID
        glGenTextures(1, &ID); 
        glBindTexture(GL_TEXTURE_2D, ID); 
        //build mip maps based on pixel depth
        mode = pixelDepth / 8;
        if (mode == 4)
        {
            gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, _width, _height, GL_BGRA_EXT, GL_UNSIGNED_BYTE, tempTextureData);
        }
        else
        {
            gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, _width, _height, GL_BGR_EXT, GL_UNSIGNED_BYTE, tempTextureData);
        }
    }
    //deallocate memory 
    delete[] tempHeaderData;
    delete[] tempTextureData;
    //init tex parameters for this texture
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    return ID;
}