#pragma once

#define PI 3.1415
#define rad PI / 180