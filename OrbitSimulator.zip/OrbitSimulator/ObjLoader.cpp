#include "ObjLoader.h"

using namespace std;

/// <summary>
/// Loads a textured mesh from a standard Triangle OBJ file
/// </summary>
/// <param name="path"></param>
/// <returns></returns>
Mesh* ObjLoader::LoadTextured(const char* path)
{
    ifstream inFile(path);
    if (!inFile.good())
    {
        cerr << "Can't open obj file " << path << endl;
        return nullptr;
    }
    //init vectors to push files data to and read mesh values from
    vector<Vector3> tempPositions;
    vector<Vector3> tempNormals;
    vector<Vector2> tempUVs;
    vector<Vertex> tempVertices;
    vector<GLushort> tempIndices;
    //read object file data
    ReadObjFile(path, tempPositions, tempNormals, tempUVs, tempVertices, tempIndices);
    //init array sizes for mesh
    Mesh* mesh = new Mesh();
    mesh->VertexCount = tempVertices.size();
    mesh->IndexCount = tempIndices.size();
    mesh->Vertices = new Vertex[mesh->VertexCount];
    mesh->Indices = new GLushort[mesh->IndexCount];
    //push vertex data into Vertices + indicies arrays
    for (int i = 0; i < mesh->VertexCount; i++)
    {
        mesh->Vertices[i] = tempVertices[i];
    }
    for (int i = 0; i < mesh->IndexCount; i++)
    {
        mesh->Indices[i] = tempIndices[i];
    }
    //radius calculation
    CalculateMeshRadii(mesh);
    return mesh;
}

/// <summary>
/// calculates the gratest distance between two points on the final mesh to calculate the radius of the mesh
/// </summary>
/// <param name="mesh"></param>
void ObjLoader::CalculateMeshRadii(Mesh* mesh)
{
    float maxDistance = 0;
    for (int i = 0; i < mesh->VertexCount; i++)
    {
        float distance = sqrt(mesh->Vertices[i].x * mesh->Vertices[i].x + mesh->Vertices[i].y * mesh->Vertices[i].y + mesh->Vertices[i].z * mesh->Vertices[i].z);
        if (distance > maxDistance)
        {
            maxDistance = distance;
        }
    }
    mesh->m_radiusX = maxDistance;
    mesh->m_radiusY = maxDistance;
    mesh->m_radiusZ = maxDistance;
}

void ObjLoader::ReadObjFile(string path, vector<Vector3> &tempPositions, vector<Vector3> &tempNormals,vector<Vector2> &tempUVs,vector<Vertex> &tempVertices,vector<GLushort> &tempIndices)
{
    ifstream inFile(path);
    string line;
    while (getline(inFile, line))
    {
        stringstream ss(line);
        string prefix;
        ss >> prefix;
        //vertices
        if (prefix == "v")
        {
            Vector3 vertex;
            ss >> vertex.x >> vertex.y >> vertex.z;
            tempPositions.push_back(vertex);
        }
        // normals
        else if (prefix == "vn")
        {
            Vector3 normal;
            ss >> normal.x >> normal.y >> normal.z;
            tempNormals.push_back(normal);
        }
        // text coords
        else if (prefix == "vt")
        {
            Vector2 textcoordVector;
            ss >> textcoordVector.x >> textcoordVector.y;
            tempUVs.push_back(textcoordVector);
        }
        // faces
        else if (prefix == "f")
        {
            string vertexString;
            while (ss >> vertexString)
            {
                stringstream ss(vertexString);
                string vertex, texcoord, normal;
                //read each coord in each section of faces
                getline(ss, vertex, '/');
                getline(ss, texcoord, '/');
                getline(ss, normal, '/');
                //index conversion
                int vertexIndex = stoi(vertex) - 1;
                int normalIndex = stoi(normal) - 1;
                int textCoordsIndex = stoi(normal) - 1;
                Vertex vert;
                // position init
                vert.x = tempPositions[vertexIndex].x;
                vert.y = tempPositions[vertexIndex].y;
                vert.z = tempPositions[vertexIndex].z;
                // normals init
                vert.nx = tempNormals[normalIndex].x;
                vert.ny = tempNormals[normalIndex].y;
                vert.nz = tempNormals[normalIndex].z;
                //text coords init
                vert.u = tempUVs[textCoordsIndex].x;
                // flip v
                vert.v = 1.0f - tempUVs[textCoordsIndex].y;
                //store vertex data for pushing to arrays
                tempVertices.push_back(vert);
                tempIndices.push_back(tempVertices.size() - 1);
            }
        }
    }
}

ObjLoader::ObjLoader()
{
}

ObjLoader::~ObjLoader()
{
}