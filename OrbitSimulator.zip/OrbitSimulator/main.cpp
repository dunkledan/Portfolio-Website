#include "Scene1.h"

int main(int argc, char* argv[])
{
	Scene1* game = new Scene1(argc, argv);
	delete game;
	game = nullptr;
	return 0;
}