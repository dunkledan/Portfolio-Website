#pragma once
#include "Structures.h"
#include "Texture2D.h"

class SceneObject
{
protected:
	Mesh* m_mesh = nullptr;
	Texture2D* m_texture = nullptr;
	Material* m_material = nullptr;
	Vector3 m_position;
	float m_scaleX = 1;
	float m_scaleY = 1;
	float m_scaleZ = 1;
	GLfloat m_roll = 0;
	GLfloat m_yaw = 0;
	GLfloat m_pitch = 0;
	bool m_selected = false;
	float m_rotation = 0;
	GLfloat emission[4] = { 0,0,0,0 };
	virtual void InitMaterials();
	float m_radiusX = 0;
	float m_radiusY = 0;
	float m_radiusZ = 0;

public:
	SceneObject(Mesh* mesh, Texture2D* texture, float x, float y, float z);
	Vector3 GetPosition() { return m_position; };
	virtual void Update();
	virtual void Draw();
	float GetRadius() { return sqrt(pow((m_mesh->m_radiusX+ m_mesh->m_radiusY+ m_mesh->m_radiusZ),2)); };
	float GetRadiusX() { return m_radiusX; };
	float GetRadiusY() { return m_radiusY; };
	float GetRadiusZ() { return m_radiusZ; };
	void SetScale(float scale);
	void SetScaleX(float scale);
	void SetScaleY(float scale);
	void SetScaleZ(float scale);
	void RotateRoll(float roll, int direction);
	void RotateYaw(float yaw, int direction);
	void RotatePitch(float pitch, int direction);
	void RotateAll(Vector3 rotation, int direction);
	void SetTexture(Texture2D* texture) { m_texture = texture; };
	Texture2D* GetTexture() { return m_texture; };
	void SetMaterial(Material* mat) { m_material = mat; } ;
	void Translate(Vector3 amount) { m_position = m_position + amount; };
	void SetSelected(bool state) { m_selected = state; };
	Material* m_unselectedMaterial = nullptr;
	Material* m_selectedMaterial = nullptr;
	bool GetSelectedState() { return m_selected; };
};

