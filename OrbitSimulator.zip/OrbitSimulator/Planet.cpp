#include "Planet.h"

Planet::Planet(Mesh* mesh, Texture2D* texture, float x, float y, float z, float axisTilt) : SceneObject(mesh, texture, x, y, z)
{
	InitMaterials();
	m_axisTilt = axisTilt;
	RotatePitch(m_axisTilt,-1);
}

void Planet::InitMaterials()
{
	SceneObject::InitMaterials();
}

Planet::~Planet()
{
}

/// <summary>
/// Updates data about the planet every frame
/// </summary>
void Planet::Update()
{
	SceneObject::Update();
	if(!m_selected && m_star != nullptr)
	{
		Orbit();
		RotateYaw(m_axisTilt,1);
	}
	if (m_starPos.x != m_star->GetPosition().x || m_starPos.y != m_star->GetPosition().y || m_starPos.z != m_star->GetPosition().z)
	{
		m_starPos = m_star->GetPosition();
	}
}

void Planet::Draw()
{
	SceneObject::Draw();
}

/// <summary>
/// initialises all vales for the orbit of the planet
/// </summary>
/// <param name="orbitSpeed"></param>
/// <param name="starDistance"></param>
/// <param name="star"></param>
void Planet::InitOrbit(float orbitSpeed, float starDistance, star* star)
{
	m_orbitSpeed = orbitSpeed;
	m_starDistance = starDistance;
	m_star = star;
}

/// <summary>
/// causes the planet to orbit a specific position given the m_star member
/// </summary>
void Planet::Orbit()
{
	//force planets to stay orbiting centralised to the star position
	Vector3 targetPos;
	targetPos.x = m_starPos.x + sinf(m_theta ) * m_starDistance;
	targetPos.z = m_starPos.z + cosf(m_theta ) * m_starDistance;
	targetPos.y = m_star->GetPosition().y;
	float followSpeed = 0.025;
	m_position = m_position + (targetPos - m_position) * followSpeed;
	m_theta += m_orbitSpeed;
	if (m_theta > 2*PI)
	{
		m_theta = 0;
	}
}
