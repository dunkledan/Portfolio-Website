#include "Text.h"

Text::Text(const char* text, Vector3 position, Color color)
{
	m_text = text;
	m_position = position;
	m_color = color;
}

Text::~Text()
{
}

///<summary>Render text at the current position + color on the screen</summary>
void Text::DrawString()
{
	//renders text in ortho projection for easier transformations on the screen rather than in world space
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, glutGet(GLUT_SCREEN_WIDTH), 0, glutGet(GLUT_SCREEN_HEIGHT));
	//disable lighting and depth testing to make text always visible
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	//rennder text
	glPushMatrix();
	glColor3f(m_color.r, m_color.g, m_color.b);
	glRasterPos2f(m_position.x, m_position.y);
	glutBitmapString(GLUT_BITMAP_TIMES_ROMAN_24, (unsigned char*)m_text.c_str());
	glPopMatrix();
	//reenable required GL matrices + states
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}