#include "Vector3.h"

Vector3::Vector3()
{
}

Vector3::Vector3(float _x, float _y, float _z)
{
	x = _x;
	y = _y;
	z = _z;
}

Vector3::~Vector3()
{
}

Vector3 Vector3::operator*(float scalar)
{
	this->x = this->x * scalar;
	this->y = this->y * scalar;
	this->z = this->z * scalar;
	Vector3 newVector(x, y, z);
	return newVector;
}

Vector3 Vector3::operator+(const Vector3& OtherVector3)
{
	float newV2X = this->x + OtherVector3.x;
	float newV2Y = this->y + OtherVector3.y;
	float newV2Z = this->z + OtherVector3.z;
	Vector3 NewV2(newV2X, newV2Y, newV2Z);
	return NewV2;
}

Vector3 Vector3::operator-(const Vector3& OtherVector3)
{
	float newV2X = this->x - OtherVector3.x;
	float newV2Y = this->y - OtherVector3.y;
	float newV2Z = this->z - OtherVector3.z;
	Vector3 NewV2(newV2X, newV2Y, newV2Z);
	return NewV2;
}

Vector3 Vector3::operator-()
{
	Vector3 NewV2(this->x * -1, this->y * -1, this->z * -1);
	return NewV2;
}

Vector3 Vector3::Normalized()
{
	float Mag = Magnitude();
	float newX = x / Mag;
	float newY = y / Mag;
	float newZ = z / Mag;
	Vector3 NewV2(newX, newY, newZ);
	return NewV2;
}

float Vector3::Distance(Vector3& v1, Vector3& v2)
{
	Vector3 distanceVector((v1.x - v2.x), (v1.y - v2.y), (v1.z - v2.z));
	return distanceVector.Magnitude();
}

float Vector3::Magnitude()
{
	return sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
}

float Vector3::Dot(Vector3& v1, Vector3& v2)
{
	float xMult = v1.x * v2.x;
	float yMult = v1.y * v2.y;
	float zMult = v1.z * v2.z;
	float product = xMult + yMult + zMult;
	return product;
}

float Vector3::CalculateDistanceSquared(Vector3 point1, Vector3 point2)
{
	float distance = ((point1.x - point2.x) * (point1.x - point2.x)) + ((point1.y - point2.y) * (point1.y - point2.y)) + ((point1.z - point2.z) * (point1.z - point2.z));
	return distance;
}