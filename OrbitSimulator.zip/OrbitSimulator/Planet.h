#pragma once
#include "SceneObject.h"
#include "star.h"

class Planet : public SceneObject
{
public:
	Planet(Mesh* mesh, Texture2D* texture, float x, float y, float z, float axisTilt);
	~Planet();
	void Update();
	void Draw();
	void InitOrbit(float orbitSpeed, float starDistance, star* star);

protected:
	void InitMaterials();
	void Orbit();
	float m_orbitSpeed = 0;
	float m_starDistance = 0;
	star* m_star = nullptr;
	float m_axisTilt = 0;
	Vector3 m_starPos = Vector3();
	float m_theta = 0;
};

