#pragma once
#include <cmath>

class Vector2
{
private:
	
public:
	Vector2();
	Vector2(float _x, float _y);
	~Vector2();
	float x = 0;
	float y = 0;
	Vector2 operator*(float scalar);
	Vector2 operator+(const Vector2& OtherVector2);
	Vector2 operator-(const Vector2& OtherVector2);
	Vector2 operator-();
	Vector2 Normalized();
	float Distance(Vector2& v1, Vector2& v2);
	float Magnitude();
	float Dot(Vector2& v1, Vector2& v2);
	float CalculateDistanceSquared(Vector2 point1, Vector2 point2);
};