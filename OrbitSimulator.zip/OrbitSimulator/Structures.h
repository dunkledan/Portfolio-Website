#pragma once
#include <Windows.h>
#include <gl/GL.h>
#include <cmath>
#include <gl/GLU.h>
#include "GL/freeglut.h"
#include "GLUTCallbacks.h"
#include "Constants.h"
#include "Vector2.h"
#include "Vector3.h"

struct Color
{
	GLfloat r, g, b;
	Color()
	{
		r = 0;
		g = 0;
		b = 0;
	}
	Color(GLfloat _r, GLfloat _g, GLfloat _b)
	{
		r = _r;
		g = _g;
		b = _b;
	}
};

struct Vertex
{
	GLfloat x;
	GLfloat y;
	GLfloat z;
	GLfloat nx;
	GLfloat ny;
	GLfloat nz;
	GLfloat u;
	GLfloat v;
};

struct TexCoord
{
	//normalised coords of texels
	GLfloat u;
	GLfloat v;
};

struct Mesh
{
	Vertex* Vertices = nullptr;
	GLushort* Indices = nullptr;
	int VertexCount = 0;
	int IndexCount = 0;
	int TexCoordCount = 0;
	float m_radiusX = 0;
	float m_radiusY = 0;
	float m_radiusZ = 0;
};

struct Vector4
{
	float x = 0;
	float y = 0;
	float z = 0;
	float w = 0;
	Vector4()
	{
	}
	Vector4(float _x, float _y, float _z, float _w)
	{
		x = _x;
		y = _y;
		z = _z;
		w = _w;
	}
};

struct Lighting
{
	Vector4 Ambient;
	Vector4 Diffuse;
	Vector4 Specular;
	Lighting()
	{
	}
	Lighting(Vector4 A,Vector4 D,Vector4 S)
	{
		Ambient = A;
		Diffuse = D;
		Specular = S;
	}
};

struct Material
{
	Vector4 Ambient;
	Vector4 Diffuse;
	Vector4 Specular;
	GLfloat Shininess;
	Material()
	{
	}
	Material(Vector4 Amb,Vector4 Diff,Vector4 Spec,GLfloat Shiny)
	{
		Ambient = Amb;
		Diffuse = Diff;
		Specular = Spec;
		Shininess = Shiny;
	}
};

class SceneObject;

struct SceneGraphNode
{
	SceneGraphNode* left = nullptr;
	SceneGraphNode* right = nullptr;
	SceneGraphNode* parent = nullptr;
	SceneObject* data = nullptr;

	//constructors + overload constructors
	SceneGraphNode()
	{
		left = nullptr;
		right = nullptr;
		parent = nullptr;
		data = nullptr;
	}
	SceneGraphNode(SceneGraphNode* l, SceneGraphNode* r, SceneGraphNode* p, SceneObject* d)
	{
		left = l;
		right = r;
		parent = p;
		data = d;
	}
};