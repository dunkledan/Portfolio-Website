#include "star.h"

using namespace std;

star::star(Mesh* mesh, Texture2D* texture, float x, float y, float z): SceneObject(mesh,texture,x,y,z)
{
	InitMaterials();
}

void star::InitMaterials()
{
	m_selectedMaterial = new Material(Vector4(0.6, 1, 0.5, 0), Vector4(0.5, 1, 0.5, 1), Vector4(1, 1, 1, 1), 128);
	m_unselectedMaterial = new Material(Vector4(1, 1, 1, 1), Vector4(1, 0, 0, 1), Vector4(1, 0.9f, 0.9f, 1), 128);
	m_lightData = new Lighting(Vector4(1, 1, 1, 1), Vector4(1, 0, 0, 1), Vector4(1, 0.99f, 0.99f, 1));
	SetMaterial(m_unselectedMaterial);
	emission[0] = { 1};
	emission[1] = { 0.99f };
	emission[2] = { 0.99f };
	emission[3] = { 1.0f };
	m_lightPosition = new Vector4(m_position.x, m_position.y, m_position.z, 1);
}

star::~star()
{
	delete m_lightPosition;
}

/// <summary>
/// updates the stars light in the scene when called in the scene
/// </summary>
void star::UpdateLights()
{
	glLightfv(GL_LIGHT0, GL_AMBIENT, &(m_lightData->Ambient.x));
	glLightfv(GL_LIGHT0, GL_DIFFUSE, &(m_lightData->Diffuse.x));
	glLightfv(GL_LIGHT0, GL_SPECULAR, &(m_lightData->Specular.x));
	glLightfv(GL_LIGHT0, GL_POSITION, &(m_lightPosition->x));
}

void star::Update()
{
	RotateAll(Vector3(0.1f,0.2f,0.3f), 1);
	m_lightPosition->x = m_position.x;
	m_lightPosition->y = m_position.y;
	m_lightPosition->z = m_position.z;
	m_lightPosition->w = 1;
	if (m_selected)
	{
		emission[0] = { 0 };
		emission[1] = { 0 };
		emission[2] = { 0};
		emission[3] = { 1.0f };
	}
	else
	{
		emission[0] = { 1 };
		emission[1] = { 0.99f };
		emission[2] = { 0.99f };
		emission[3] = { 1.0f };
	}
	SceneObject::Update();
}
	

void star::Draw()
{
	SceneObject::Draw();
}