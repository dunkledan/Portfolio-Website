#pragma once
#include <Windows.h>
#include <gl/GL.h>
#include <gl/GLU.h>
#include "GL/freeglut.h"
#include "GLUTCallbacks.h"
#include "Structures.h"
#include "LinkedList.h"
#include "Camera.h"
#include <iostream>
#include "Texture2D.h"
#include "tgaLoader.h"
#include "Constants.h"
#include "ObjLoader.h"
#include "star.h"
#include "Planet.h"
#include "SceneObject.h"
#include "skyBox.h"
#include "Text.h"
#include "SceneGraph.h"
#define REFRESHRATE 16

//useful structs

class Scene1
{
public:
	Scene1(int argc, char* argv[]);
	~Scene1(void);
	void Display();
	void Update();
	void KeyboardInput(unsigned char key, int x, int y);
	void MouseMovementInput(int x, int y);
	void MouseClickInput(int a, int b, int c, int d);
	void KeyboardSpecial(int key, int x, int y);

private:
	SceneGraph* m_solarSystemSceneGraph = nullptr;
	SceneGraphNode* m_solarSystemSceneGraphHead = nullptr;
	SceneGraphNode* m_solarSystemSceneGraphNode2 = nullptr;
	SceneGraphNode* m_solarSystemSceneGraphNode3 = nullptr;
	SceneGraphNode* m_solarSystemSceneGraphNode4 = nullptr;
	Camera* m_camera;
	LinkedList<SceneObject> m_linkedObjects = LinkedList<SceneObject>();
	void InitObjects();
	void InitGL(int argc, char* argv[]);
	void InitTextures();
	void InitMeshes();
	Texture2D* m_penguinsTexture = nullptr;
	Texture2D* m_invincibleTexture = nullptr;
	Texture2D* m_grassTexture = nullptr;
	Texture2D* m_starTexture = nullptr;
	Texture2D* m_spaceTexture = nullptr;
	Texture2D* m_planetTexture = nullptr;
	Texture2D* m_planetTexture2 = nullptr;
	Texture2D* m_planetTexture3 = nullptr;
	LinkedList<Texture2D> m_textureList = LinkedList<Texture2D>();
	Mesh* m_testMesh = nullptr;
	Mesh* m_testMeshTextured = nullptr;
	Mesh* m_planetTextured = nullptr;
	Mesh* m_planet2Textured = nullptr;
	Mesh* m_planet3Textured = nullptr;
	Mesh* m_starTextured = nullptr;
	Mesh* m_cubeMesh = nullptr;
	Mesh* m_stretchedCubeMesh = nullptr;
	Lighting* m_lightData = new Lighting();
	Vector4* m_lightPosition = new Vector4();
	void InitLighting();
	void CamPerspectiveSetup();
	void InitCamera();
	void CameraMovementInputs(unsigned char key, int x, int y);
	float CalculateFPS();
	void CreateMouseRay(Vector2 screenPos, Vector3& rayDir, Vector3& rayOrigin);
	SceneObject* m_selectedObject = nullptr;
	void HandleAllTextDisplay();
	skyBox* m_sbox = nullptr;
	void ScaleObjects();
	void CalculateMouseRayHit(SceneObject* editablePtr, int x, int y, SceneObject*& currentShortestobj, float& currentShortestRayDistance);
	void SelectObject(SceneObject* currentShortestobj);
	void UpdateLighting();
	void HandleRotationInput(unsigned char key);
	void DeselectObject();
	void SwapTexture(Texture2D* texture);
	Text* m_wText = nullptr;
	Text* m_aText = nullptr;
	Text* m_sText = nullptr;
	Text* m_dText = nullptr;
	Text* m_frameRateText = nullptr;
	Text* m_objectCountText = nullptr;
	Text* m_movementControlsText = nullptr;
	Text* m_objectMovementControlsText = nullptr;
	Text* m_upText = nullptr;
	Text* m_downText = nullptr;
	Text* m_leftText = nullptr;
	Text* m_rightText = nullptr;
	Text* m_shiftText = nullptr;
	Text* m_spaceText = nullptr;
	void InitHUDText();
	LinkedList<Text> m_HUDTextList = LinkedList<Text>();
	void ResetKeyStrokeTextColors();
	void InitPlanetsStar();
};