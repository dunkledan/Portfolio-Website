#pragma once
#include "Structures.h"

class Camera
{
private:
	Vector3 m_eye = Vector3(0, 0, 0);
	Vector3 m_centre = Vector3(0, 0, 0);
	Vector3 m_up = Vector3(0, 0, 0);
	Vector3 m_direction = Vector3(0, 0, 0);
	float m_yaw = -90.0f;
	float m_pitch = 0.0f;
	float m_roll = 0.0f;
	float m_speed = 1;
	float m_sensitivity = 0.2f;

public:
	Camera(Vector3 eye, Vector3 centre, Vector3 up);
	~Camera();
	void Update();
	void SetMovementSpeed(float speed) { m_speed = speed; };
	void SetSensitivity(float sensitivity) { m_sensitivity = sensitivity; };
	void MoveForward();
	void MoveBackwards();
	void MoveLeft();
	void MoveRight();
	void HandleMouseLook(int x, int y);
	void CamPerspectiveSetup();
	Vector3 GetDirection() { return m_direction; };
	Vector3 GetEye() { return m_eye; };
	Vector3 GetCentre() { return m_centre; };
	Vector3 GetUp() { return m_up; };
	void SetCentre(Vector3 c) { m_centre = c; };
	void SetEye(Vector3 e) { m_centre = e; };
	void SetUp(Vector3 u) { m_centre = u; };
	void LookAt(Vector3 pos);
};


