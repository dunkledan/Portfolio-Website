#include "skyBox.h"

skyBox::skyBox(Mesh* mesh, Texture2D* texture, float x, float y, float z, Camera* cam)
{
	m_position = Vector3(x, y, z);
	m_texture = texture;
	m_mesh = mesh;
	m_cam = cam;
}

void skyBox::Update()
{
	m_position = m_cam->GetEye();
}

/// <summary>
/// draws the skybox as 6 planes in world space
/// </summary>
void skyBox::Draw()
{
	glDepthMask(GL_FALSE);
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	glBindTexture(GL_TEXTURE_2D, m_texture->GetID());
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	//init Vertices + vertex data
	//material setup
	glPushMatrix();
	//rotate and translate + draw
	glTranslatef(m_position.x, m_position.y, m_position.z);
	glColor3f(1.0f, 1.0f, 1.0f);
	//draw 6 2D planes around the game area
	glBegin(GL_QUADS);
	float s = 500;
	// front face
	glTexCoord2f(0, 0); glVertex3f(-s, -s, s);
	glTexCoord2f(1, 0); glVertex3f(s, -s, s);
	glTexCoord2f(1, 1); glVertex3f(s, s, s);
	glTexCoord2f(0, 1); glVertex3f(-s, s, s);
	// back face
	glTexCoord2f(0, 0); glVertex3f(s, -s, -s);
	glTexCoord2f(1, 0); glVertex3f(-s, -s, -s);
	glTexCoord2f(1, 1); glVertex3f(-s, s, -s);
	glTexCoord2f(0, 1); glVertex3f(s, s, -s);
	// left face
	glTexCoord2f(0, 0); glVertex3f(-s, -s, -s);
	glTexCoord2f(1, 0); glVertex3f(-s, -s, s);
	glTexCoord2f(1, 1); glVertex3f(-s, s, s);
	glTexCoord2f(0, 1); glVertex3f(-s, s, -s);
	// right face
	glTexCoord2f(0, 0); glVertex3f(s, -s, s);
	glTexCoord2f(1, 0); glVertex3f(s, -s, -s);
	glTexCoord2f(1, 1); glVertex3f(s, s, -s);
	glTexCoord2f(0, 1); glVertex3f(s, s, s);
	// top face
	glTexCoord2f(0, 0); glVertex3f(-s, s, s);
	glTexCoord2f(1, 0); glVertex3f(s, s, s);
	glTexCoord2f(1, 1); glVertex3f(s, s, -s);
	glTexCoord2f(0, 1); glVertex3f(-s, s, -s);
	// bottom face
	glTexCoord2f(0, 0); glVertex3f(-s, -s, -s);
	glTexCoord2f(1, 0); glVertex3f(s, -s, -s);
	glTexCoord2f(1, 1); glVertex3f(s, -s, s);
	glTexCoord2f(0, 1); glVertex3f(-s, -s, s);
	glEnd();
	glPopMatrix();
	//disable uneeded stacks
	glEnable(GL_CULL_FACE);
	glDepthMask(GL_TRUE);
	glEnable(GL_LIGHTING);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}

skyBox::~skyBox()
{
}