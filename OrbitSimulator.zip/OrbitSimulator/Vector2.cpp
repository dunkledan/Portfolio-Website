#include "Vector2.h"

Vector2::Vector2()
{
}

Vector2::Vector2(float _x, float _y)
{
	x = _x;
	y = _y;
}

Vector2::~Vector2()
{
}

Vector2 Vector2::operator*(float scalar)
{
	this->x = this->x * scalar;
	this->y = this->y * scalar;
	Vector2 newVector(x, y);
	return newVector;
}

Vector2 Vector2::operator+(const Vector2& OtherVector2)
{
	float newV2X = this->x + OtherVector2.x;
	float newV2Y = this->y + OtherVector2.y;
	Vector2 NewV2(newV2X, newV2Y);
	return NewV2;
}

Vector2 Vector2::operator-(const Vector2& OtherVector2)
{
	float newV2X = this->x - OtherVector2.x;
	float newV2Y = this->y - OtherVector2.y;
	Vector2 NewV2(newV2X, newV2Y);
	return NewV2;
}

Vector2 Vector2::operator-()
{
	Vector2 NewV2(this->x * -1, this->y * -1);
	return NewV2;
}

Vector2 Vector2::Normalized()
{
	float Mag = Magnitude();
	float newX = x / Mag;
	float newY = y / Mag;
	Vector2 NewV2(newX,newY);
	return NewV2;
}

float Vector2::Distance(Vector2& v1, Vector2& v2)
{
	Vector2 distanceVector((v1.x - v2.x), (v1.y - v2.y));
	return distanceVector.Magnitude();
}

float Vector2::Magnitude()
{
	return sqrt(pow(x, 2) + pow(y, 2));
}

float Vector2::Dot(Vector2& v1, Vector2& v2)
{
	float xMult = v1.x * v2.x;
	float yMult = v1.y * v2.y;
	float product = xMult + yMult;
	return product;
}

float Vector2::CalculateDistanceSquared(Vector2 point1, Vector2 point2)
{
	float distance = ((point1.x - point2.x) * (point1.x - point2.x)) + ((point1.y - point2.y) * (point1.y - point2.y));
	return distance;
}