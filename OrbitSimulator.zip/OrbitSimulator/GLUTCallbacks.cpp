#include "GLUTCallbacks.h"
#include "Scene1.h"

/// <summary>Glut callback functions that can be called dynamically throughout codebase</summary>
namespace GLUTCallbacks
{
	namespace
	{
		Scene1* scene1 = nullptr;
	}

	/// <summary>Initialises main class</summary>
	void Init(Scene1* gl)
	{
		scene1 = gl;
	}

	/// <summary>Draws all data to screen from main class</summary>
	void Display()
	{
		if (scene1 != nullptr)
		{
			scene1->Display();
		}
	}

	/// <summary>Sets and manages framerate for when to update the program e.g update 60/s if frame rate is 60fps</summary>
	void Timer(int preferredRefresh)
	{
		int updateTime = glutGet(GLUT_ELAPSED_TIME);
		scene1->Update();
		updateTime = glutGet(GLUT_ELAPSED_TIME) - updateTime;
		glutTimerFunc(preferredRefresh - updateTime, GLUTCallbacks::Timer, preferredRefresh);
	}

	/// <summary>Allows keyboard input</summary>
	void Keyboard(unsigned char key, int x, int y)
	{
		scene1->KeyboardInput(key,x,y);
	}

	void KeyboardSpecial(int key, int x, int y)
	{
		scene1->KeyboardSpecial(key, x, y);
	}


	/// <summary>Allows mouse movement position to be read when the mouse moves</summary>
	void MouseMovementInput(int x, int y)
	{
		scene1->MouseMovementInput(x, y);
	}

	/// <summary>Allows mosuse buttons left and right with position of the mouse when clicked to be found</summary>
	void MouseClickInput(int a, int b, int c, int d)
	{
		scene1->MouseClickInput(a, b, c, d);
	}
}