#include "Scene1.h"

/// <summary>constructor inits all relevant data and starts the update loop</summary>
Scene1::Scene1(int argc, char* argv[])
{
	InitGL(argc, argv);
	InitCamera();
	InitTextures();
	InitMeshes();
	InitObjects();
	InitLighting();
	InitHUDText();
	glutMainLoop();
}

/// <summary>Initialises HUD text for this scene</summary>
void Scene1::InitHUDText()
{
	m_wText = new Text("W", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 110, glutGet(GLUT_SCREEN_HEIGHT) - 30, 0), Color(0, 1, 0));
	m_aText = new Text("A", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 150, glutGet(GLUT_SCREEN_HEIGHT) - 60, 0), Color(0, 1, 0));
	m_sText = new Text("S", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 100, glutGet(GLUT_SCREEN_HEIGHT) - 60, 0), Color(0, 1, 0));
	m_dText = new Text("D", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 60, glutGet(GLUT_SCREEN_HEIGHT) - 60, 0), Color(0, 1, 0));
	m_frameRateText = new Text("FrameRate: ", Vector3(10, glutGet(GLUT_SCREEN_HEIGHT) - 30, 0), Color(0, 1, 0));
	m_objectCountText = new Text("Object count: ", Vector3(10, glutGet(GLUT_SCREEN_HEIGHT) - 60, 0), Color(0, 1, 0));
	m_movementControlsText = new Text("Movement Controls", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 600, glutGet(GLUT_SCREEN_HEIGHT) - 50, 0), Color(0, 1, 0));
	m_objectMovementControlsText = new Text("Move Select object controls", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 800, glutGet(GLUT_SCREEN_HEIGHT) - 600, 0), Color(0, 1, 0));
	m_upText = new Text("Up", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 150, glutGet(GLUT_SCREEN_HEIGHT) - 600, 0), Color(0, 1, 0));
	m_downText = new Text("Down", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 180, glutGet(GLUT_SCREEN_HEIGHT) - 630, 0), Color(0, 1, 0));
	m_leftText = new Text("<-", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 230, glutGet(GLUT_SCREEN_HEIGHT) - 630, 0), Color(0, 1, 0));
	m_rightText = new Text("->", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 60, glutGet(GLUT_SCREEN_HEIGHT) - 630, 0), Color(0, 1, 0));
	m_shiftText = new Text("LShift", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 250, glutGet(GLUT_SCREEN_HEIGHT) - 700, 0), Color(0, 1, 0));
	m_spaceText = new Text("Space", Vector3(glutGet(GLUT_SCREEN_WIDTH) - 130, glutGet(GLUT_SCREEN_HEIGHT) - 700, 0), Color(0, 1, 0));
	m_HUDTextList.Push(m_wText);
	m_HUDTextList.Push(m_aText);
	m_HUDTextList.Push(m_sText);
	m_HUDTextList.Push(m_dText);
	m_HUDTextList.Push(m_frameRateText);
	m_HUDTextList.Push(m_objectCountText);
	m_HUDTextList.Push(m_movementControlsText);
	m_HUDTextList.Push(m_objectMovementControlsText);
	m_HUDTextList.Push(m_upText);
	m_HUDTextList.Push(m_downText);
	m_HUDTextList.Push(m_leftText);
	m_HUDTextList.Push(m_rightText);
	m_HUDTextList.Push(m_shiftText);
	m_HUDTextList.Push(m_spaceText);
}


/// <summary>Load textures from file and store them for later use</summary>
void Scene1::InitTextures()
{
	//texture loading
	//raw textures
	m_penguinsTexture = new Texture2D();
	m_penguinsTexture->LoadRAW("Textures/penguins.raw", 512, 512);
	//tga textures
	tgaLoader TGALoader;
	m_invincibleTexture = new Texture2D();
	m_invincibleTexture->SetID(TGALoader.LoadTextureTGA("Textures/invincible.tga"));
	m_grassTexture = new Texture2D();
	m_grassTexture->SetID(TGALoader.LoadTextureTGA("Textures/grass.tga"));
	m_starTexture = new Texture2D();
	m_starTexture->SetID(TGALoader.LoadTextureTGA("Textures/star.tga"));
	m_spaceTexture = new Texture2D();
	m_spaceTexture->SetID(TGALoader.LoadTextureTGA("Textures/space.tga"));
	m_planetTexture = new Texture2D();
	m_planetTexture->SetID(TGALoader.LoadTextureTGA("Textures/planet.tga"));
	m_planetTexture2 = new Texture2D();
	m_planetTexture2->SetID(TGALoader.LoadTextureTGA("Textures/earth.tga"));
	m_planetTexture3 = new Texture2D();
	m_planetTexture3->SetID(TGALoader.LoadTextureTGA("Textures/mars.tga"));
	//push to linkedlist storage
	m_textureList.Push(m_penguinsTexture);
	m_textureList.Push(m_invincibleTexture);
	m_textureList.Push(m_grassTexture);
	m_textureList.Push(m_starTexture);
	m_textureList.Push(m_spaceTexture);
	m_textureList.Push(m_planetTexture);
	m_textureList.Push(m_planetTexture2);

}

/// <summary>Load meshes from file and store them for later use</summary>
void Scene1::InitMeshes()
{
	ObjLoader* objLoader = new ObjLoader();
	m_testMesh = objLoader->LoadTextured("Meshes/capsule.obj");
	m_testMeshTextured = objLoader->LoadTextured("Meshes/capsule.obj");
	m_planetTextured = objLoader->LoadTextured("Meshes/planet.obj");
	m_planet2Textured = objLoader->LoadTextured("Meshes/star.obj");
	m_planet3Textured = objLoader->LoadTextured("Meshes/star.obj");
	m_starTextured = objLoader->LoadTextured("Meshes/star.obj");
	m_cubeMesh = objLoader->LoadTextured("Meshes/cube.obj");
	delete objLoader;
	objLoader = nullptr;
}

/// <summary>Initlaise SceneObjects within a Linked list to store them for the scene</summary>
void Scene1::InitObjects()
{
	m_sbox = new skyBox(m_cubeMesh, m_spaceTexture, 0, 0, 0, m_camera);
	m_linkedObjects.Push(new star(m_starTextured, m_starTexture, 0, 0, -10));
	m_linkedObjects.Push(new Planet(m_planetTextured, m_planetTexture, 0, 0, -40, 10));
	m_linkedObjects.Push(new Planet(m_planet2Textured, m_planetTexture2, 0, 0, -20, 20));
	m_linkedObjects.Push(new Planet(m_planet3Textured, m_planetTexture3, 0, 0, -30, 10));
	m_linkedObjects.Push(new SceneObject(m_cubeMesh, m_grassTexture, 0, -10, 0));

	ScaleObjects();
	InitPlanetsStar();

	//init scene graph
	m_solarSystemSceneGraphHead = new SceneGraphNode(nullptr, nullptr, nullptr, m_linkedObjects.GetItemByIndex(0));
	m_solarSystemSceneGraphNode2 = new SceneGraphNode(nullptr, nullptr, nullptr, m_linkedObjects.GetItemByIndex(1));
	m_solarSystemSceneGraphNode3 = new SceneGraphNode(nullptr, nullptr, nullptr, m_linkedObjects.GetItemByIndex(2));
	m_solarSystemSceneGraphNode4 = new SceneGraphNode(nullptr, nullptr, nullptr, m_linkedObjects.GetItemByIndex(3));
	m_solarSystemSceneGraph = new SceneGraph(m_solarSystemSceneGraphHead);
	m_solarSystemSceneGraphHead->left = m_solarSystemSceneGraphNode2;
	m_solarSystemSceneGraphNode2->right = m_solarSystemSceneGraphNode3;
	m_solarSystemSceneGraphNode3->right = m_solarSystemSceneGraphNode4;

}

/// <summary>Scale SceneObjects as required here after instantiating them </summary>
void Scene1::ScaleObjects()
{
	m_linkedObjects.GetItemByIndex(4)->SetScaleX(100);
	m_linkedObjects.GetItemByIndex(4)->SetScaleZ(100);
	m_linkedObjects.GetItemByIndex(0)->SetScale(2);
	m_linkedObjects.GetItemByIndex(1)->SetScale(0.9f);
	m_linkedObjects.GetItemByIndex(2)->SetScale(0.8f);
}

/// <summary>
/// initialises each planet to orbit the specific star given
/// </summary>
void Scene1::InitPlanetsStar()
{
	for (int i = 0; i < m_linkedObjects.GetSize(); i++)
	{
		if (dynamic_cast<Planet*>(m_linkedObjects.GetItemByIndex(i)) != nullptr)
		{
			dynamic_cast<Planet*>(m_linkedObjects.GetItemByIndex(i))->InitOrbit((rand() % 15 - 3) / 100.0f, 10+rand() % 10, dynamic_cast<star*>(m_linkedObjects.GetItemByIndex(0)));
		}
	}
}

/// <summary>Initialise generic lighting for the scene</summary>
void Scene1::InitLighting()
{
	m_lightData = new Lighting(Vector4(0.2f, 0.2f, 0.2f, 1), Vector4(1, 0, 0, 1), Vector4(1, 1, 1, 1));
	m_lightPosition = new Vector4(0, 10, 0, 1);
}

/// <summary>Initialise OpenGL and GLUT functions, in addition to allowing input reading</summary>
void Scene1::InitGL(int argc, char* argv[])
{
	GLUTCallbacks::Init(this);
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GL_DEPTH_BUFFER_BIT);
	glutInitWindowSize(glutGet(GLUT_SCREEN_HEIGHT), glutGet(GLUT_SCREEN_HEIGHT));
	glutCreateWindow("Simple Orbit simulation");
	//glut calbacks
	glutDisplayFunc(GLUTCallbacks::Display);
	//sets refresh rate to ~60fps
	glutTimerFunc(REFRESHRATE, GLUTCallbacks::Timer, REFRESHRATE);
	//keyboard input
	glutKeyboardFunc(GLUTCallbacks::Keyboard);
	glutSpecialFunc(GLUTCallbacks::KeyboardSpecial);
	//mouse movement
	glutPassiveMotionFunc(GLUTCallbacks::MouseMovementInput);
	glutMouseFunc(GLUTCallbacks::MouseClickInput);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glCullFace(GL_BACK);
}

/// <summary>Initialises camera for the scene</summary>
void Scene1::InitCamera()
{
	m_camera = new Camera(Vector3(-5, 0, 10), Vector3(0, 0, 0), Vector3(0, 1, 0));
	m_camera->CamPerspectiveSetup();
}

/// <summary>
/// calculate if a ray cast from the pouse position in two space hits any 3D objects in world space and returns the closet one + that distance by reference based on the direction the camera is facing
/// </summary>
/// <param name="editablePtr"></param>
/// <param name="x"></param>
/// <param name="y"></param>
/// <param name="currentShortestobj"></param>
/// <param name="currentShortestRayDistance"></param>
void Scene1::CalculateMouseRayHit(SceneObject* editablePtr, int x, int y, SceneObject*& currentShortestobj, float& currentShortestRayDistance)
{
	//calculate ray hit
	Vector3 mouseRayDirection = Vector3();
	Vector3 mouseWorldPosOrigin = Vector3();
	CreateMouseRay(Vector2(x, y), mouseRayDirection, mouseWorldPosOrigin);
	float objRadius = editablePtr->GetRadius();
	Vector3 objPos = editablePtr->GetPosition();
	Vector3 rayOriginToObjectDistance = objPos - mouseWorldPosOrigin;
	float dotProduct = rayOriginToObjectDistance.Dot(rayOriginToObjectDistance, mouseRayDirection);
	Vector3 tempRayDir = mouseRayDirection * dotProduct;
	Vector3 rayClosestPointToObj = mouseWorldPosOrigin + tempRayDir;
	Vector3 Dist = objPos - rayClosestPointToObj;
	float Distance = Dist.Magnitude();
	if (Distance <= objRadius)
	{
		//check if this is the closest object so far to start ray
		if (currentShortestRayDistance > Distance)
		{
			currentShortestRayDistance = Distance;
			currentShortestobj = editablePtr;
		}
	}
}

/// <summary>
/// Selects a Given scene object 
/// </summary>
/// <param name="currentShortestobj"></param>
void Scene1::SelectObject(SceneObject* currentShortestobj)
{
	if (currentShortestobj != nullptr)
	{
		if (currentShortestobj == m_solarSystemSceneGraphHead->data)
		{
			m_solarSystemSceneGraph->SetSelectedInOrder(m_solarSystemSceneGraphHead, true);
			m_solarSystemSceneGraph->SetMaterialInOrder(m_solarSystemSceneGraphHead);
		}
		else
		{
			m_solarSystemSceneGraph->SetSelectedInOrder(m_solarSystemSceneGraphHead, false);
			m_solarSystemSceneGraph->SetMaterialInOrder(m_solarSystemSceneGraphHead);
		}
		if (m_selectedObject != nullptr)
		{
			m_selectedObject->SetMaterial(m_selectedObject->m_unselectedMaterial);
			m_selectedObject->SetSelected(false);
		}
		m_selectedObject = currentShortestobj;
		m_selectedObject->SetMaterial(m_selectedObject->m_selectedMaterial);
		m_selectedObject->SetSelected(true);
	}
}

/// <summary>
/// handles mouse click input
/// </summary>
/// <param name="rightClick"></param>
/// <param name="leftClick"></param>
/// <param name="x"></param>
/// <param name="y"></param>
void Scene1::MouseClickInput(int rightClick, int leftClick, int x, int y)
{
	float currentShortestRayDistance = INT_MAX;
	SceneObject* currentShortestobj = nullptr;
	for (int i = 0; i < m_linkedObjects.GetSize(); i++)
	{
		if (m_linkedObjects.GetItemByIndex(i) != nullptr)
		{
			//calculate ray hit
			CalculateMouseRayHit(m_linkedObjects.GetItemByIndex(i),x,y, currentShortestobj, currentShortestRayDistance);
		}
	}
	SelectObject(currentShortestobj);
}

/// <summary>
/// https://antongerdelan.net/opengl/raycasting.html - source for a lot of the calculations herer
/// </summary>
/// <param name="screenPos"></param>
/// <returns></returns>
void Scene1::CreateMouseRay(Vector2 screenPos, Vector3& rayDir, Vector3& rayOrigin)
{
	//Get viewport and relevant matrices to inverse project for deprojection
	GLdouble modelMatrixPtr[16];
	GLdouble projectionMatrixPtr[16];
	GLint viewport[4];
	glGetDoublev(GL_PROJECTION_MATRIX, projectionMatrixPtr);
	glGetDoublev(GL_MODELVIEW_MATRIX, modelMatrixPtr);
	glGetIntegerv(GL_VIEWPORT, viewport);
	//Get near and far planes
	//near plane
	GLdouble nearX, nearY, nearZ;
	gluUnProject(screenPos.x, viewport[3] - screenPos.y, 0, modelMatrixPtr, projectionMatrixPtr, viewport, &nearX, &nearY, &nearZ);
	//far plane
	GLdouble farX, farY, farZ;
	gluUnProject(screenPos.x, viewport[3] - screenPos.y, 1, modelMatrixPtr, projectionMatrixPtr, viewport, &farX, &farY, &farZ);
	//noramlised direction of the ray
	Vector3 rayUnNormal = Vector3(farX - nearX, farY - nearY, farZ - nearZ);
	float magnitude = rayUnNormal.Magnitude();
	Vector3 rayNormalised = rayUnNormal.Normalized();
	rayDir = rayNormalised;
	rayOrigin = Vector3(nearX, nearY, nearZ);
}


/// <summary>Calculates and returns current fps whemn called in display function</summary>
float Scene1::CalculateFPS()
{
	static int frameCount = 0;
	static float lastTime = 0.0f;
	static float displayFPS = 0.0f;
	float currentTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
	frameCount++;
	//update framerate every second
	if (currentTime - lastTime >= 1.0f)
	{
		displayFPS = frameCount;
		frameCount = 0;
		lastTime = currentTime;
	}
	return displayFPS;
}

/// <summary>Displays all elements on the screen each frame</summary>
void Scene1::Display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//clears scene 
	//render skybox
	m_sbox->Draw();
	//render text
	HandleAllTextDisplay();
	for (int i = 0; i < m_linkedObjects.GetSize(); i++)
	{
		m_linkedObjects.GetItemByIndex(i)->Draw();
	}
	glutSwapBuffers();//swaps to forward buffer
}

/// <summary>
/// displays all text in the HUD list
/// </summary>
void Scene1::HandleAllTextDisplay()
{
	//calcaulate fps
	float fps = CalculateFPS();
	m_frameRateText->m_text = "FPS: " + to_string((int)fps);
	m_objectCountText->m_text = "Object count: " + to_string(m_linkedObjects.GetSize());
	//draw all HUD elements
	for (int i = 0; i < m_HUDTextList.GetSize(); i++)
	{
		m_HUDTextList.GetItemByIndex(i)->DrawString();
	}
}

/// <summary>
/// updates the lighting for the scene every frame
/// </summary>
void Scene1::UpdateLighting()
{
	glLightfv(GL_LIGHT0, GL_AMBIENT, &(m_lightData->Ambient.x));
	glLightfv(GL_LIGHT0, GL_DIFFUSE, &(m_lightData->Diffuse.x));
	glLightfv(GL_LIGHT0, GL_SPECULAR, &(m_lightData->Specular.x));
	glLightfv(GL_LIGHT0, GL_POSITION, &(m_lightPosition->x));
}

/// <summary>Updates relevant scene data once per frame</summary>
void Scene1::Update()
{
	//reset ModelViewMatrix, to stop continous rendering from previous frames
	glLoadIdentity();
	UpdateLighting();
	m_camera->Update();
	m_sbox->Update();
	for (int i = 0; i < m_linkedObjects.GetSize(); i++)
	{
		if(dynamic_cast<star*>(m_linkedObjects.GetItemByIndex(i)) != nullptr)
		{
			dynamic_cast<star*>(m_linkedObjects.GetItemByIndex(i))->UpdateLights();
		}
	}
	if (m_selectedObject != nullptr)
	{
		m_camera->LookAt(m_selectedObject->GetPosition());
	}
	//update functions for each obj
	for (int i = 0; i < m_linkedObjects.GetSize(); i++)
	{
		m_linkedObjects.GetItemByIndex(i)->Update();
	}
	glutPostRedisplay();
}

/// <summary>
/// handles input to rotate a selected scene object
/// </summary>
/// <param name="key"></param>
void Scene1::HandleRotationInput(unsigned char key)
{
	//rotate roll
	if (key == '1')
	{
		if (m_selectedObject != nullptr)
		{
			if (m_selectedObject == m_solarSystemSceneGraphHead->data)
			{
				m_solarSystemSceneGraph->SetRotationRollInOrder(m_solarSystemSceneGraphHead);
			}
			(m_selectedObject)->RotateRoll(1, 1);
		}
	}
	//rotate roll
	if (key == '2')
	{
		if (m_selectedObject != nullptr)
		{
			if (m_selectedObject == m_solarSystemSceneGraphHead->data)
			{
				m_solarSystemSceneGraph->SetRotationYawInOrder(m_solarSystemSceneGraphHead);
			}
			m_selectedObject->RotateYaw(1, 1);
		}
	}
	//rotate pitch
	if (key == '3')
	{
		if (m_selectedObject != nullptr)
		{
			if (m_selectedObject == m_solarSystemSceneGraphHead->data)
			{
				m_solarSystemSceneGraph->SetRotationPitchInOrder(m_solarSystemSceneGraphHead);
			}
			m_selectedObject->RotatePitch(1, 1);
		}
	}
	//rotate all
	if (key == '4')
	{
		if (m_selectedObject != nullptr)
		{
			if (m_selectedObject == m_solarSystemSceneGraphHead->data)
			{
				m_solarSystemSceneGraph->SetRotationInOrder(m_solarSystemSceneGraphHead);
			}
			m_selectedObject->RotateAll(Vector3(1, 1, 1), 1);
		}
	}
}

/// <summary>
/// deselects the currently selected object
/// </summary>
void Scene1::DeselectObject()
{
	m_selectedObject->SetSelected(false);
	m_selectedObject->SetMaterial(m_selectedObject->m_unselectedMaterial);
	m_selectedObject = nullptr;
	ResetKeyStrokeTextColors();
}

/// <summary>
/// swaps the texture of the currently selected object
/// </summary>
/// <param name="texture"></param>
void Scene1::SwapTexture(Texture2D* texture)
{
	if (m_selectedObject != nullptr)
	{
		if (m_selectedObject == m_solarSystemSceneGraphHead->data)
		{
			m_solarSystemSceneGraph->SetTextureInOrder(m_solarSystemSceneGraphHead, texture);
		}
		m_selectedObject->SetTexture(texture);
	}
}

/// <summary>
/// resets all keystroke text colors to thier default value (green)
/// </summary>
void Scene1::ResetKeyStrokeTextColors()
{
	for (int i = 0; i < m_HUDTextList.GetSize(); i++)
	{
		m_HUDTextList.GetItemByIndex(i)->SetColor(Color(0,1,0));
	}
}

/// <summary>Handles Keyboard input and results once per frame</summary>
void Scene1::KeyboardInput(unsigned char key, int x, int y)
{
	ResetKeyStrokeTextColors();
	//Camera movement inputs
	CameraMovementInputs(key, x, y);
	//user interaction with editable scene objects
	HandleRotationInput(key);
	if (key == '5')
	{
		SwapTexture(m_planetTexture);
	}
	//move object upwards with space
	if (key == ' ')
	{
		if (m_selectedObject != nullptr)
		{
			for (int i = 0; i < m_linkedObjects.GetSize(); i++)
			{
				if (m_linkedObjects.GetItemByIndex(i)->GetSelectedState())
				{
					m_linkedObjects.GetItemByIndex(i)->Translate(Vector3(0, 0.1f, 0));
				}
			}
			m_spaceText->SetColor(Color(1, 1, 1));
		}
	}
	//deselect object when esc pressed
	if (key == 27)
	{
		if(m_selectedObject != nullptr)
		{
			m_solarSystemSceneGraph->SetSelectedInOrder(m_solarSystemSceneGraphHead, false);
			m_solarSystemSceneGraph->SetMaterialInOrder(m_solarSystemSceneGraphHead);
			DeselectObject();
		}
	}
}

/// <summary>
/// handles special characters pressed on the keyboard and calls relevant functiosn
/// </summary>
/// <param name="key"></param>
/// <param name="x"></param>
/// <param name="y"></param>
void Scene1::KeyboardSpecial(int key, int x, int y)
{
	ResetKeyStrokeTextColors();
	//move selected object in specific direction based on key input
	if (key == GLUT_KEY_UP)
	{
		if (m_selectedObject != nullptr)
		{
			for (int i = 0; i < m_linkedObjects.GetSize(); i++)
			{
				if (m_linkedObjects.GetItemByIndex(i)->GetSelectedState())
				{
					m_linkedObjects.GetItemByIndex(i)->Translate(Vector3(0, 0, -0.1f));
				}
			}
			m_upText->SetColor(Color(1, 1, 1));
		}
	}
	if (key == GLUT_KEY_DOWN)
	{
		if (m_selectedObject != nullptr)
		{
			for (int i = 0; i < m_linkedObjects.GetSize(); i++)
			{
				if (m_linkedObjects.GetItemByIndex(i)->GetSelectedState())
				{
					m_linkedObjects.GetItemByIndex(i)->Translate(Vector3(0, 0, 0.1f));
				}
			}
			m_downText->SetColor(Color(1, 1, 1));
		}
	}
	if (key == GLUT_KEY_RIGHT)
	{
		if (m_selectedObject != nullptr)
		{
			for (int i = 0; i < m_linkedObjects.GetSize(); i++)
			{
				if (m_linkedObjects.GetItemByIndex(i)->GetSelectedState())
				{
					m_linkedObjects.GetItemByIndex(i)->Translate(Vector3(0.1, 0, 0));
				}
			}
			m_rightText->SetColor(Color(1, 1, 1));
		}
	}
	if (key == GLUT_KEY_LEFT)
	{
		if (m_selectedObject != nullptr)
		{
			for (int i = 0; i < m_linkedObjects.GetSize(); i++)
			{
				if (m_linkedObjects.GetItemByIndex(i)->GetSelectedState())
				{
					m_linkedObjects.GetItemByIndex(i)->Translate(Vector3(-0.1f, 0, 0));
				}
			}
			m_leftText->SetColor(Color(1, 1, 1));
		}
	}
	if (key == GLUT_KEY_SHIFT_L)
	{
		if (m_selectedObject != nullptr)
		{
			for (int i = 0; i < m_linkedObjects.GetSize(); i++)
			{
				if (m_linkedObjects.GetItemByIndex(i)->GetSelectedState())
				{
					m_linkedObjects.GetItemByIndex(i)->Translate(Vector3(0, -0.1f, -0));
				}
			}
			m_shiftText->SetColor(Color(1, 1, 1));
		}
	}
}

/// <summary>
/// moves camera based on mosue movement
/// </summary>
/// <param name="key"></param>
/// <param name="x"></param>
/// <param name="y"></param>
void Scene1::CameraMovementInputs(unsigned char key, int x, int y)
{
	ResetKeyStrokeTextColors();
	if (key == 'w')
	{
		m_wText->SetColor(Color(1, 1, 1));
		//moves camera position forward based on direction camera is looking
		m_camera->MoveForward();
	}
	if (key == 'a')
	{
		m_aText->SetColor(Color(1, 1, 1));
		//moves camera position left based on direction camera is looking
		m_camera->MoveLeft();
	}
	if (key == 's')
	{
		m_sText->SetColor(Color(1, 1, 1));
		//moves camera position backwards based on direction camera is looking
		m_camera->MoveBackwards();

	}
	if (key == 'd')
	{
		//input text handling  for controls display
		m_dText->SetColor(Color(1, 1, 1));
		//moves camera position right based on direction camera is looking
		m_camera->MoveRight();
	}
}

/// <summary>Updates relevant data based on mouse movement input</summary>
void Scene1::MouseMovementInput(int x, int y)
{
	if (!m_selectedObject)
	{
		m_camera->HandleMouseLook(x, y);
	}
}

/// <summary>destructor to properly deallocate memory</summary>
Scene1::~Scene1(void)
{
	//deallocate text memory
	for (int i = 0; i < m_HUDTextList.GetSize(); i++)
	{
		delete m_HUDTextList.GetItemByIndex(i);
	}
	//deallocate texture memory
	for (int i = 0; i < m_textureList.GetSize(); i++)
	{
		delete m_textureList.GetItemByIndex(i);
	}
	//deallocate object memory
	for (int i = 0; i < m_linkedObjects.GetSize(); i++)
	{
		delete m_linkedObjects.GetItemByIndex(i);
	}
	//deallocate skybox memory
	delete m_sbox;
	m_sbox = nullptr;
	//deallocate lighting memory
	delete m_lightData;
	m_lightData = nullptr;
	delete m_lightPosition;
	m_lightPosition = nullptr;
	//deallocate camera memory
	delete m_camera;
	m_camera = nullptr;
}