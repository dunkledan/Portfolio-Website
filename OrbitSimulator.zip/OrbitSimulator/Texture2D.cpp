#include "Texture2D.h"

using namespace std;

Texture2D::Texture2D()
{

}

Texture2D::~Texture2D()
{
	glDeleteTextures(1, &m_ID);
}

/// <summary>
/// loads a texture and binds it to next available ID based on raw file data
/// </summary>
/// <param name="path"></param>
/// <param name="width"></param>
/// <param name="height"></param>
/// <returns></returns>
bool Texture2D::LoadRAW(const char* path, int width, int height)
{
	//load texture from path
	char* tempTextureData;
	int fileSize;
	ifstream inFile;
	m_width = width;
	m_height = height;
	inFile.open(path,ios::binary);
	if (!inFile.good())
	{
		std::cerr << "failed to load textures " << path << std::endl;
		return false;
	}
	//read file to end if good
	inFile.seekg(0, ios::end);
	fileSize = (int)inFile.tellg();
	tempTextureData = new char[fileSize];
	inFile.seekg(0,ios::beg);
	inFile.read(tempTextureData, fileSize);
	inFile.close();
	//texture generation
	glGenTextures(1, &m_ID);
	glBindTexture(GL_TEXTURE_2D, m_ID);
	//texture sampling type 
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	//generate image based on texture
	glTexImage2D(GL_TEXTURE_2D, 0,3,width,height,0,GL_RGB,GL_UNSIGNED_BYTE,tempTextureData);
	delete [] tempTextureData;
	return true;
}