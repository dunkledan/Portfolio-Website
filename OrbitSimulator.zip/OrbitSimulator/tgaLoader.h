#pragma once
#include "Structures.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

class tgaLoader
{
public:
	int LoadTextureTGA(const char* textureFileName);
	tgaLoader();
	~tgaLoader();
};

